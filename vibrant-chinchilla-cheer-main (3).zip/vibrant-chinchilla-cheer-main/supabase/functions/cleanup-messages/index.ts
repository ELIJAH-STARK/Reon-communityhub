import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log("[cleanup-messages] Starting message maintenance tasks...");

    // 1. Permanently delete archived messages older than 2 months
    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(twoMonthsAgo.getMonth() - 2);
    
    const { count: archivedDeleted, error: archivedError } = await supabaseAdmin
      .from('deleted_messages')
      .delete({ count: 'exact' })
      .lt('deleted_at', twoMonthsAgo.toISOString());

    if (archivedError) throw archivedError;
    console.log(`[cleanup-messages] Permanently removed ${archivedDeleted} archived messages (2nd month threshold).`);

    // 2. Delete active messages not visited (updated) for 1 year
    const oneYearAgo = new Date();
    oneYearAgo.setFullYear(oneYearAgo.getFullYear() - 1);

    const { count: inactiveDeleted, error: inactiveError } = await supabaseAdmin
      .from('messages')
      .delete({ count: 'exact' })
      .lt('updated_at', oneYearAgo.toISOString());

    if (inactiveError) throw inactiveError;
    console.log(`[cleanup-messages] Removed ${inactiveDeleted} inactive messages (1-year threshold).`);

    return new Response(JSON.stringify({ 
      success: true, 
      archivedCleared: archivedDeleted, 
      inactiveCleared: inactiveDeleted 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('[cleanup-messages] Fatal Maintenance Error:', message)
    return new Response(JSON.stringify({ success: false, error: message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})