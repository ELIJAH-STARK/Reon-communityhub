import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { guestUserId, existingUserId } = await req.json()

    if (!guestUserId || !existingUserId) {
      return new Response(JSON.stringify({ error: 'Missing guestUserId or existingUserId' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400,
      })
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    const authHeader = req.headers.get('Authorization')
    if (!authHeader) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 401,
      })
    }

    const token = authHeader.replace('Bearer ', '')
    const { data: { user: authenticatedUser }, error: authError } = await supabaseClient.auth.getUser(token)

    if (authError || !authenticatedUser || authenticatedUser.id !== existingUserId) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 403,
      })
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log(`[merge-accounts] Starting merge for guest ${guestUserId} into user ${existingUserId}`);

    // 1. Transfer Goods
    await supabaseAdmin.from('goods').update({ user_id: existingUserId }).eq('user_id', guestUserId);

    // 2. Transfer Services
    await supabaseAdmin.from('services').update({ user_id: existingUserId }).eq('user_id', guestUserId);

    // 3. Transfer Messages (Sender)
    await supabaseAdmin.from('messages').update({ sender_id: existingUserId }).eq('sender_id', guestUserId);

    // 4. Transfer Messages (Receiver)
    await supabaseAdmin.from('messages').update({ receiver_id: existingUserId }).eq('receiver_id', guestUserId);

    // 5. Transfer Favorites
    await supabaseAdmin.from('favorites').update({ user_id: existingUserId }).eq('user_id', guestUserId);

    // 6. Transfer Notifications
    await supabaseAdmin.from('notifications').update({ user_id: existingUserId }).eq('user_id', guestUserId);

    // 7. Transfer Reviews (where the guest was the reviewer)
    await supabaseAdmin.from('reviews').update({ reviewer_id: existingUserId }).eq('reviewer_id', guestUserId);

    // 8. Delete the guest user (ON DELETE CASCADE handles profiles)
    const { error: deleteUserError } = await supabaseAdmin.auth.admin.deleteUser(guestUserId)

    if (deleteUserError) {
      console.error('[merge-accounts] Error deleting guest user:', deleteUserError)
      throw new Error(`Failed to delete guest user: ${deleteUserError.message}`)
    }

    return new Response(JSON.stringify({ success: true, message: 'Accounts merged successfully.' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('[merge-accounts] Error:', message)
    return new Response(JSON.stringify({ success: false, error: message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})