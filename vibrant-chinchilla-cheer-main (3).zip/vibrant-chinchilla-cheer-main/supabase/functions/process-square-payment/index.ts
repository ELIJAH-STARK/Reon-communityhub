import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  // Handle CORS
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { sourceId, amount, itemType, userId } = await req.json()
    const squareToken = Deno.env.get('SQUARE_ACCESS_TOKEN')
    const locationId = Deno.env.get('SQUARE_LOCATION_ID')

    if (!squareToken || !locationId) {
      console.error("[process-square-payment] Configuration missing: SQUARE_ACCESS_TOKEN or SQUARE_LOCATION_ID");
      throw new Error('Server configuration error. Please check Supabase Secrets.');
    }

    console.log(`[process-square-payment] User ${userId} attempting to buy \${itemType} for $\${amount}`);

    // 1. Initialize Supabase Admin
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // 2. Execute Square Payment
    const paymentResponse = await fetch('https://connect.squareup.com/v2/payments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer \${squareToken}`,
        'Square-Version': '2023-12-13'
      },
      body: JSON.stringify({
        source_id: sourceId,
        idempotency_key: crypto.randomUUID(),
        amount_money: {
          amount: Math.round(amount * 100), // Square requires cents
          currency: 'USD'
        },
        location_id: locationId,
        note: `Community Hub Purchase: \${itemType} - User: \${userId}`
      })
    })

    const paymentData = await paymentResponse.json()
    
    if (!paymentResponse.ok) {
      console.error('[process-square-payment] Square Payment API error:', paymentData.errors);
      return new Response(JSON.stringify({ 
        success: false, 
        error: paymentData.errors?.[0]?.detail || 'Square payment rejected.' 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 400
      })
    }

    console.log(`[process-square-payment] Square Transaction Successful: \${paymentData.payment.id}`);

    // 3. Database Updates
    const now = new Date()
    const oneYearFromNow = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000)

    // A. Log Transaction
    await supabaseAdmin.from('transactions').insert({
      user_id: userId,
      amount: amount,
      item_type: itemType,
      square_transaction_id: paymentData.payment.id,
      status: 'completed'
    });

    // B. Handle Logic by Type
    if (itemType === 'premium') {
      await supabaseAdmin.from('profiles').update({
        is_premium: true,
        premium_until: oneYearFromNow.toISOString(),
        updated_at: now.toISOString()
      }).eq('id', userId);

      // Unhold everything
      await Promise.all([
        supabaseAdmin.from('goods').update({ is_held: false }).eq('user_id', userId),
        supabaseAdmin.from('services').update({ is_held: false }).eq('user_id', userId),
        supabaseAdmin.from('requests').update({ is_held: false }).eq('user_id', userId)
      ]);

      return new Response(JSON.stringify({ success: true, type: 'premium_granted' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    } 

    if (itemType === '1slot' || itemType === '4slot') {
      const slotsToAdd = itemType === '1slot' ? 1 : 4;

      // Log Slot Expiry
      await supabaseAdmin.from('slot_transactions').insert({
        user_id: userId,
        slot_count: slotsToAdd,
        expiry_date: oneYearFromNow.toISOString()
      });

      // Fetch all active slots to update profile total
      const { data: activeSlots } = await supabaseAdmin
        .from('slot_transactions')
        .select('slot_count')
        .eq('user_id', userId)
        .gt('expiry_date', now.toISOString());

      const totalActiveExtraSlots = (activeSlots || []).reduce((sum, t) => sum + t.slot_count, 0);

      // Update Profile Total
      await supabaseAdmin.from('profiles').update({
        extra_slots: totalActiveExtraSlots,
        updated_at: now.toISOString()
      }).eq('id', userId);

      // 4. Process "Unholding"
      const totalAllowed = 10 + totalActiveExtraSlots;
      
      const [hGoods, hServices, hRequests] = await Promise.all([
        supabaseAdmin.from('goods').select('id, created_at').eq('user_id', userId).eq('is_held', true),
        supabaseAdmin.from('services').select('id, created_at').eq('user_id', userId).eq('is_held', true),
        supabaseAdmin.from('requests').select('id, created_at').eq('user_id', userId).eq('is_held', true)
      ]);

      const allHeld = [
        ...(hGoods.data || []).map(i => ({ ...i, table: 'goods' })),
        ...(hServices.data || []).map(i => ({ ...i, table: 'services' })),
        ...(hRequests.data || []).map(i => ({ ...i, table: 'requests' }))
      ].sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());

      // Find out how many current non-held items we have
      const [{ count: gActive }, { count: sActive }, { count: rActive }] = await Promise.all([
        supabaseAdmin.from('goods').select('id', { count: 'exact', head: true }).eq('user_id', userId).eq('is_held', false),
        supabaseAdmin.from('services').select('id', { count: 'exact', head: true }).eq('user_id', userId).eq('is_held', false),
        supabaseAdmin.from('requests').select('id', { count: 'exact', head: true }).eq('user_id', userId).eq('is_held', false)
      ]);

      const currentActiveCount = (gActive || 0) + (sActive || 0) + (rActive || 0);
      const spaceLeft = totalAllowed - currentActiveCount;

      if (spaceLeft > 0) {
        const toUnhold = allHeld.slice(0, spaceLeft);
        await Promise.all(toUnhold.map(item => 
          supabaseAdmin.from(item.table).update({ is_held: false }).eq('id', item.id)
        ));
      }

      // Check for Streak Success (20 slots in 90 days)
      const ninetyDaysAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
      const { data: recentSlots } = await supabaseAdmin
        .from('slot_transactions')
        .select('slot_count')
        .eq('user_id', userId)
        .gte('created_at', ninetyDaysAgo.toISOString());

      const windowTotal = (recentSlots || []).reduce((sum, t) => sum + t.slot_count, 0);

      if (windowTotal >= 20) {
        await supabaseAdmin.from('profiles').update({
          is_premium: true,
          premium_until: oneYearFromNow.toISOString()
        }).eq('id', userId);

        return new Response(JSON.stringify({ success: true, type: 'premium_achieved' }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      return new Response(JSON.stringify({ success: true, type: 'slots_added' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    throw new Error('Invalid purchase type requested.');

  } catch (err: any) {
    console.error('[process-square-payment] Fatal Internal Error:', err.message);
    return new Response(JSON.stringify({ success: false, error: err.message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500
    });
  }
})