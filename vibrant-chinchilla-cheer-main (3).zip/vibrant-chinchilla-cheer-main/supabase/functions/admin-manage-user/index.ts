import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders })

  try {
    const { userId, action, banUntil, reason } = await req.json()
    
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    )

    // Verify calling user is an Admin
    const authHeader = req.headers.get('Authorization')
    const { data: { user: adminUser } } = await supabaseClient.auth.getUser(authHeader?.replace('Bearer ', '') ?? '')
    
    const { data: adminProfile } = await supabaseClient
      .from('profiles')
      .select('role')
      .eq('id', adminUser?.id)
      .single()

    if (adminProfile?.role !== 'admin') {
      console.warn("[admin-manage-user] Unauthorized attempt by user:", adminUser?.id);
      return new Response(JSON.stringify({ error: 'Unauthorized' }), { status: 403, headers: corsHeaders })
    }

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (action === 'ban') {
      console.log(`[admin-manage-user] Banning user \${userId}. Reason: \${reason}`);
      // 1. Update Profile
      await supabaseAdmin.from('profiles').update({
        is_banned: true,
        banned_until: banUntil,
        ban_reason: reason
      }).eq('id', userId)

      // 2. Lock Auth User
      await supabaseAdmin.auth.admin.updateUserById(userId, { 
        ban_duration: banUntil ? 'temporary' : 'none',
        app_metadata: { is_banned: true } 
      })
    } else if (action === 'unban') {
      console.log(`[admin-manage-user] Unbanning user \${userId}`);
      await supabaseAdmin.from('profiles').update({
        is_banned: false,
        banned_until: null,
        ban_reason: null
      }).eq('id', userId)
    }

    return new Response(JSON.stringify({ success: true }), { headers: corsHeaders })
  } catch (err: any) {
    console.error("[admin-manage-user] Fatal Error:", err.message);
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: corsHeaders })
  }
})