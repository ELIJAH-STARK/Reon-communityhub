import { serve } from "https://deno.land/std@0.190.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    console.log("[cleanup-idle-guests] Starting idle account cleanup (6-month threshold)...");

    // Calculate the threshold date (6 months ago)
    const thresholdDate = new Date();
    thresholdDate.setMonth(thresholdDate.getMonth() - 6);
    const thresholdISO = thresholdDate.toISOString();

    const { data: idleProfiles, error: fetchError } = await supabaseAdmin
      .from('profiles')
      .select('id')
      .lt('updated_at', thresholdISO);

    if (fetchError) throw fetchError;

    if (!idleProfiles || idleProfiles.length === 0) {
      return new Response(JSON.stringify({ message: "No idle accounts found to clean up." }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    let deletedCount = 0;
    const errors = [];

    for (const profile of idleProfiles) {
      const { data: { user }, error: getUserError } = await supabaseAdmin.auth.admin.getUserById(profile.id);
      
      if (getUserError) {
        console.error(`[cleanup-idle-guests] Error fetching user ${profile.id}:`, getUserError);
        continue;
      }

      if (user?.user_metadata?.is_guest === true) {
        const { error: deleteError } = await supabaseAdmin.auth.admin.deleteUser(profile.id);
        if (deleteError) {
          console.error(`[cleanup-idle-guests] Failed to delete user ${profile.id}:`, deleteError);
          errors.push({ id: profile.id, error: deleteError.message });
        } else {
          deletedCount++;
        }
      }
    }

    console.log(`[cleanup-idle-guests] Cleanup complete. Deleted ${deletedCount} idle guest accounts.`);

    return new Response(JSON.stringify({ 
      success: true, 
      deletedCount, 
      errors: errors.length > 0 ? errors : undefined 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    });

  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : String(err);
    console.error('[cleanup-idle-guests] Fatal Error:', message)
    return new Response(JSON.stringify({ success: false, error: message }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})