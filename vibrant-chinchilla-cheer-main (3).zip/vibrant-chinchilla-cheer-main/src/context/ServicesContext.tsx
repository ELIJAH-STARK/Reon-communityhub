"use client";
/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "./SessionContext";
import { toast } from "sonner";

interface UploadedService {
  id: string;
  name: string;
  description: string;
  category: string;
  image_url: string | null;
  additional_images: string[];
  latitude: number | null;
  longitude: number | null;
  user_id: string;
  status: string;
  price: number | null;
  discount_percentage: number | null;
  created_at?: string;
  is_provider_verified?: boolean;
  is_featured?: boolean;
  is_held?: boolean;
}

interface ServicesContextType {
  uploadedServices: UploadedService[];
  addService: (service: any, mainFile?: File, additionalFiles?: File[]) => Promise<void>;
  updateService: (id: string, service: any, mainFile?: File, additionalFiles?: File[]) => Promise<void>;
  deleteService: (id: string) => Promise<void>;
  toggleFeatured: (id: string, featured: boolean) => Promise<void>;
  loadingServices: boolean;
  errorServices: string | null;
  refreshServices: () => Promise<void>;
}

const ServicesContext = createContext<ServicesContextType | undefined>(undefined);

export const ServicesProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useSession();
  const [uploadedServices, setUploadedServices] = useState<UploadedService[]>([]);
  const [loadingServices, setLoadingServices] = useState(true);
  const [errorServices, setErrorServices] = useState<string | null>(null);
  const fetchCountRef = useRef(0);
  const isMountedRef = useRef(true);

  // Cleanup function to prevent state updates on unmounted components
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const fetchServices = useCallback(async () => {
    if (!isMountedRef.current) return;
    
    // Prevent overlapping fetches
    if (fetchCountRef.current > 0 && loadingServices) return;
    fetchCountRef.current++;
    setLoadingServices(true);
    setErrorServices(null);
    
    try {
      // Add timeout to prevent hanging requests
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout
      
      const { data, error } = await supabase
        .from('services')
        .select(`*, profiles(is_verified)`)
        .order('is_featured', { ascending: false })
        .order('created_at', { ascending: false });
      
      clearTimeout(timeoutId);
      
      if (error) throw error;
      if (!isMountedRef.current) return;
      
      const transformedData = data?.map(service => ({
        ...service,
        is_provider_verified: Array.isArray(service.profiles) 
          ? service.profiles[0]?.is_verified 
          : (service.profiles as any)?.is_verified || false
      })) || [];
      
      setUploadedServices(transformedData as UploadedService[]);
    } catch (error: any) {
      if (!isMountedRef.current) return;
      console.error("ServicesContext: Fetch error:", error.message);
      setErrorServices("Could not load services. Please try again.");
    } finally {
      if (isMountedRef.current) {
        setLoadingServices(false);
        fetchCountRef.current--;
      }
    }
  }, []);

  // Fetch services when component mounts or user changes
  useEffect(() => {
    console.log("ServicesContext: User changed. Fetching services. User:", user?.id);
    if (user) {
      fetchServices();
    } else {
      setUploadedServices([]);
      setLoadingServices(false);
    }
  }, [user]);

  const uploadImage = async (file: File, userId: string) => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/service_${Math.random()}.${fileExt}`;
    const filePath = `public/${fileName}`;
    
    const { error: uploadError } = await supabase.storage
      .from('item-images')
      .upload(filePath, file, {
        cacheControl: '3600'
      });
    
    if (uploadError) throw uploadError;
    
    const { data } = supabase.storage
      .from('item-images')
      .getPublicUrl(filePath);
    
    return data.publicUrl;
  };

  const addService = async (service: any, mainFile?: File, additionalFiles: File[] = []) => {
    if (!user) return;
    
    try {
      let mainUrl = null;
      if (mainFile) mainUrl = await uploadImage(mainFile, user.id);
      
      const additionalUrls = await Promise.all(
        additionalFiles.map(file => uploadImage(file, user.id))
      );
      
      const { data, error } = await supabase
        .from('services')
        .insert({
          ...service,
          user_id: user.id,
          image_url: mainUrl,
          additional_images: additionalUrls
        })
        .select();
      
      if (error) throw error;
      
      if (data) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('is_verified')
          .eq('id', user.id)
          .single();
        
        const newService = {
          ...data[0],
          is_provider_verified: profile?.is_verified || false
        } as UploadedService;
        
        setUploadedServices(prev => [newService, ...prev]);
      }
      
      toast.success(`"${service.name}" offered successfully!`);
    } catch (err: any) {
      toast.error("Failed to offer service: " + (err.message || String(err)));
      throw err;
    }
  };

  const updateService = async (id: string, service: any, mainFile?: File, additionalFiles?: File[]) => {
    if (!user) return;
    
    try {
      let mainUrl: string | undefined;
      if (mainFile) mainUrl = await uploadImage(mainFile, user.id);
      
      let additionalUrls: string[] | undefined;
      if (additionalFiles) {
        additionalUrls = await Promise.all(
          additionalFiles.map(file => uploadImage(file, user.id))
        );
      }
      
      const updatePayload = {
        ...service,
        ...(mainUrl && { image_url: mainUrl }),
        ...(additionalUrls && { additional_images: additionalUrls })
      };
      
      const { data, error } = await supabase
        .from('services')
        .update(updatePayload)
        .eq('id', id)
        .eq('user_id', user.id)
        .select();
      
      if (error) throw error;
      
      if (data) {
        setUploadedServices(prev => prev.map(s => 
          s.id === id ? { ...s, ...data[0] } as UploadedService : s
        ));
      }
      
      toast.success("Service updated!");
    } catch (err: any) {
      toast.error("Update failed: " + (err.message || String(err)));
      throw err;
    }
  };

  const deleteService = async (id: string) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('services')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);
      
      if (error) {
        toast.error("Deletion failed: " + error.message);
        throw error;
      } else {
        setUploadedServices(prev => prev.filter(s => s.id !== id));
        toast.success("Service deleted.");
      }
    } catch (err: any) {
      console.error("Delete service error:", err);
      throw err;
    }
  };

  const toggleFeatured = async (id: string, featured: boolean) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('services')
        .update({ is_featured: featured })
        .eq('id', id)
        .eq('user_id', user.id);
      
      if (error) {
        toast.error("Failed to update featured status.");
        throw error;
      } else {
        setUploadedServices(prev => prev.map(s => 
          s.id === id ? { ...s, is_featured: featured } : s
        ));
        toast.success(featured ? "Service is now featured! 🚀" : "Service removed from featured.");
      }
    } catch (err: any) {
      console.error("Toggle featured error:", err);
      throw err;
    }
  };

  return (
    <ServicesContext.Provider value={{ 
      uploadedServices, 
      addService, 
      updateService, 
      deleteService,
      toggleFeatured,
      loadingServices, 
      errorServices, 
      refreshServices: fetchServices 
    }}>
      {children}
    </ServicesContext.Provider>
  );
};

export const useServices = () => {
  const context = useContext(ServicesContext);
  if (context === undefined) throw new Error("useServices must be used within a ServicesProvider");
  return context;
};