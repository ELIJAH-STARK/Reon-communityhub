"use client";
/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface UserPreferences {
  accentColor: string;
  showFooter: boolean; // New preference for footer visibility
}

interface UserPreferencesContextType {
  preferences: UserPreferences;
  updateAccentColor: (color: string) => void;
  updateShowFooter: (show: boolean) => void; // New method to update footer visibility
}

const defaultPreferences: UserPreferences = {
  accentColor: "#f97316", // Default fiery coral color
  showFooter: true, // Default to showing footer
};

const UserPreferencesContext = createContext<UserPreferencesContextType | undefined>(undefined);

export const UserPreferencesProvider = ({ children }: { children: ReactNode }) => {
  const [preferences, setPreferences] = useState<UserPreferences>(defaultPreferences);

  useEffect(() => {
    // Load preferences from localStorage on initial render
    const savedPreferences = localStorage.getItem("userPreferences");
    if (savedPreferences) {
      try {
        const parsedPreferences = JSON.parse(savedPreferences);
        setPreferences(parsedPreferences);
      } catch (error) {
        console.error("Failed to parse user preferences from localStorage", error);
      }
    }
  }, []);

  useEffect(() => {
    // Save preferences to localStorage whenever they change
    localStorage.setItem("userPreferences", JSON.stringify(preferences));
  }, [preferences]);

  const updateAccentColor = (color: string) => {
    setPreferences(prev => ({ ...prev, accentColor: color }));
  };

  const updateShowFooter = (show: boolean) => {
    setPreferences(prev => ({ ...prev, showFooter: show }));
  };

  return (
    <UserPreferencesContext.Provider value={{ preferences, updateAccentColor, updateShowFooter }}>
      {children}
    </UserPreferencesContext.Provider>
  );
};

export const useUserPreferences = () => {
  const context = useContext(UserPreferencesContext);
  if (context === undefined) {
    throw new Error("useUserPreferences must be used within a UserPreferencesProvider");
  }
  return context;
};