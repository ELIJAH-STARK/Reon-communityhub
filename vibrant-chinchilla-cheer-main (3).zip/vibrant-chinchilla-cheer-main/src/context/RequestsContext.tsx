"use client";
/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "./SessionContext";
import { toast } from "sonner";

export interface Request {
  id: string;
  user_id: string;
  title: string;
  description: string;
  category: string;
  status: string;
  latitude: number | null;
  longitude: number | null;
  created_at: string;
  updated_at: string;
  is_featured?: boolean;
  is_held?: boolean;
  distance?: number;
}

interface RequestsContextType {
  requests: Request[];
  userRequests: Request[];
  addRequest: (request: Omit<Request, "id" | "user_id" | "created_at" | "updated_at">) => Promise<void>;
  updateRequest: (id: string, updates: Partial<Request>) => Promise<void>;
  deleteRequest: (id: string) => Promise<void>;
  toggleFeatured: (id: string, featured: boolean) => Promise<void>;
  loading: boolean;
  error: string | null;
  refreshRequests: () => Promise<void>;
}

const RequestsContext = createContext<RequestsContextType | undefined>(undefined);

export const RequestsProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useSession();
  const [requests, setRequests] = useState<Request[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRequests = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const { data, error: fetchError } = await supabase
        .from('requests')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (fetchError) throw fetchError;
      
      setRequests(data as Request[]);
    } catch (err: any) {
      console.error("[RequestsContext] Fetch error:", err.message);
      setError("Failed to load requests");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRequests();
    
    const channel = supabase
      .channel('requests_changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'requests' },
        (payload) => {
          fetchRequests();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchRequests]);

  const userRequests = requests.filter(request => request.user_id === user?.id);

  const addRequest = async (request: Omit<Request, "id" | "user_id" | "created_at" | "updated_at">) => {
    if (!user) return;
    
    try {
      const { data, error: insertError } = await supabase
        .from('requests')
        .insert({
          ...request,
          user_id: user.id,
        })
        .select()
        .single();
      
      if (insertError) throw insertError;
      
      // Immediately update the local state
      setRequests(prev => [data as Request, ...prev]);
      toast.success("Request created successfully!");
    } catch (err: any) {
      toast.error("Failed to create request: " + err.message);
      throw err;
    }
  };

  const updateRequest = async (id: string, updates: Partial<Request>) => {
    if (!user) return;
    
    try {
      const { data, error: updateError } = await supabase
        .from('requests')
        .update({
          ...updates,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)
        .eq('user_id', user.id)
        .select()
        .single();
      
      if (updateError) throw updateError;
      
      // Immediately update the local state
      setRequests(prev => prev.map(req => req.id === id ? { ...req, ...data } : req));
      toast.success("Request updated successfully!");
    } catch (err: any) {
      toast.error("Failed to update request: " + err.message);
      throw err;
    }
  };

  const deleteRequest = async (id: string) => {
    if (!user) return;
    
    try {
      const { error: deleteError } = await supabase
        .from('requests')
        .delete()
        .eq('id', id)
        .eq('user_id', user.id);
      
      if (deleteError) throw deleteError;
      
      // Immediately update the local state
      setRequests(prev => prev.filter(req => req.id !== id));
      toast.success("Request deleted successfully!");
    } catch (err: any) {
      toast.error("Failed to delete request: " + err.message);
      throw err;
    }
  };

  const toggleFeatured = async (id: string, featured: boolean) => {
    if (!user) return;
    
    try {
      const { error } = await supabase
        .from('requests')
        .update({ is_featured: featured })
        .eq('id', id)
        .eq('user_id', user.id);
      
      if (error) throw error;
      
      setRequests(prev => prev.map(req => req.id === id ? { ...req, is_featured: featured } : req));
      toast.success(featured ? "Request featured on Home! " : "Featured removed.");
    } catch (err: any) {
      toast.error("Failed to update featured status.");
      throw err;
    }
  };

  return (
    <RequestsContext.Provider value={{ 
      requests, 
      userRequests, 
      addRequest, 
      updateRequest, 
      deleteRequest, 
      toggleFeatured,
      loading, 
      error, 
      refreshRequests: fetchRequests 
    }}>
      {children}
    </RequestsContext.Provider>
  );
};

export const useRequests = () => {
  const context = useContext(RequestsContext);
  if (context === undefined) {
    throw new Error("useRequests must be used within a RequestsProvider");
  }
  return context;
};