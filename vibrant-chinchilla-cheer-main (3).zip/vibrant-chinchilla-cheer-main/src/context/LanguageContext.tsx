import React, { createContext, useContext, useEffect, useState } from 'react';
import en from '../locales/en.json';
import es from '../locales/es.json';
import fr from '../locales/fr.json';
import de from '../locales/de.json';
import ja from '../locales/ja.json';
import ru from '../locales/ru.json';
import zhCn from '../locales/zh-cn.json';
import hi from '../locales/hi.json';
import it from '../locales/it.json';
import ar from '../locales/ar.json';

export type Language = 'en' | 'es' | 'fr' | 'de' | 'ja' | 'ru' | 'zh-cn' | 'hi' | 'it' | 'ar';

interface Translations {
  [key: string]: any;
}

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, defaultValue?: string) => string;
  translations: Translations;
}

const translations: Record<Language, Translations> = {
  en,
  es,
  fr,
  de,
  ja,
  ru,
  'zh-cn': zhCn,
  hi,
  it,
  ar,
};

const LANGUAGE_STORAGE_KEY = 'app_language';
const SUPPORTED_LANGUAGES: Language[] = ['en', 'es', 'fr', 'de', 'ja', 'ru', 'zh-cn', 'hi', 'it', 'ar'];

// Detect language from browser Accept-Language header
const detectBrowserLanguage = (): Language => {
  // First, check if user has a saved preference
  const savedLanguage = localStorage.getItem(LANGUAGE_STORAGE_KEY);
  if (savedLanguage && SUPPORTED_LANGUAGES.includes(savedLanguage as Language)) {
    return savedLanguage as Language;
  }

  // Try to detect from browser language
  const browserLang = navigator.language.toLowerCase();
  
  // Check exact match first
  if (SUPPORTED_LANGUAGES.includes(browserLang as Language)) {
    return browserLang as Language;
  }

  // Check language prefix (e.g., 'en' from 'en-US')
  const langPrefix = browserLang.split('-')[0];
  const matchedLang = SUPPORTED_LANGUAGES.find(lang => lang.startsWith(langPrefix));
  if (matchedLang) {
    return matchedLang;
  }

  // Check Accept-Language header if available
  if (navigator.languages && navigator.languages.length > 0) {
    for (const lang of navigator.languages) {
      const cleanLang = lang.toLowerCase();
      if (SUPPORTED_LANGUAGES.includes(cleanLang as Language)) {
        return cleanLang as Language;
      }
      const prefix = cleanLang.split('-')[0];
      const prefixMatch = SUPPORTED_LANGUAGES.find(l => l.startsWith(prefix));
      if (prefixMatch) {
        return prefixMatch;
      }
    }
  }

  // Fallback to English
  return 'en';
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => detectBrowserLanguage());

  // Save language preference to localStorage when it changes
  const setLanguage = (lang: Language) => {
    if (SUPPORTED_LANGUAGES.includes(lang)) {
      setLanguageState(lang);
      localStorage.setItem(LANGUAGE_STORAGE_KEY, lang);
    }
  };

  // Get nested translation value using dot notation (e.g., "common.home")
  const getNestedTranslation = (obj: any, path: string): string => {
    const keys = path.split('.');
    let value = obj;
    
    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return path; // Return the key path if translation not found
      }
    }
    
    return typeof value === 'string' ? value : path;
  };

  // Translation helper function
  const t = (key: string, defaultValue?: string): string => {
    const translation = getNestedTranslation(translations[language], key);
    
    // If translation not found in current language, try English as fallback
    if (translation === key && language !== 'en') {
      const fallback = getNestedTranslation(translations['en'], key);
      return fallback === key ? (defaultValue || key) : fallback;
    }
    
    return translation === key ? (defaultValue || key) : translation;
  };

  const value: LanguageContextType = {
    language,
    setLanguage,
    t,
    translations: translations[language],
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

export default LanguageContext;
