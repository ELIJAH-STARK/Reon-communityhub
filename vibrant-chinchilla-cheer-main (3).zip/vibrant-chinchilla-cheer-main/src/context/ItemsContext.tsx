"use client";
/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "./SessionContext";
import { toast } from "sonner";

export interface UploadedItem {
  id: string;
  name: string;
  description: string;
  category: string;
  image_url: string;
  additional_images: string[];
  latitude: number | null;
  longitude: number | null;
  user_id: string;
  status: string;
  price: number | null;
  discount_percentage: number | null;
  created_at?: string;
  is_seller_verified?: boolean;
  is_featured?: boolean;
  is_held?: boolean;
  similarity?: number;
}

interface ItemsContextType {
  uploadedItems: UploadedItem[];
  addItem: (item: any, mainFile: File, additionalFiles?: File[]) => Promise<void>;
  updateItem: (id: string, updates: any, mainFile?: File, newAdditionalFiles?: File[], remainingUrls?: string[]) => Promise<void>;
  deleteItem: (id: string) => Promise<void>;
  applyBulkDiscount: (itemIds: string[], discountPercentage: number | null) => Promise<void>;
  toggleFeatured: (id: string, featured: boolean) => Promise<void>;
  performSmartSearch: (query: string) => Promise<UploadedItem[]>;
  loadingItems: boolean;
  errorItems: string | null;
  refreshItems: () => Promise<void>;
}

const ItemsContext = createContext<ItemsContextType | undefined>(undefined);

export const ItemsProvider = ({ children }: { children: ReactNode }) => {
  const { user, loading: sessionLoading } = useSession();
  const [uploadedItems, setUploadedItems] = useState<UploadedItem[]>([]);
  const [loadingItems, setLoadingItems] = useState(true);
  const [errorItems, setErrorItems] = useState<string | null>(null);
  const isMounted = useRef(true);

  useEffect(() => {
    return () => { isMounted.current = false; };
  }, []);

  const fetchItems = useCallback(async () => {
    if (!isMounted.current) return;
    setLoadingItems(true);
    setErrorItems(null);
    
    try {
      const { data, error } = await supabase
        .from('goods')
        .select(`*, profiles(is_verified)`)
        .order('is_featured', { ascending: false })
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      const transformedData = data?.map(item => ({
        ...item,
        additional_images: item.additional_images || [],
        is_seller_verified: (item.profiles as any)?.is_verified || false
      })) || [];
      
      if (isMounted.current) setUploadedItems(transformedData as UploadedItem[]);
    } catch (error: any) {
      console.error("[ItemsContext] Fetch error:", error.message);
      if (isMounted.current) setErrorItems("Trouble reaching the community hub.");
    } finally {
      if (isMounted.current) setLoadingItems(false);
    }
  }, []);

  useEffect(() => {
    if (!sessionLoading) {
      if (user) fetchItems();
      else {
        setUploadedItems([]);
        setLoadingItems(false);
      }
    }
  }, [user, sessionLoading, fetchItems]);

  const generateEmbedding = async (text: string) => {
    try {
      const { data, error } = await supabase.functions.invoke('ai-search', {
        body: { text }
      });
      if (error) throw error;
      return data.embedding;
    } catch (err) {
      console.warn("AI Embedding failed, listing will only be searchable by text.", err);
      return null;
    }
  };

  const uploadFile = async (file: File, userId: string) => {
    const fileExt = file.name.split('.').pop();
    const fileName = `${userId}/${Math.random()}.${fileExt}`;
    const filePath = `public/${fileName}`;
    const { error } = await supabase.storage.from('item-images').upload(filePath, file);
    if (error) throw error;
    const { data } = supabase.storage.from('item-images').getPublicUrl(filePath);
    return data.publicUrl;
  };

  const addItem = async (item: any, mainFile: File, additionalFiles: File[] = []) => {
    if (!user) return;
    try {
      const mainUrl = await uploadFile(mainFile, user.id);
      const additionalUrls = await Promise.all(additionalFiles.map(f => uploadFile(f, user.id)));
      
      // AI: Generate meaning for smart search
      const embeddingText = `${item.name} ${item.category} ${item.description}`;
      const embedding = await generateEmbedding(embeddingText);

      const { data, error } = await supabase.from('goods').insert({
        ...item,
        user_id: user.id,
        image_url: mainUrl,
        additional_images: additionalUrls,
        embedding: embedding
      }).select();
      
      if (error) throw error;
      if (data) fetchItems();
      toast.success(`Shared "${item.name}"!`);
    } catch (err: any) {
      toast.error("Upload failed.");
    }
  };

  const updateItem = async (id: string, updates: any, mainFile?: File, newAdditionalFiles: File[] = [], remainingUrls: string[] = []) => {
    if (!user) return;
    try {
      let mainUrl = updates.image_url;
      if (mainFile) mainUrl = await uploadFile(mainFile, user.id);

      const newUploadedUrls = await Promise.all(newAdditionalFiles.map(f => uploadFile(f, user.id)));
      const finalAdditionalImages = [...remainingUrls, ...newUploadedUrls];

      // AI: Re-generate meaning if name/desc changed
      const embeddingText = `${updates.name} ${updates.category} ${updates.description}`;
      const embedding = await generateEmbedding(embeddingText);

      const { error } = await supabase
        .from('goods')
        .update({
          ...updates,
          image_url: mainUrl,
          additional_images: finalAdditionalImages,
          embedding: embedding
        })
        .eq('id', id)
        .eq('user_id', user.id);

      if (error) throw error;
      fetchItems();
      toast.success("Item updated!");
    } catch (err: any) {
      toast.error("Update failed.");
    }
  };

  const performSmartSearch = async (query: string): Promise<UploadedItem[]> => {
    try {
      const embedding = await generateEmbedding(query);
      if (!embedding) return [];

      const { data, error } = await supabase.rpc('match_goods', {
        query_embedding: embedding,
        match_threshold: 0.5,
        match_count: 20
      });

      if (error) throw error;
      return data || [];
    } catch (err) {
      console.error("Smart search failed:", err);
      return [];
    }
  };

  const deleteItem = async (id: string) => {
    const { error } = await supabase.from('goods').delete().eq('id', id);
    if (error) throw error;
    setUploadedItems(prev => prev.filter(i => i.id !== id));
    toast.success("Item deleted.");
  };

  const toggleFeatured = async (id: string, featured: boolean) => {
    const { error } = await supabase.from('goods').update({ is_featured: featured }).eq('id', id);
    if (error) throw error;
    setUploadedItems(prev => prev.map(i => i.id === id ? { ...i, is_featured: featured } : i));
    toast.success(featured ? "Item featured on Home! ✨" : "Featured removed.");
  };

  const applyBulkDiscount = async (itemIds: string[], discount: number | null) => {
    const { error } = await supabase.from('goods').update({ discount_percentage: discount }).in('id', itemIds);
    if (error) throw error;
    fetchItems();
    toast.success("Bulk update applied!");
  };

  return (
    <ItemsContext.Provider value={{ 
      uploadedItems, addItem, updateItem, deleteItem, applyBulkDiscount, toggleFeatured, performSmartSearch,
      loadingItems, errorItems, refreshItems: fetchItems 
    }}>
      {children}
    </ItemsContext.Provider>
  );
};

export const useItems = () => {
  const context = useContext(ItemsContext);
  if (context === undefined) throw new Error("useItems context not found");
  return context;
};