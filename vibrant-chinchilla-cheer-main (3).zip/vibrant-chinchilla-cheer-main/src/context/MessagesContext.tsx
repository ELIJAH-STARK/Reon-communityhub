"use client";
/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "./SessionContext";
import { toast } from "sonner";

interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  content: string;
  item_id: string | null;
  service_id: string | null;
  is_read: boolean;
  created_at: string;
}

interface Conversation {
  id: string;
  otherUserId: string;
  otherUserName: string;
  otherUserAvatar: string | null;
  lastMessageContent: string;
  lastMessageTime: string;
  lastMessageSenderId: string;
  lastMessageIsRead: boolean;
  unreadCount: number;
  itemId: string | null;
  itemName: string | null;
  itemImageUrl: string | null;
  serviceId: string | null;
  serviceName: string | null;
}

interface MessagesContextType {
  messages: Message[];
  conversations: Conversation[];
  loadingMessages: boolean;
  loadingConversations: boolean;
  errorMessages: string | null;
  sendMessage: (receiverId: string, content: string, itemId?: string, serviceId?: string) => Promise<void>;
  fetchMessagesForConversation: (otherUserId: string, itemId?: string, serviceId?: string) => Promise<void>;
  markAsRead: (otherUserId: string, itemId?: string, serviceId?: string) => Promise<void>;
  fetchConversations: () => Promise<void>;
  deleteConversation: (otherUserId: string, itemId?: string, serviceId?: string) => Promise<void>;
}

const MessagesContext = createContext<MessagesContextType | undefined>(undefined);

export const MessagesProvider = ({ children }: { children: ReactNode }) => {
  const { user, session, profile } = useSession();
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [loadingConversations, setLoadingConversations] = useState(false);
  const [errorMessages, setErrorMessages] = useState<string | null>(null);
  const activeFilters = useRef<{ otherUserId: string; itemId?: string; serviceId?: string } | null>(null);

  const fetchConversations = useCallback(async () => {
    if (!user) {
      setConversations([]);
      return;
    }

    setLoadingConversations(true);

    try {
      const { data: rawMessages, error: messagesError } = await supabase
        .from('messages')
        .select(`id, sender_id, receiver_id, content, item_id, service_id, is_read, created_at`)
        .or(`sender_id.eq.${user.id},receiver_id.eq.${user.id}`)
        .order('created_at', { ascending: false });

      if (messagesError) throw messagesError;

      if (!rawMessages || rawMessages.length === 0) {
        setConversations([]);
        return;
      }

      const uniqueUserIds = new Set<string>();
      const uniqueItemIds = new Set<string>();
      const uniqueServiceIds = new Set<string>();

      rawMessages.forEach(msg => {
        uniqueUserIds.add(msg.sender_id);
        uniqueUserIds.add(msg.receiver_id);
        if (msg.item_id) uniqueItemIds.add(msg.item_id);
        if (msg.service_id) uniqueServiceIds.add(msg.service_id);
      });

      const [profilesRes, itemsRes, servicesRes] = await Promise.all([
        supabase.from('profiles').select('id, username, first_name, last_name, avatar_url').in('id', Array.from(uniqueUserIds)),
        uniqueItemIds.size > 0 ? supabase.from('goods').select('id, name, image_url').in('id', Array.from(uniqueItemIds)) : Promise.resolve({ data: [] }),
        uniqueServiceIds.size > 0 ? supabase.from('services').select('id, name').in('id', Array.from(uniqueServiceIds)) : Promise.resolve({ data: [] })
      ]);

      const profilesMap = new Map(profilesRes.data?.map(p => [p.id, p]));
      const itemsMap = new Map(itemsRes.data?.map(i => [i.id, i]));
      const servicesMap = new Map(servicesRes.data?.map(s => [s.id, s]));

      const conversationMap = new Map<string, Conversation>();

      rawMessages.forEach((msg) => {
        const otherUserId = msg.sender_id === user.id ? msg.receiver_id : msg.sender_id;
        const otherUserProfile = profilesMap.get(otherUserId);
        
        const otherUserName = otherUserProfile?.username || 
                             [otherUserProfile?.first_name, otherUserProfile?.last_name].filter(Boolean).join(' ') || 
                             "Neighbor";

        const itemId = msg.item_id;
        const serviceId = msg.service_id;
        const conversationKey = `${otherUserId}_${itemId || 'null'}_${serviceId || 'null'}`;
        const isUnread = !msg.is_read && msg.receiver_id === user.id;

        if (!conversationMap.has(conversationKey)) {
          conversationMap.set(conversationKey, {
            id: conversationKey,
            otherUserId,
            otherUserName,
            otherUserAvatar: otherUserProfile?.avatar_url || null,
            lastMessageContent: msg.content,
            lastMessageTime: msg.created_at,
            lastMessageSenderId: msg.sender_id,
            lastMessageIsRead: msg.is_read,
            unreadCount: isUnread ? 1 : 0,
            itemId,
            itemName: itemId ? itemsMap.get(itemId)?.name || null : null,
            itemImageUrl: itemId ? itemsMap.get(itemId)?.image_url || null : null,
            serviceId,
            serviceName: serviceId ? servicesMap.get(serviceId)?.name || null : null,
          });
        } else if (isUnread) {
          const conv = conversationMap.get(conversationKey)!;
          conv.unreadCount += 1;
        }
      });

      setConversations(Array.from(conversationMap.values()));
    } catch (err) {
      console.error("[MessagesContext] Failed to fetch conversations:", err);
    } finally {
      setLoadingConversations(false);
    }
  }, [user]);

  const fetchMessagesForConversation = useCallback(async (otherUserId: string, itemId?: string, serviceId?: string) => {
    if (!user) {
      setMessages([]);
      return;
    }

    setLoadingMessages(true);
    setErrorMessages(null);
    activeFilters.current = { otherUserId, itemId, serviceId };

    try {
      let query = supabase
        .from('messages')
        .select('*')
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${user.id})`)
        .order('created_at', { ascending: true });

      if (itemId && itemId !== '_') {
        query = query.eq('item_id', itemId);
      } else if (serviceId && serviceId !== '_') {
        query = query.eq('service_id', serviceId);
      } else {
        query = query.is('item_id', null).is('service_id', null);
      }

      const { data, error } = await query;
      if (error) throw error;

      setMessages(data as Message[]);
    } catch (err) {
      setErrorMessages("Connection trouble. Unable to load messages.");
    } finally {
      setLoadingMessages(false);
    }
  }, [user]);

  const markAsRead = useCallback(async (otherUserId: string, itemId?: string, serviceId?: string) => {
    if (!user) return;

    try {
      let messageQuery = supabase
        .from('messages')
        .update({ is_read: true })
        .eq('sender_id', otherUserId)
        .eq('receiver_id', user.id)
        .eq('is_read', false);

      if (itemId && itemId !== '_') {
        messageQuery = messageQuery.eq('item_id', itemId);
      } else if (serviceId && serviceId !== '_') {
        messageQuery = messageQuery.eq('service_id', serviceId);
      } else {
        messageQuery = messageQuery.is('item_id', null).is('service_id', null);
      }

      await messageQuery;

      const chatLink = itemId && itemId !== '_'
        ? `/chat/${otherUserId}/${itemId}` 
        : serviceId && serviceId !== '_'
          ? `/chat/${otherUserId}/_/${serviceId}` 
          : `/chat/${otherUserId}`;

      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('user_id', user.id)
        .eq('type', 'message')
        .eq('link', chatLink)
        .eq('is_read', false);

      fetchConversations();
    } catch (err) {
      // Fail silently
    }
  }, [user, fetchConversations]);

  const sendMessage = useCallback(async (receiverId: string, content: string, itemId?: string, serviceId?: string) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('messages')
        .insert({
          sender_id: user.id,
          receiver_id: receiverId,
          content: content.trim(),
          item_id: (itemId && itemId !== '_') ? itemId : null,
          service_id: (serviceId && serviceId !== '_') ? serviceId : null,
          is_read: false,
        })
        .select();

      if (error) throw error;

      if (data) {
        const newMessage = data[0] as Message;
        setMessages(prev => [...prev, newMessage]);

        const senderName = profile?.username || user.user_metadata?.first_name || 'Neighbor';

        await supabase.from('notifications').insert({
          user_id: receiverId,
          type: 'message',
          title: 'New Message',
          content: `New message from ${senderName}.`,
          link: itemId && itemId !== '_'
            ? `/chat/${user.id}/${itemId}` 
            : serviceId && serviceId !== '_'
              ? `/chat/${user.id}/_/${serviceId}` 
              : `/chat/${user.id}`,
        });

        fetchConversations();
      }
    } catch (err) {
      toast.error("Message delivery failed.");
      throw err;
    }
  }, [user, profile, fetchConversations]);

  const deleteConversation = useCallback(async (otherUserId: string, itemId?: string, serviceId?: string) => {
    if (!user) return;

    try {
      let query = supabase
        .from('messages')
        .delete()
        .or(`and(sender_id.eq.${user.id},receiver_id.eq.${otherUserId}),and(sender_id.eq.${otherUserId},receiver_id.eq.${user.id})`);

      if (itemId && itemId !== '_') {
        query = query.eq('item_id', itemId);
      } else if (serviceId && serviceId !== '_') {
        query = query.eq('service_id', serviceId);
      } else {
        query = query.is('item_id', null).is('service_id', null);
      }

      const { error } = await query;
      if (error) throw error;

      toast.success("Conversation deleted.");
      fetchConversations();
    } catch (err) {
      toast.error("Failed to delete conversation.");
    }
  }, [user, fetchConversations]);

  useEffect(() => {
    if (session && user) {
      fetchConversations();

      const messageChannel = supabase
        .channel(`user-messages-${user.id}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'messages',
        }, (payload) => {
          const msg = (payload.new as Message) || (payload.old as Message);
          
          if (msg && (msg.sender_id === user.id || msg.receiver_id === user.id)) {
            fetchConversations();
            
            if (activeFilters.current) {
              const { otherUserId, itemId, serviceId } = activeFilters.current;
              const changedMessage = (payload.new as Message) || (payload.old as Message);
              
              const isFromOther = changedMessage.sender_id === otherUserId && changedMessage.receiver_id === user.id;
              const isToOther = changedMessage.sender_id === user.id && changedMessage.receiver_id === otherUserId;
              
              const matchesItem = (itemId && changedMessage.item_id === itemId) || (!itemId && !changedMessage.item_id);
              const matchesService = (serviceId && changedMessage.service_id === serviceId) || (!serviceId && !changedMessage.service_id);
              
              if ((isFromOther || isToOther) && matchesItem && matchesService) {
                if (payload.eventType === 'INSERT') {
                  setMessages(prev => {
                    if (prev.some(m => m.id === changedMessage.id)) return prev;
                    return [...prev, changedMessage];
                  });
                } else if (payload.eventType === 'UPDATE') {
                  setMessages(prev => prev.map(m => m.id === changedMessage.id ? changedMessage : m));
                } else if (payload.eventType === 'DELETE') {
                  setMessages(prev => prev.filter(m => m.id !== changedMessage.id));
                }
              }
            }
          }
        })
        .subscribe();

      return () => {
        supabase.removeChannel(messageChannel);
      };
    }
  }, [session, user, fetchConversations]);

  return (
    <MessagesContext.Provider value={{
      messages,
      conversations,
      loadingMessages,
      loadingConversations,
      errorMessages,
      sendMessage,
      fetchMessagesForConversation,
      markAsRead,
      fetchConversations,
      deleteConversation
    }}>
      {children}
    </MessagesContext.Provider>
  );
};

export const useMessages = () => {
  const context = useContext(MessagesContext);
  if (context === undefined) throw new Error("useMessages must be used within a MessagesProvider");
  return context;
};