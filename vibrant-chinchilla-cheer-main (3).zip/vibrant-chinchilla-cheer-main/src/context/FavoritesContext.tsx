"use client";
/* eslint-disable react-refresh/only-export-components */

import React, { createContext, useState, useContext, ReactNode, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "./SessionContext";
import { toast } from "sonner";

interface Favorite {
  id: string;
  user_id: string;
  item_id: string | null;
  service_id: string | null;
  created_at: string;
}

interface FavoritesContextType {
  favorites: Favorite[];
  isFavorited: (id: string, type: 'item' | 'service') => boolean;
  toggleFavorite: (id: string, type: 'item' | 'service') => Promise<void>;
  loadingFavorites: boolean;
}

const FavoritesContext = createContext<FavoritesContextType | undefined>(undefined);

export const FavoritesProvider = ({ children }: { children: ReactNode }) => {
  const { user, session } = useSession();
  const [favorites, setFavorites] = useState<Favorite[]>([]);
  const [loadingFavorites, setLoadingFavorites] = useState(false);

  const fetchFavorites = useCallback(async () => {
    if (!user) {
      setFavorites([]);
      return;
    }
    setLoadingFavorites(true);
    
    const { data, error } = await supabase
      .from('favorites')
      .select('*')
      .eq('user_id', user.id);
      
    if (error) {
      console.error("Error fetching favorites:", error);
    } else {
      setFavorites(data as Favorite[]);
    }
    setLoadingFavorites(false);
  }, [user]);

  useEffect(() => {
    if (session && user) {
      fetchFavorites();
    } else {
      setFavorites([]);
    }
  }, [session, user, fetchFavorites]);

  const isFavorited = (id: string, type: 'item' | 'service') => {
    return favorites.some(fav => 
      type === 'item' ? fav.item_id === id : fav.service_id === id
    );
  };

  const toggleFavorite = async (id: string, type: 'item' | 'service') => {
    if (!user) {
      toast.error("Please log in to favorite items.");
      return;
    }
    
    const existingFav = favorites.find(fav => 
      type === 'item' ? fav.item_id === id : fav.service_id === id
    );
    
    if (existingFav) {
      // Remove favorite
      const { error } = await supabase
        .from('favorites')
        .delete()
        .eq('id', existingFav.id);
        
      if (error) {
        toast.error("Failed to remove favorite.");
      } else {
        setFavorites(prev => prev.filter(fav => fav.id !== existingFav.id));
        toast.success("Removed from favorites.");
      }
    } else {
      // Add favorite
      const newFavData = type === 'item' 
        ? { user_id: user.id, item_id: id } 
        : { user_id: user.id, service_id: id };
        
      const { data, error } = await supabase
        .from('favorites')
        .insert(newFavData)
        .select()
        .single();
        
      if (error) {
        toast.error("Failed to add favorite.");
      } else if (data) {
        setFavorites(prev => [...prev, data as Favorite]);
        toast.success("Added to favorites!");
      }
    }
  };

  return (
    <FavoritesContext.Provider value={{ 
      favorites, 
      isFavorited, 
      toggleFavorite, 
      loadingFavorites 
    }}>
      {children}
    </FavoritesContext.Provider>
  );
};

export const useFavorites = () => {
  const context = useContext(FavoritesContext);
  if (context === undefined) {
    throw new Error("useFavorites must be used within a FavoritesProvider");
  }
  return context;
};