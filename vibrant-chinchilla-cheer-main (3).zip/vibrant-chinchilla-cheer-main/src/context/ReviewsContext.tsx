"use client";
/* eslint-disable react-refresh/only-export-components */

import React, { createContext, useState, useContext, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "./SessionContext";
import { toast } from "sonner";

interface Review {
  id: string;
  reviewer_id: string;
  reviewee_id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  reviewer_profile?: {
    username: string | null;
    first_name: string | null;
    last_name: string | null;
    avatar_url: string | null;
  };
}

interface ReviewsContextType {
  fetchReviewsForUser: (userId: string) => Promise<Review[]>;
  addReview: (revieweeId: string, rating: number, comment: string) => Promise<void>;
  calculateAverageRating: (reviews: Review[]) => number;
}

const ReviewsContext = createContext<ReviewsContextType | undefined>(undefined);

export const ReviewsProvider = ({ children }: { children: ReactNode }) => {
  const { user } = useSession();

  const fetchReviewsForUser = useCallback(async (userId: string) => {
    // We join the profiles table using the explicit relationship name
    const { data, error } = await supabase
      .from('reviews')
      .select(`
        id,
        reviewer_id,
        reviewee_id,
        rating,
        comment,
        created_at,
        reviewer_profile:profiles!reviewer_id (
          username,
          first_name,
          last_name,
          avatar_url
        )
      `)
      .eq('reviewee_id', userId)
      .order('created_at', { ascending: false });
      
    if (error) {
      console.error("[ReviewsContext] Fetch error:", error.message);
      return [];
    }

    return (data || []) as Review[];
  }, []);

  const addReview = async (revieweeId: string, rating: number, comment: string) => {
    if (!user) {
      toast.error("You must be logged in to leave a review.");
      return;
    }
    
    if (user.id === revieweeId) {
      toast.info("You cannot review yourself.");
      return;
    }
    
    const { error } = await supabase
      .from('reviews')
      .insert({
        reviewer_id: user.id,
        reviewee_id: revieweeId,
        rating,
        comment,
      });
      
    if (error) {
      console.error("[ReviewsContext] Insert error:", error.message);
      toast.error("Failed to submit review.");
      throw error;
    }
    
    // Add notification for the reviewee
    await supabase.from('notifications').insert({
      user_id: revieweeId,
      type: 'review',
      title: 'New Review',
      content: `${user.user_metadata.username || 'A neighbor'} left you a ${rating}-star review!`,
      link: '/profile',
    });
    
    toast.success("Review submitted!");
  };

  const calculateAverageRating = (reviews: Review[]) => {
    if (!reviews || reviews.length === 0) return 0;
    const sum = reviews.reduce((acc, review) => acc + review.rating, 0);
    return sum / reviews.length;
  };

  return (
    <ReviewsContext.Provider value={{ 
      fetchReviewsForUser, 
      addReview, 
      calculateAverageRating 
    }}>
      {children}
    </ReviewsContext.Provider>
  );
};

export const useReviews = () => {
  const context = useContext(ReviewsContext);
  if (context === undefined) {
    throw new Error("useReviews must be used within a ReviewsProvider");
  }
  return context;
};