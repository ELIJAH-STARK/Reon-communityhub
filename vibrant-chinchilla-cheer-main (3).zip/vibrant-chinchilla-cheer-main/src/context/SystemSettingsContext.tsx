import React, { createContext, useContext, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface SystemSettings {
  premiumEnabled: boolean;
}

interface SystemSettingsContextType {
  settings: SystemSettings;
  isLoading: boolean;
}

const SystemSettingsContext = createContext<SystemSettingsContextType | undefined>(undefined);

export const SystemSettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<SystemSettings>({ premiumEnabled: true });

  const { data: queryData, isLoading } = useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from("site_settings")
          .select("*")
          .single();

        if (error && error.code !== "PGRST116") {
          console.error("Error fetching settings:", error);
          return { premium_enabled: true };
        }

        return data || { premium_enabled: true };
      } catch (err) {
        console.error("Error in SystemSettingsProvider:", err);
        return { premium_enabled: true };
      }
    },
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Subscribe to real-time updates using modern v2 syntax
  useEffect(() => {
    const channel = supabase
      .channel('system_settings_realtime')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'site_settings'
        },
        (payload) => {
          if (payload.new) {
            setSettings({
              premiumEnabled: (payload.new as any).premium_enabled ?? true,
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  useEffect(() => {
    if (queryData) {
      setSettings({
        premiumEnabled: queryData.premium_enabled ?? true,
      });
    }
  }, [queryData]);

  return (
    <SystemSettingsContext.Provider value={{ settings, isLoading }}>
      {children}
    </SystemSettingsContext.Provider>
  );
};

export const useSystemSettingsContext = () => {
  const context = useContext(SystemSettingsContext);
  if (!context) {
    throw new Error("useSystemSettingsContext must be used within SystemSettingsProvider");
  }
  return context;
};