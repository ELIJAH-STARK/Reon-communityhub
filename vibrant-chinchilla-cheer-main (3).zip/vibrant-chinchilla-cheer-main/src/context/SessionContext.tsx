"use client";
/* eslint-disable react-refresh/only-export-components */
import React, { createContext, useContext, useState, useEffect, ReactNode, useCallback, useRef } from "react";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";
import { useNavigate } from "react-router-dom";

interface Profile {
  id: string;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  avatar_url: string | null;
  is_premium: boolean;
  role: string;
  is_banned: boolean;
  extra_slots: number;
}

interface SessionContextType {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  isGuest: boolean;
  isPremium: boolean;
  isAdmin: boolean;
  previousGuestUserId: string | null;
  clearPreviousGuestUserId: () => void;
  refreshProfile: () => Promise<void>;
}

const SessionContext = createContext<SessionContextType | undefined>(undefined);
const GUEST_CREDENTIALS_KEY = 'hub_guest_credentials';
const PREVIOUS_GUEST_ID_KEY = 'previousGuestUserId';

export const SessionContextProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isGuest, setIsGuest] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [previousGuestUserId, setPreviousGuestUserId] = useState<string | null>(localStorage.getItem(PREVIOUS_GUEST_ID_KEY));
  
  const internalNavigate = useNavigate();
  const isInitializingRef = useRef(false);
  const hasCheckedInitialSession = useRef(false);
  
  // Track the current user ID for transition detection
  const currentUserIdRef = useRef<string | null>(null);
  const currentIsGuestRef = useRef<boolean>(false);

  const fetchProfileInfo = useCallback(async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .maybeSingle();
      
      if (!error && data) {
        setProfile(data as Profile);
        setIsPremium(data.is_premium || false);
        setIsAdmin(data.role === 'admin');
        
        if (data.is_banned && window.location.pathname !== "/banned") {
          internalNavigate("/banned", { replace: true });
        }
        return data;
      }
    } catch (err) {
      console.warn("[SessionContext] Profile fetch failed:", err);
    }
    return null;
  }, [internalNavigate]);

  const createGuestUser = useCallback(async () => {
    if (isInitializingRef.current) return;
    isInitializingRef.current = true;
    
    try {
      const storedCreds = localStorage.getItem(GUEST_CREDENTIALS_KEY);
      if (storedCreds) {
        try {
          const { email, password } = JSON.parse(storedCreds);
          const { data, error } = await supabase.auth.signInWithPassword({ email, password });
          
          if (!error && data.session) {
            console.log("[SessionContext] Successfully restored guest account from stored credentials");
            isInitializingRef.current = false;
            return;
          } else {
            // Credentials exist but login failed - account may have been deleted/merged
            console.log("[SessionContext] Stored guest credentials invalid, creating new guest account");
            localStorage.removeItem(GUEST_CREDENTIALS_KEY);
          }
        } catch (parseError) {
          console.error("[SessionContext] Error parsing stored credentials:", parseError);
          localStorage.removeItem(GUEST_CREDENTIALS_KEY);
        }
      }
      
      // No valid stored credentials - create new guest account
      console.log("[SessionContext] Creating new guest account");
      const guestEmail = `guest_${Date.now()}_${Math.floor(Math.random() * 1000)}@hub-guest.com`;
      const guestPassword = Math.random().toString(36).substring(2, 15) + "!";
      
      const { data, error } = await supabase.auth.signUp({
        email: guestEmail,
        password: guestPassword,
        options: { 
          data: { is_guest: true, first_name: "Guest", last_name: "User" } 
        },
      });
      
      if (!error && data.session) {
        localStorage.setItem(GUEST_CREDENTIALS_KEY, JSON.stringify({ 
          email: guestEmail, 
          password: guestPassword 
        }));
        console.log("[SessionContext] New guest account created:", guestEmail);
      }
    } catch (err) {
      console.error("[SessionContext] Guest creation error:", err);
    } finally {
      isInitializingRef.current = false;
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;

    const handleAuthStateChange = async (currentSession: Session | null) => {
      if (!isMounted) return;

      if (currentSession) {
        const newUser = currentSession.user;
        const newIsGuest = newUser.user_metadata?.is_guest || false;

        // TRANSITION DETECTION: 
        // If we were a guest and now we are a real user, save the old guest ID for merging
        if (currentIsGuestRef.current && !newIsGuest && currentUserIdRef.current && currentUserIdRef.current !== newUser.id) {
          console.log("[SessionContext] Detected transition from guest to real account.");
          localStorage.setItem(PREVIOUS_GUEST_ID_KEY, currentUserIdRef.current);
          setPreviousGuestUserId(currentUserIdRef.current);
        }

        setSession(currentSession);
        setUser(newUser);
        setIsGuest(newIsGuest);
        
        currentUserIdRef.current = newUser.id;
        currentIsGuestRef.current = newIsGuest;

        await fetchProfileInfo(newUser.id);
        setLoading(false);
      } else {
        setSession(null);
        setUser(null);
        setProfile(null);
        setIsGuest(false);
        setIsPremium(false);
        setIsAdmin(false);
        
        currentUserIdRef.current = null;
        currentIsGuestRef.current = false;
        
        if (hasCheckedInitialSession.current) {
          await createGuestUser();
        }
      }
    };

    supabase.auth.getSession().then(({ data: { session: initialSession } }) => {
      hasCheckedInitialSession.current = true;
      handleAuthStateChange(initialSession);
    });

    const { data: authListener } = supabase.auth.onAuthStateChange(async (event, currentSession) => {
      if (event === 'SIGNED_OUT') {
        // IMPORTANT: Only clear guest credentials if the logged-out user was NOT a guest
        // This preserves guest credentials for guest account reuse
        const wasGuest = currentUserIdRef.current && currentIsGuestRef.current;
        
        if (!wasGuest) {
          // Real user logged out - clear guest credentials since they won't be used
          localStorage.removeItem(GUEST_CREDENTIALS_KEY);
        }
        // If it WAS a guest logout, we preserve credentials for next login
        
        handleAuthStateChange(null);
      } else if (currentSession) {
        handleAuthStateChange(currentSession);
      }
    });

    return () => {
      isMounted = false;
      authListener.subscription.unsubscribe();
    };
  }, [createGuestUser, fetchProfileInfo]);

  const clearPreviousGuestUserId = useCallback(() => {
    localStorage.removeItem(PREVIOUS_GUEST_ID_KEY);
    setPreviousGuestUserId(null);
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user) await fetchProfileInfo(user.id);
  }, [user, fetchProfileInfo]);

  return (
    <SessionContext.Provider value={{ 
      session, user, profile, loading, isGuest, isPremium, isAdmin,
      previousGuestUserId,
      clearPreviousGuestUserId,
      refreshProfile 
    }}>
      {children}
    </SessionContext.Provider>
  );
};

export const useSession = () => {
  const context = useContext(SessionContext);
  if (context === undefined) throw new Error("useSession must be used within a SessionContextProvider");
  return context;
};