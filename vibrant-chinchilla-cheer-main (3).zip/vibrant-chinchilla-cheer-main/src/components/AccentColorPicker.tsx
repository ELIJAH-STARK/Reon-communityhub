"use client";

import React from "react";
import { useUserPreferences } from "@/context/UserPreferencesContext";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useTranslation } from "@/hooks/useTranslation";

const colorOptions = [
  { name: "fieryCoral", value: "#f97316" },
  { name: "oceanBlue", value: "#3b82f6" },
  { name: "forestGreen", value: "#10b981" },
  { name: "sunsetOrange", value: "#f59e0b" },
  { name: "royalPurple", value: "#8b5cf6" },
  { name: "rosePink", value: "#ec4899" },
];

const AccentColorPicker = () => {
  const { preferences, updateAccentColor } = useUserPreferences();
  const { t } = useTranslation();

  return (
    <div className="space-y-4">
      <Label className="text-lg font-semibold">{t('settings.accentColor')}</Label>
      <div className="flex flex-wrap gap-3">
        {colorOptions.map((color) => (
          <button
            key={color.value}
            className={cn(
              "w-10 h-10 rounded-full border-2 transition-all",
              preferences.accentColor === color.value
                ? "border-foreground scale-110"
                : "border-muted-foreground hover:border-foreground"
            )}
            style={{ backgroundColor: color.value }}
            onClick={() => updateAccentColor(color.value)}
            aria-label={t('settings.selectAccentColor', { colorName: t(`settings.colorNames.${color.name}`) })}
          />
        ))}
        <div className="flex items-center gap-2">
          <input
            type="color"
            value={preferences.accentColor}
            onChange={(e) => updateAccentColor(e.target.value)}
            className="w-10 h-10 rounded-full border-2 border-muted-foreground cursor-pointer hover:border-foreground"
          />
          <span className="text-sm text-muted-foreground">{t('settings.custom')}</span>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-sm text-muted-foreground">{t('settings.currentColor')}</span>
        <div 
          className="w-6 h-6 rounded border" 
          style={{ backgroundColor: preferences.accentColor }}
        />
        <span className="text-sm font-mono">{preferences.accentColor}</span>
      </div>
    </div>
  );
};

export default AccentColorPicker;