"use client";

import React, { useState, useEffect, useId } from "react";
import { Loader2, Edit, X, Plus, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { serviceCategories } from "@/lib/constants";
import { useSession } from "@/context/SessionContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useTranslation } from "@/hooks/useTranslation";

interface UploadedService {
  id: string;
  name: string;
  description: string;
  category: string;
  image_url: string | null;
  additional_images: string[];
  latitude: number | null;
  longitude: number | null;
  user_id: string;
  status: string;
  price: number | null;
  discount_percentage: number | null;
}

interface EditServiceDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onEditSuccess: () => void;
  updateService: (id: string, updates: any, mainFile?: File, newFiles?: File[], remainingUrls?: string[]) => Promise<void>;
  editingService: UploadedService | null;
}

const serviceStatuses = ["available", "unavailable", "completed"];

const EditServiceDialog: React.FC<EditServiceDialogProps> = ({ isOpen, onOpenChange, onEditSuccess, updateService, editingService }) => {
  const { t } = useTranslation();
  const { user, isPremium } = useSession();
  const { latitude, longitude } = useGeolocation();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("available");
  const [price, setPrice] = useState("");
  const [discount, setDiscount] = useState("");
  
  const [mainImageFile, setMainImageFile] = useState<File | null>(null);
  const [mainPreview, setMainPreview] = useState<string | null>(null);
  const [existingUrls, setExistingUrls] = useState<string[]>([]);
  const [newImageFiles, setNewImageFiles] = useState<File[]>([]);
  const [newPreviews, setNewPreviews] = useState<string[]>([]);

  const [isUploading, setIsUploading] = useState(false);
  const dialogTitleId = useId();

  const maxTotal = isPremium ? 11 : 5;

  useEffect(() => {
    if (isOpen && editingService) {
      setName(editingService.name);
      setDescription(editingService.description || "");
      setCategory(editingService.category);
      setStatus(editingService.status);
      setPrice(editingService.price?.toString() || "");
      setDiscount(editingService.discount_percentage?.toString() || "");
      setExistingUrls(editingService.additional_images || []);
      setMainPreview(editingService.image_url);
      setMainImageFile(null);
      setNewImageFiles([]);
      setNewPreviews([]);
    }
  }, [isOpen, editingService]);

  const handleAddNewImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const currentTotal = 1 + existingUrls.length + newImageFiles.length;
    if (currentTotal + files.length > maxTotal) {
      toast.error(t('dialogs.selectAtLeastOneImage'));
      return;
    }
    setNewImageFiles(prev => [...prev, ...files]);
    setNewPreviews(prev => [...prev, ...files.map(f => URL.createObjectURL(f))]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingService || !user) return;
    setIsUploading(true);
    try {
      const updates = {
        name, description, category, status,
        price: price === "" ? null : parseFloat(price),
        discount_percentage: discount === "" ? null : parseFloat(discount),
        latitude: latitude || editingService.latitude,
        longitude: longitude || editingService.longitude
      };
      await updateService(editingService.id, updates, mainImageFile || undefined, newImageFiles, existingUrls);
      onEditSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle id={dialogTitleId}>{t('dialogs.editService')}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2"><Label>{t('dialogs.serviceName')}</Label><Input value={name} onChange={e => setName(e.target.value)} required /></div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('dialogs.category')}</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{serviceCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2"> 
              <Label>{t('content.status')}</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{serviceStatuses.map(s => <SelectItem key={s} value={s}>{s.toUpperCase()}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2"><Label>{t('dialogs.price')}</Label><Input type="number" value={price} onChange={e => setPrice(e.target.value)} placeholder={t('dialogs.negotiable')} /></div>
            <div className="space-y-2"><Label>{t('dialogs.discount')}</Label><Input type="number" value={discount} onChange={e => setDiscount(e.target.value)} /></div>
          </div>
          <div className="space-y-2"><Label>{t('dialogs.description')}</Label><Textarea value={description} onChange={e => setDescription(e.target.value)} /></div>

          <div className="space-y-4 pt-2">
            <Label className="text-primary font-bold">{t('dialogs.portfolioImages')}</Label>
            <div className="flex flex-wrap gap-2">
              <div className="relative h-20 w-20">
                <Input type="file" accept="image/*" onChange={(e) => {
                  const f = e.target.files?.[0];
                  if(f) { setMainImageFile(f); setMainPreview(URL.createObjectURL(f)); }
                }} className="hidden" id="edit-svc-main" />
                <Label htmlFor="edit-svc-main" className="block h-full w-full rounded-lg border-2 border-dashed cursor-pointer overflow-hidden">
                  {mainPreview ? <img src={mainPreview} className="h-full w-full object-cover" /> : <UploadCloud className="m-auto h-6 w-6 mt-6" />}
                </Label>
                <span className="absolute -bottom-4 left-0 text-[8px] font-bold uppercase text-muted-foreground">{t('dialogs.main')}</span>
              </div>
              {existingUrls.map((url, i) => (
                <div key={i} className="relative h-20 w-20">
                  <img src={url} className="h-full w-full object-cover rounded-lg border" />
                  <button type="button" onClick={() => setExistingUrls(prev => prev.filter(u => u !== url))} className="absolute -top-1 -right-1 bg-destructive rounded-full p-0.5 text-white"><X className="h-3 w-3"/></button>
                </div>
              ))}
              {newPreviews.map((p, i) => (
                <div key={i} className="relative h-20 w-20">
                  <img src={p} className="h-full w-full object-cover rounded-lg border border-primary" />
                  <button type="button" onClick={() => {
                    setNewImageFiles(prev => prev.filter((_, idx) => idx !== i));
                    setNewPreviews(prev => prev.filter((_, idx) => idx !== i));
                  }} className="absolute -top-1 -right-1 bg-destructive rounded-full p-0.5 text-white"><X className="h-3 w-3"/></button>
                </div>
              ))}
              {(existingUrls.length + newImageFiles.length) < (maxTotal - 1) && (
                <>
                  <Input type="file" accept="image/*" multiple onChange={handleAddNewImages} className="hidden" id="edit-svc-add" />
                  <Label htmlFor="edit-svc-add" className="flex h-20 w-20 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed bg-muted/30"><Plus/></Label>
                </>
              )}
            </div>
          </div>

          <DialogFooter className="pt-6">
            <Button type="submit" disabled={isUploading}>{isUploading ? t('dialogs.saving') : t('dialogs.saveChanges')}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditServiceDialog;