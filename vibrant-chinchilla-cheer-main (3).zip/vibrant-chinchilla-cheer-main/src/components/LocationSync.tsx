"use client";

import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";

/**
 * LocationSync handles background updates for the user's location.
 * If live_location_enabled is true in the profile, it updates the 
 * latitude and longitude in Supabase every 30 seconds.
 */
const LocationSync = () => {
  const { user } = useSession();
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    const updateLocation = async () => {
      if (!user) return;

      // 1. Check if the user has live location enabled
      const { data: profile } = await supabase
        .from('profiles')
        .select('live_location_enabled')
        .eq('id', user.id)
        .single();

      if (!profile?.live_location_enabled) return;

      // 2. Get current position
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          
          // 3. Update profile with new coordinates
          await supabase
            .from('profiles')
            .update({
              latitude,
              longitude,
              updated_at: new Date().toISOString()
            })
            .eq('id', user.id);
            
          console.log("[LocationSync] Background coordinates updated", { latitude, longitude });
        },
        (error) => {
          console.error("[LocationSync] Failed to get location", error.message);
        },
        { enableHighAccuracy: true }
      );
    };

    if (user) {
      // Run immediately
      updateLocation();
      
      // Setup interval (every 30 seconds)
      intervalRef.current = window.setInterval(updateLocation, 30000);
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [user]);

  return null; // This component doesn't render anything
};

export default LocationSync;