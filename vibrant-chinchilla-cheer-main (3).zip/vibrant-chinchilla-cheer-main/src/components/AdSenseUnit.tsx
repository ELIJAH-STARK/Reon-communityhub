"use client";

import React, { useEffect } from "react";

interface AdSenseUnitProps {
  client?: string;
  slot: string;
  format?: "auto" | "fluid" | "rectangle";
  responsive?: "true" | "false";
  className?: string;
}

/**
 * AdSenseUnit renders a standard Google AdSense ad slot.
 * It automatically triggers the 'push' command to fill the ad when it enters the page.
 */
const AdSenseUnit: React.FC<AdSenseUnitProps> = ({ 
  client = "ca-pub-XXXXXXXXXXXXXXXX", // REPLACE with your actual Publisher ID
  slot, 
  format = "auto", 
  responsive = "true",
  className
}) => {
  useEffect(() => {
    try {
      // @ts-ignore
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.warn("AdSense failed to load unit", e);
    }
  }, []);

  return (
    <div className={className} style={{ overflow: 'hidden', minWidth: '250px', minHeight: '100px' }}>
      <ins 
        className="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client={client}
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive}
      />
    </div>
  );
};

export default AdSenseUnit;