"use client";

import React from "react";
import { Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useFavorites } from "@/context/FavoritesContext";
import { cn } from "@/lib/utils";
import { useHaptics } from "@/hooks/use-haptics";
import { ImpactStyle } from "@capacitor/haptics";

interface FavoriteButtonProps {
  id: string;
  type: 'item' | 'service';
  className?: string;
}

const FavoriteButton: React.FC<FavoriteButtonProps> = ({ id, type, className }) => {
  const { isFavorited, toggleFavorite } = useFavorites();
  const { impact } = useHaptics();
  const favorited = isFavorited(id, type);

  const handleToggle = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    // Provide a light 'click' feeling on mobile
    impact(ImpactStyle.Light);
    
    toggleFavorite(id, type);
  };

  return (
    <Button
      variant="ghost"
      size="icon"
      className={cn(
        "rounded-full hover:bg-red-50 hover:text-red-500 transition-colors",
        favorited ? "text-red-500 fill-red-500" : "text-muted-foreground",
        className
      )}
      onClick={handleToggle}
    >
      <Heart className={cn("h-5 w-5", favorited && "fill-current")} />
    </Button>
  );
};

export default FavoriteButton;