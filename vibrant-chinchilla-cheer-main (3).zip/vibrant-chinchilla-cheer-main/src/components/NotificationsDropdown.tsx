"use client";

import React from "react";
import { Bell, MessageSquare, Star, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import { useNotifications } from "@/context/NotificationsContext";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";

const NotificationsDropdown = () => {
  const { notifications, unreadCount, deleteNotification, markAllAsRead } = useNotifications();
  const navigate = useNavigate();

  const getIcon = (type: string) => {
    switch (type) {
      case 'message': return <MessageSquare className="h-4 w-4 text-blue-500" />;
      case 'review': return <Star className="h-4 w-4 text-yellow-500" />;
      default: return <Info className="h-4 w-4 text-primary" />;
    }
  };

  const handleNotificationClick = async (notif: any) => {
    // Delete notification first as requested
    await deleteNotification(notif.id);
    
    // Then navigate to the link if it exists
    if (notif.link) {
      navigate(notif.link);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative h-9 w-9 rounded-full">
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground font-bold">
              {unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <div className="flex items-center justify-between px-4 py-2">
          <DropdownMenuLabel className="p-0">Notifications</DropdownMenuLabel>
          {unreadCount > 0 && (
            <Button variant="ghost" size="sm" className="h-auto p-0 text-xs text-primary" onClick={markAllAsRead}>
              Mark all as read
            </Button>
          )}
        </div>
        <DropdownMenuSeparator />
        <ScrollArea className="h-80">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
              <Bell className="h-8 w-8 mb-2 opacity-20" />
              <p className="text-sm">No notifications yet</p>
            </div>
          ) : (
            notifications.map((notif) => (
              <DropdownMenuItem
                key={notif.id}
                className={cn(
                  "flex flex-col items-start gap-1 p-4 cursor-pointer focus:bg-accent",
                  !notif.is_read && "bg-primary/5"
                )}
                onClick={() => handleNotificationClick(notif)}
              >
                <div className="flex w-full items-center gap-2">
                  {getIcon(notif.type)}
                  <span className="font-semibold text-sm flex-1">{notif.title}</span>
                  {!notif.is_read && <div className="h-2 w-2 rounded-full bg-primary" />}
                </div>
                <p className="text-xs text-muted-foreground line-clamp-2">{notif.content}</p>
                <div className="flex w-full items-center justify-between mt-1">
                  <span className="text-[10px] text-muted-foreground">
                    {new Date(notif.created_at).toLocaleDateString()}
                  </span>
                  <span className="text-[10px] text-primary font-medium">Open chat</span>
                </div>
              </DropdownMenuItem>
            ))
          )}
        </ScrollArea>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default NotificationsDropdown;