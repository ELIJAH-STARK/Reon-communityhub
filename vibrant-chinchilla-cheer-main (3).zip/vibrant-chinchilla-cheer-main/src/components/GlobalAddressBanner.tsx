"use client";

import React from "react";
import { MapPin } from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

const GlobalAddressBanner = () => {
  const { user } = useSession();
  
  // In a real implementation, this would fetch the global address from the user's profile
  const globalAddress = user?.user_metadata?.global_address || user?.user_metadata?.full_address;
  
  // Only show the banner if the user has set a global address
  if (!globalAddress) {
    return null;
  }

  return (
    <div className="bg-primary/5 border-b border-primary/10 py-2 px-4 flex flex-col sm:flex-row items-center justify-center gap-2 text-sm">
      <div className="flex items-center">
        <MapPin className="h-4 w-4 text-primary mr-2" />
        <span className="font-medium">Your Global Address:</span>
        <span className="ml-2 text-muted-foreground truncate max-w-md">{globalAddress}</span>
      </div>
      <Button variant="link" size="sm" className="h-auto p-0 text-primary hover:text-primary/80" asChild>
        <Link to="/profile">Edit</Link>
      </Button>
    </div>
  );
};

export default GlobalAddressBanner;