"use client";

import React, { useState, useEffect, useId } from "react";
import { Loader2, Percent } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge"; // Import Badge component

interface UploadedItem {
  id: string;
  name: string;
  image_url: string;
  price: number | null;
  discount_percentage: number | null;
}

interface BulkDiscountDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  userItems: UploadedItem[];
  applyBulkDiscount: (itemIds: string[], discountPercentage: number | null) => Promise<void>;
}

const BulkDiscountDialog: React.FC<BulkDiscountDialogProps> = ({ isOpen, onOpenChange, userItems, applyBulkDiscount }) => {
  const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());
  const [discountPercentage, setDiscountPercentage] = useState<string>("");
  const [isApplying, setIsApplying] = useState(false);
  const [selectAll, setSelectAll] = useState(false);

  const dialogTitleId = useId(); // Generate a unique ID for the dialog title

  useEffect(() => {
    if (!isOpen) {
      // Reset form when dialog closes
      setSelectedItemIds(new Set());
      setDiscountPercentage("");
      setIsApplying(false);
      setSelectAll(false);
    }
  }, [isOpen]);

  useEffect(() => {
    if (selectAll) {
      const allIds = new Set(userItems.map(item => item.id));
      setSelectedItemIds(allIds);
    } else if (selectedItemIds.size === userItems.length && userItems.length > 0) {
      // If all items were manually selected, and then user unchecks selectAll, clear it.
      // Or if userItems changes and previously all were selected, but now not all are.
      // This handles the case where user manually selects all, then unchecks selectAll.
      // We only want to clear if selectAll is explicitly unchecked.
      // If selectAll is false, and selectedItemIds has all items, it means user manually selected all.
      // We don't want to clear it in that case.
      // So, only update selectedItemIds if selectAll is true.
    }
  }, [selectAll, userItems, selectedItemIds]);

  const handleCheckboxChange = (itemId: string, checked: boolean) => {
    setSelectedItemIds(prev => {
      const newSet = new Set(prev);
      if (checked) {
        newSet.add(itemId);
      } else {
        newSet.delete(itemId);
      }
      return newSet;
    });
  };

  const handleSelectAllChange = (checked: boolean) => {
    setSelectAll(checked);
    if (checked) {
      setSelectedItemIds(new Set(userItems.map(item => item.id)));
    } else {
      setSelectedItemIds(new Set());
    }
  };

  const handleApplyDiscount = async () => {
    if (selectedItemIds.size === 0) {
      toast.error("Please select at least one item to apply a discount.");
      return;
    }

    const discountValue = discountPercentage.trim() === "" ? null : parseFloat(discountPercentage);

    if (discountValue !== null && (isNaN(discountValue) || discountValue < 0 || discountValue > 100)) {
      toast.error("Please enter a valid discount percentage between 0 and 100.");
      return;
    }

    setIsApplying(true);
    try {
      await applyBulkDiscount(Array.from(selectedItemIds), discountValue);
      onOpenChange(false);
    } catch (error) {
      console.error("Failed to apply bulk discount:", error);
    } finally {
      setIsApplying(false);
    }
  };

  const isApplyButtonActive = selectedItemIds.size > 0 && !isApplying;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]" aria-labelledby={dialogTitleId}>
        <DialogHeader>
          <DialogTitle id={dialogTitleId}>Apply Bulk Discount</DialogTitle>
          <DialogDescription>
            Select items and apply a discount percentage. Set to 0 or leave empty to remove discount.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="flex items-center gap-2">
            <Label htmlFor="discountPercentage" className="text-right">
              Discount (%)
            </Label>
            <Input
              id="discountPercentage"
              type="number"
              value={discountPercentage}
              onChange={(e) => setDiscountPercentage(e.target.value)}
              className="flex-1"
              placeholder="e.g., 15 (for 15% off)"
              min="0"
              max="100"
              step="1"
              disabled={isApplying}
            />
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="selectAll"
              checked={selectAll || (userItems.length > 0 && selectedItemIds.size === userItems.length)}
              onCheckedChange={(checked: boolean) => handleSelectAllChange(checked)}
              disabled={userItems.length === 0 || isApplying}
            />
            <label
              htmlFor="selectAll"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              Select All ({userItems.length} items)
            </label>
          </div>

          <Label className="text-sm font-medium">Select Items:</Label>
          <ScrollArea className="h-60 w-full rounded-md border p-4">
            {userItems.length === 0 ? (
              <p className="text-muted-foreground text-center">No items available to discount.</p>
            ) : (
              <div className="space-y-3">
                {userItems.map((item) => (
                  <div key={item.id} className="flex items-center space-x-3">
                    <Checkbox
                      id={`item-${item.id}`}
                      checked={selectedItemIds.has(item.id)}
                      onCheckedChange={(checked: boolean) => handleCheckboxChange(item.id, checked)}
                      disabled={isApplying}
                    />
                    <label
                      htmlFor={`item-${item.id}`}
                      className="flex items-center gap-2 text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      <img src={item.image_url} alt={item.name} className="w-8 h-8 object-cover rounded-sm" />
                      <span>{item.name}</span>
                      {item.price != null && (
                        <span className="text-xs text-muted-foreground">(${item.price.toFixed(2)})</span>
                      )}
                      {item.discount_percentage != null && item.discount_percentage > 0 && (
                        <Badge variant="default" className="bg-green-500 hover:bg-green-600 text-xs py-0.5 px-1">
                          {item.discount_percentage}% OFF
                        </Badge>
                      )}
                    </label>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
        <DialogFooter>
          <Button onClick={handleApplyDiscount} disabled={!isApplyButtonActive}>
            {isApplying && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <Percent className="h-4 w-4 mr-2" />
            Apply Discount
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default BulkDiscountDialog;