"use client";

import React from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { LucideIcon } from "lucide-react";

interface FeatureCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  href: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon: Icon, title, description, href }) => {
  return (
    <Card className="flex flex-col items-center text-center p-4 h-full">
      <CardHeader className="pb-2">
        <Icon className="h-10 w-10 text-primary mb-2" />
        <CardTitle className="text-xl font-semibold">{title}</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center justify-between flex-grow">
        <p className="text-sm text-muted-foreground mb-4">{description}</p>
        <Button asChild className="mt-auto w-full">
          <Link to={href}>
            Learn More
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
};

export default FeatureCard;