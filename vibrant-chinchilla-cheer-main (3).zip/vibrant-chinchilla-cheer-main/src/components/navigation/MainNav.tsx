"use client";

import * as React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { MapPin, LogOut, User as UserIcon, LogIn, ShieldCheck, Users, ShieldAlert, Loader2, Crown, Megaphone, LayoutDashboard, TrendingUp } from "lucide-react";
import { navItems } from "@/lib/navigation";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";
import { useSystemSettingsContext } from "@/context/SystemSettingsContext";
import { useTranslation } from "@/hooks/useTranslation";
import NotificationsDropdown from "@/components/NotificationsDropdown";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

export function MainNav() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, profile, loading, isGuest, isPremium, isAdmin } = useSession();
  const { settings } = useSystemSettingsContext();
  const { t } = useTranslation();
  const activeItemRef = React.useRef<HTMLAnchorElement>(null);

  React.useEffect(() => {
    if (activeItemRef.current) {
      activeItemRef.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
        inline: "center",
      });
    }
  }, [location.pathname]);

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast.error(t('errors.failedToLogOut', 'Failed to log out'));
    } else {
      toast.success(t('errors.youHaveBeenLoggedOut', 'You have been logged out.'));
      navigate('/');
    }
  };

  const displayName = profile?.username || 
    (profile?.first_name || profile?.last_name 
      ? `${profile.first_name || ''} ${profile.last_name || ''}`.trim() 
      : user?.email?.split('@')[0] || "Guest");
      
  const displayAvatar = profile?.avatar_url || user?.user_metadata?.avatar_url;

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center px-4">
        <Link
          to="/"
          className="mr-4 flex items-center gap-2 font-bold transition-opacity hover:opacity-80 shrink-0"
        >
          <div className="bg-primary p-1.5 rounded-lg shadow-sm">
            <MapPin className="h-5 w-5 text-white" />
          </div>
          <span className="hidden sm:inline-block tracking-tight text-xl">Hub</span>
        </Link>
        
        <nav className="flex items-center flex-1 overflow-x-auto no-scrollbar -mb-px">
          <div className="flex gap-4 md:gap-6 items-center px-2">
            {navItems.map((item) => {
              const isActive = location.pathname === item.href || 
                (item.href !== '/' && location.pathname.startsWith(item.href));
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  ref={isActive ? activeItemRef : null}
                  className={cn(
                    "flex items-center gap-2 text-sm font-medium transition-all hover:text-primary whitespace-nowrap py-2 border-b-2 border-transparent",
                    isActive 
                      ? "text-primary border-primary" 
                      : "text-muted-foreground"
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.name}
                </Link>
              );
            })}
          </div>
        </nav>
        
        <div className="ml-4 flex items-center gap-1 sm:gap-2 shrink-0">
          {loading ? (
            <div className="h-9 w-9 flex items-center justify-center">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          ) : (
            <>
              {isPremium && settings.premiumEnabled && (
                <Link 
                  to="/premium" 
                  className="hidden md:flex items-center gap-1.5 text-xs font-bold text-yellow-500 bg-yellow-500/10 px-3 py-1.5 rounded-full border border-yellow-500/20 mr-2"
                >
                  <Crown className="h-3 w-3 fill-current" /> {t('navigation.premium', 'Premium')}
                </Link>
              )}
              
              {user && !isGuest && <NotificationsDropdown />}
              
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      variant="ghost" 
                      className="relative h-10 w-10 rounded-full p-0 overflow-hidden ring-2 ring-muted ring-offset-2 hover:ring-primary transition-all"
                    >
                      <Avatar className="h-full w-full">
                        <AvatarImage 
                          src={displayAvatar || undefined} 
                          alt={displayName} 
                          className="object-cover" 
                        />
                        <AvatarFallback className="bg-muted text-muted-foreground">
                          <UserIcon className="h-5 w-5" />
                        </AvatarFallback>
                      </Avatar>
                      {isAdmin ? (
                        <div className="absolute top-0 right-0 h-3 w-3 rounded-full bg-primary border-2 border-background" />
                      ) : isPremium ? (
                        <div className="absolute top-0 right-0 h-3 w-3 rounded-full bg-yellow-500 border-2 border-background" />
                      ) : null}
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-64 rounded-2xl" align="end" forceMount>
                    <div className="flex items-center justify-start gap-2 p-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={displayAvatar || undefined} alt={displayName} />
                        <AvatarFallback>
                          <UserIcon className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col space-y-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-black leading-none truncate max-w-[120px]">
                            {displayName}
                          </p>
                          {isGuest && <Badge variant="secondary" className="h-4 px-1 text-[8px] uppercase">Guest</Badge>}
                        </div>
                        <p className="text-xs leading-none text-muted-foreground truncate">{isGuest ? "Temporary Session" : user.email}</p>
                      </div>
                    </div>
                    
                    {isAdmin && (
                      <>
                        <DropdownMenuSeparator />
                        <DropdownMenuLabel className="text-[10px] uppercase text-muted-foreground tracking-widest font-bold px-2 py-1">
                          {t('common.admin', 'Administration')}
                        </DropdownMenuLabel>
                        <DropdownMenuItem 
                          onClick={() => navigate('/admin')} 
                          className="cursor-pointer rounded-lg"
                        >
                          <LayoutDashboard className="mr-2 h-4 w-4" />
                          {t('pages.adminDashboard', 'Control Panel')}
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => navigate('/admin/revenue')} 
                          className="cursor-pointer rounded-lg"
                        >
                          <TrendingUp className="mr-2 h-4 w-4" />
                          {t('common.revenue', 'Revenue Analytics')}
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => navigate('/admin/announcements')} 
                          className="cursor-pointer rounded-lg"
                        >
                          <Megaphone className="mr-2 h-4 w-4" />
                          {t('common.announcements', 'Announcements')}
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => navigate('/admin/reports')} 
                          className="cursor-pointer rounded-lg"
                        >
                          <ShieldAlert className="mr-2 h-4 w-4" />
                          {t('common.reports', 'Community Reports')}
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => navigate('/admin/users')} 
                          className="cursor-pointer rounded-lg"
                        >
                          <Users className="mr-2 h-4 w-4" />
                          {t('common.userManagement', 'User Management')}
                        </DropdownMenuItem>
                      </>
                    )}
                    
                    <DropdownMenuSeparator />
                    <DropdownMenuItem 
                      onClick={() => navigate('/profile')} 
                      className="cursor-pointer rounded-lg"
                    >
                      <UserIcon className="mr-2 h-4 w-4" />
                      {isGuest ? t('common.settings', 'Guest Settings') : t('pages.profilePage', 'My Profile')}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    {isGuest ? (
                      <DropdownMenuItem 
                        onClick={() => navigate('/login')} 
                        className="text-primary cursor-pointer font-bold rounded-lg"
                      >
                        <LogIn className="mr-2 h-4 w-4" />
                        {t('auth.createAccount', 'Sign In / Register')}
                      </DropdownMenuItem>
                    ) : (
                      <DropdownMenuItem 
                        onClick={handleLogout} 
                        className="text-destructive cursor-pointer rounded-lg"
                      >
                        <LogOut className="mr-2 h-4 w-4" />
                        {t('common.logout', 'Log out')}
                      </DropdownMenuItem>
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={() => navigate('/login')}
                  className="rounded-full"
                >
                  <LogIn className="h-4 w-4 mr-2" /> {t('common.login', 'Sign In')}
                </Button>
              )}
            </>
          )}
        </div>
      </div>
    </header>
  );
}