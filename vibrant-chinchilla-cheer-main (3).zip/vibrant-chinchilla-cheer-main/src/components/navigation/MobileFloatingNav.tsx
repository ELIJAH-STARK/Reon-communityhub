"use client";

import React, { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Plus } from "lucide-react";
import { navItems } from "@/lib/navigation";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const MobileFloatingNav = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  // We only show this on smaller screens
  return (
    <div className="fixed bottom-6 right-6 z-[100] md:hidden pointer-events-none">
      {/* Backdrop for the menu */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm transition-all animate-in fade-in pointer-events-auto"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Navigation Items */}
      <div className={cn(
        "flex flex-col-reverse items-end gap-3 mb-4 transition-all duration-300 relative z-10",
        isOpen ? "translate-y-0 opacity-100 scale-100 pointer-events-auto" : "translate-y-10 opacity-0 scale-90 pointer-events-none"
      )}>
        {navItems.map((item, index) => {
          const isActive = location.pathname === item.href;
          return (
            <Link
              key={item.name}
              to={item.href}
              onClick={() => setIsOpen(false)}
              className={cn(
                "flex items-center gap-3 px-4 py-2 rounded-full shadow-lg border transition-all hover:scale-105 active:scale-95",
                isActive 
                  ? "bg-primary text-primary-foreground border-primary" 
                  : "bg-card text-foreground border-border hover:bg-accent"
              )}
              style={{ transitionDelay: `${index * 50}ms` }}
            >
              <span className="text-xs font-bold uppercase tracking-wider">{item.name}</span>
              <item.icon className="h-5 w-5" />
            </Link>
          );
        })}
      </div>

      {/* Main Toggle Button */}
      <div className="relative z-10 pointer-events-auto flex justify-end">
        <Button
          size="icon"
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            "h-14 w-14 rounded-full shadow-2xl transition-all duration-300 active:scale-90",
            isOpen ? "bg-destructive hover:bg-destructive rotate-90" : "bg-primary hover:bg-primary/90"
          )}
        >
          {isOpen ? (
            <X className="h-6 w-6 text-white" />
          ) : (
            <Menu className="h-6 w-6 text-white" />
          )}
        </Button>
      </div>
    </div>
  );
};

export default MobileFloatingNav;