"use client";

import React, { useState } from "react";
import { Copy, Check, Info, ShieldCheck, Loader2, Link as LinkIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface CryptoPaymentFormProps {
  amount: number;
  itemType: string;
  userId: string;
  onSuccess: () => void;
}

// REPLACE THESE WITH YOUR ACTUAL WALLET ADDRESSES
const WALLET_ADDRESSES = {
  BTC: "bc1qwystwxxkl0kzcz0c07zfc94wtnrm7tuqglzcu2", // Example address
  ETH: "0x71C7656EC7ab88b098defB751B7401B5f6d8976F", // Example address
};

const CryptoPaymentForm: React.FC<CryptoPaymentFormProps> = ({ amount, itemType, userId, onSuccess }) => {
  const [selectedCurrency, setSelectedCurrency] = useState<'BTC' | 'ETH'>('ETH');
  const [txHash, setTxHash] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(WALLET_ADDRESSES[selectedCurrency]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    toast.success("Address copied to clipboard");
  };

  const handleSubmit = async () => {
    if (txHash.length < 10) {
      toast.error("Please enter a valid transaction hash.");
      return;
    }

    setIsSubmitting(true);
    try {
      const { error } = await supabase.from('transactions').insert({
        user_id: userId,
        amount: amount,
        item_type: itemType,
        payment_method: 'crypto',
        status: 'pending',
        transaction_details: {
          currency: selectedCurrency,
          hash: txHash,
          submitted_at: new Date().toISOString()
        }
      });

      if (error) throw error;

      toast.success("Transaction submitted for review!");
      onSuccess();
    } catch (err: any) {
      toast.error("Failed to submit: " + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-2 p-1 bg-muted rounded-xl">
        {(['ETH', 'BTC'] as const).map((curr) => (
          <button
            key={curr}
            className={cn(
              "flex-1 rounded-lg h-9 font-bold text-xs transition-all",
              selectedCurrency === curr ? "bg-background shadow-sm text-foreground" : "text-muted-foreground hover:text-foreground"
            )}
            onClick={() => setSelectedCurrency(curr)}
          >
            {curr}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <Label className="text-xs font-bold text-muted-foreground uppercase">Send Exactly</Label>
        <div className="p-3 bg-muted/50 rounded-xl border flex items-center justify-between">
          <span className="font-mono font-bold text-lg">${amount.toFixed(2)} USD value</span>
          <span className="text-[10px] bg-primary/10 text-primary px-2 py-0.5 rounded-full font-bold">Live Rate</span>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-xs font-bold text-muted-foreground uppercase">{selectedCurrency} Wallet Address</Label>
        <div className="relative group">
          <Input 
            readOnly 
            value={WALLET_ADDRESSES[selectedCurrency]} 
            className="pr-12 font-mono text-[10px] h-11 bg-muted/20"
          />
          <Button 
            size="icon" 
            variant="ghost" 
            className="absolute right-1 top-1 h-9 w-9"
            onClick={handleCopy}
          >
            {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-xs font-bold text-muted-foreground uppercase">Transaction Hash (TXID)</Label>
        <div className="relative">
          <LinkIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Paste your hash here..." 
            className="pl-10 h-11"
            value={txHash}
            onChange={(e) => setTxHash(e.target.value)}
          />
        </div>
        <p className="text-[10px] text-muted-foreground italic flex items-start gap-2 pt-1">
          <Info className="h-3 w-3 shrink-0 mt-0.5" />
          Benefits will be activated once the network confirms the transaction (usually 10-30 mins).
        </p>
      </div>

      <Button className="w-full h-12 rounded-xl font-bold" onClick={handleSubmit} disabled={isSubmitting}>
        {isSubmitting ? <Loader2 className="h-5 w-5 animate-spin mr-2" /> : <ShieldCheck className="h-5 w-5 mr-2" />}
        Confirm Payment Sent
      </Button>
    </div>
  );
};

export default CryptoPaymentForm;