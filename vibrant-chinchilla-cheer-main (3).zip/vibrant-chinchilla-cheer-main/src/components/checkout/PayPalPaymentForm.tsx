"use client";

import React, { useEffect, useState } from "react";
import { Loader2, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface PayPalPaymentFormProps {
  amount: number;
  onSuccess: (sourceId?: string) => Promise<void>;
  isProcessing: boolean;
  setIsProcessing: (val: boolean) => void;
  itemType: string;
  userId: string;
}

declare global {
  interface Window {
    paypal: any;
  }
}

const PayPalPaymentForm: React.FC<PayPalPaymentFormProps> = ({ amount, onSuccess, isProcessing, setIsProcessing, itemType, userId }) => {
  const [error, setError] = useState<string | null>(null);
  const [isSdkLoaded, setIsSdkLoaded] = useState(false);

  useEffect(() => {
    const loadPayPalScript = () => {
      // Check if already loaded to prevent duplicate scripts
      if (window.paypal) {
        setIsSdkLoaded(true);
        return;
      }

      const clientId = import.meta.env.VITE_PAYPAL_CLIENT_ID || "test";
      const script = document.createElement('script');
      script.src = `https://www.paypal.com/sdk/js?client-id=\${clientId}&currency=USD`;
      script.async = true;
      script.onload = () => setIsSdkLoaded(true);
      script.onerror = () => setError("Failed to load PayPal secure portal.");
      document.head.appendChild(script);
    };

    loadPayPalScript();
  }, []);

  useEffect(() => {
    if (isSdkLoaded && window.paypal && !isProcessing) {
      // Clear previous buttons if any
      const container = document.getElementById('paypal-button-container');
      if (container) container.innerHTML = '';

      window.paypal.Buttons({
        style: {
          layout: 'vertical',
          color:  'gold',
          shape:  'pill',
          label:  'checkout'
        },
        createOrder: (data: any, actions: any) => {
          return actions.order.create({
            purchase_units: [{
              amount: { value: amount.toString() },
              description: `Community Hub: \${itemType}`
            }]
          });
        },
        onApprove: async (data: any, actions: any) => {
          setIsProcessing(true);
          try {
            const order = await actions.order.capture();
            
            // Verify and process on backend via Edge Function
            const { data: result, error: funcError } = await supabase.functions.invoke('process-paypal-payment', {
              body: {
                orderId: order.id,
                itemType,
                userId,
                amount
              }
            });

            if (funcError || !result?.success) throw new Error(result?.error || "Verification failed");

            await onSuccess();
          } catch (err: any) {
            setError(err.message || "Payment verification failed.");
            setIsProcessing(false);
          }
        },
        onError: (err: any) => {
          console.error("PayPal Error:", err);
          setError("The transaction was declined or interrupted.");
        }
      }).render('#paypal-button-container');
    }
  }, [isSdkLoaded, amount, itemType, userId, isProcessing]);

  return (
    <div className="space-y-4">
      <div id="paypal-button-container" className={isProcessing ? "opacity-50 pointer-events-none" : ""} />
      
      {!isSdkLoaded && !error && (
        <div className="flex flex-col items-center justify-center py-8 gap-2">
          <Loader2 className="h-6 w-6 animate-spin text-primary" />
          <p className="text-[10px] font-bold text-muted-foreground uppercase">Connecting to PayPal...</p>
        </div>
      )}

      {error && (
        <div className="p-3 bg-destructive/10 text-destructive rounded-lg border border-destructive/20 text-xs flex items-center gap-2">
          <AlertCircle className="h-4 w-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      <p className="text-[10px] text-muted-foreground text-center">
        Transactions are protected by PayPal Purchase Protection.
      </p>
    </div>
  );
};

export default PayPalPaymentForm;