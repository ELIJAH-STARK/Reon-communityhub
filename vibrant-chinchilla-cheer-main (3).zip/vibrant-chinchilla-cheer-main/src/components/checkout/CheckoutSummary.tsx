"use client";

import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, PackagePlus, Sparkles, AlertCircle } from "lucide-react";

interface CheckoutSummaryProps {
  type: 'premium' | '1slot' | '4slot' | string;
}

const CheckoutSummary: React.FC<CheckoutSummaryProps> = ({ type }) => {
  const getDetails = () => {
    switch (type) {
      case 'premium':
        return {
          title: "1 Year Hub Supporter",
          price: 29.99,
          icon: <Crown className="h-6 w-6 text-yellow-500" />,
          features: [
            "Unlimited Hub Listings",
            "Featured Placement",
            "Supporter Gold Badge",
            "Ad-free Experience"
          ]
        };
      case '1slot':
        return {
          title: "Extra Listing Slot (+1)",
          price: 1.99,
          icon: <PackagePlus className="h-6 w-6 text-blue-500" />,
          features: [
            "Permanent +1 Capacity",
            "Valid for 1 Year",
            "Instant Activation"
          ]
        };
      case '4slot':
        return {
          title: "Extra Slots Bundle (+4)",
          price: 6.99,
          icon: <Sparkles className="h-6 w-6 text-primary" />,
          features: [
            "Permanent +4 Capacity",
            "Valid for 1 Year",
            "Counts toward Supporter goal"
          ]
        };
      default:
        // Fallback for invalid types
        return {
          title: "Standard Upgrade",
          price: 0.00,
          icon: <AlertCircle className="h-6 w-6 text-muted-foreground" />,
          features: ["Selection error", "Please return to previous page"]
        };
    }
  };

  const details = getDetails();

  return (
    <Card className="border-none shadow-none bg-muted/30 rounded-2xl overflow-hidden">
      <CardHeader className="pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-background rounded-xl shadow-sm">
            {details.icon}
          </div>
          <div>
            <CardTitle className="text-lg font-bold">{details.title}</CardTitle>
            <Badge variant="outline" className="mt-1 border-primary/20 text-primary">
              Secure SSL Transaction
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-baseline gap-1">
          <span className="text-4xl font-black">${details.price.toFixed(2)}</span>
          <span className="text-muted-foreground text-sm">USD</span>
        </div>
        
        <ul className="space-y-3">
          {details.features.map((feature, i) => (
            <li key={i} className="flex items-center gap-2 text-sm font-medium">
              <Check className="h-4 w-4 text-green-500 shrink-0" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
};

export default CheckoutSummary;