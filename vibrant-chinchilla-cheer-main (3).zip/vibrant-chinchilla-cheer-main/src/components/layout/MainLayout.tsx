"use client";

import React from "react";
import { Outlet, Link } from "react-router-dom";
import { MainNav } from "@/components/navigation/MainNav";
import Footer from "@/components/layout/Footer";
import GlobalAddressBanner from "@/components/GlobalAddressBanner";
import LocationSync from "@/components/LocationSync";
import PresenceSync from "@/components/PresenceSync";
import MobileFloatingNav from "@/components/navigation/MobileFloatingNav";
import { useSession } from "@/context/SessionContext";
import { useUserPreferences } from "@/context/UserPreferencesContext";
import { AlertCircle, Sparkles, Loader2 } from "lucide-react";
import { Capacitor } from "@capacitor/core";

const MainLayout = () => {
  const { user, isGuest, loading, previousGuestUserId } = useSession();
  const { preferences } = useUserPreferences();

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="text-sm font-medium text-muted-foreground animate-pulse">Syncing with Community Hub...</p>
        </div>
      </div>
    );
  }

  // Determine if footer should be shown
  const shouldShowFooter = Capacitor.isNativePlatform() ? false : preferences.showFooter;

  return (
    <div className="flex min-h-screen w-full flex-col">
      {/* Background Services */}
      {user && (
        <>
          <LocationSync />
          <PresenceSync />
        </>
      )}
      <div className="sticky top-0 z-50 w-full flex flex-col bg-background">
        <MainNav />
        {isGuest && (
          <div className="bg-primary/10 border-b border-primary/20 py-2 px-4 flex items-center justify-center gap-2 text-[10px] md:text-xs font-medium text-primary">
            <AlertCircle className="h-3 w-3" />
            <span>Guest Mode Active. Your data won't persist unless you register.</span>
            <Link to="/login" className="underline font-bold hover:text-primary/80 ml-1">Register Now</Link>
          </div>
        )}
        {!isGuest && previousGuestUserId && (
          <div className="bg-orange-500/10 border-b border-orange-500/20 py-2 px-4 flex items-center justify-center gap-2 text-[10px] md:text-xs font-medium text-orange-600">
            <Sparkles className="h-3 w-3" />
            <span>You have unsynced data from your guest session.</span>
            <Link to="/profile" className="underline font-bold hover:text-orange-700 ml-1">Merge History</Link>
          </div>
        )}
        <GlobalAddressBanner />
      </div>
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <Outlet />
      </main>
      <MobileFloatingNav />
      {shouldShowFooter && <Footer />}
    </div>
  );
};

export default MainLayout;