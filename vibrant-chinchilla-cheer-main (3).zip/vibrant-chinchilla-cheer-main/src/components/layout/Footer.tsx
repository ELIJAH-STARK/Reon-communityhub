"use client";

import React from "react";
import { Link } from "react-router-dom";
import { Package2, Heart } from "lucide-react";
import { Capacitor } from "@capacitor/core";

const Footer = () => {
  // Don't render footer in native mobile apps
  if (Capacitor.isNativePlatform()) {
    return null;
  }

  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t bg-muted/30 pt-12 pb-8 px-4">
      <div className="container mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
          <div className="space-y-4">
            <div className="flex items-center gap-2 font-bold text-primary">
              <Package2 className="h-6 w-6" />
              <span className="text-xl tracking-tight">Community Hub</span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed max-w-xs">
              Empowering neighborhoods to share, trade, and connect. Built for people who care about their local community.
            </p>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold uppercase tracking-widest text-[10px] text-foreground">Resources</h4>
            <nav className="flex flex-col gap-2 text-sm text-muted-foreground">
              <Link to="/settings/about-us" className="hover:text-primary transition-colors">About Us</Link>
              <Link to="/map" className="hover:text-primary transition-colors">Neighborhood Map</Link>
              <Link to="/premium" className="hover:text-primary transition-colors">Premium Membership</Link>
            </nav>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold uppercase tracking-widest text-[10px] text-foreground">Legal & Privacy</h4>
            <nav className="flex flex-col gap-2 text-sm text-muted-foreground">
              <Link to="/settings/privacy-policy" className="hover:text-primary transition-colors">Privacy Policy</Link>
              <Link to="/settings/terms-of-service" className="hover:text-primary transition-colors">Terms of Service</Link>
              <Link to="/settings/privacy-policy" className="hover:text-primary transition-colors">Safety Guidelines</Link>
            </nav>
          </div>
        </div>
        <div className="pt-8 border-t flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
          <div className="flex items-center gap-1">
            <span>&copy; {currentYear} Community Hub. All rights reserved.</span>
          </div>
          <div className="flex items-center gap-1">
            <span>Made with</span>
            <Heart className="h-3 w-3 text-red-500 fill-current" />
            <span>by Neighbors for Neighbors</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;