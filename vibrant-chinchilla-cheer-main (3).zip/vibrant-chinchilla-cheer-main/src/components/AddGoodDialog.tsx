"use client";

import React, { useState, useEffect } from "react";
import { Loader2, UploadCloud, X, Plus, Sparkles, Crown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { itemCategories } from "@/lib/constants";
import { useSession } from "@/context/SessionContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useRequests } from "@/context/RequestsContext";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useTranslation } from "@/hooks/useTranslation";

interface AddGoodDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onAddSuccess: () => void;
  addItem: (item: any, mainFile: File, additionalFiles: File[]) => Promise<void>;
}

const AddGoodDialog: React.FC<AddGoodDialogProps> = ({ isOpen, onOpenChange, onAddSuccess, addItem }) => {
  const { t } = useTranslation();
  const { user, isPremium } = useSession();
  const { uploadedItems } = useItems();
  const { uploadedServices } = useServices();
  const { requests } = useRequests();
  const { latitude, longitude, loading: geoLoading } = useGeolocation();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [status] = useState("available");
  const [price, setPrice] = useState<string>("");
  const [mainImage, setMainImage] = useState<File | null>(null);
  const [mainPreview, setMainPreview] = useState<string | null>(null);
  const [additionalImages, setAdditionalImages] = useState<File[]>([]);
  const [additionalPreviews, setAdditionalPreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [extraSlots, setExtraSlots] = useState(0);

  useEffect(() => {
    const fetchExtraSlots = async () => {
      if (user && isOpen) {
        const { data } = await supabase.from('profiles').select('extra_slots').eq('id', user.id).single();
        if (data) setExtraSlots(data.extra_slots || 0);
      }
    };
    fetchExtraSlots();
  }, [user, isOpen]);

  // Corrected: Total count across all types
  const userListingsCount = (uploadedItems?.filter(i => i.user_id === user?.id).length || 0) +
    (uploadedServices?.filter(s => s.user_id === user?.id).length || 0) +
    (requests?.filter(r => r.user_id === user?.id).length || 0);

  const currentLimit = 10 + extraSlots;
  const isLimitReached = !isPremium && userListingsCount >= currentLimit;
  const maxAdditionalPhotos = isPremium ? 10 : 4;

  useEffect(() => {
    if (!isOpen) {
      setName("");
      setDescription("");
      setCategory("");
      setPrice("");
      setMainImage(null);
      setMainPreview(null);
      setAdditionalImages([]);
      setAdditionalPreviews([]);
      setIsUploading(false);
    }
  }, [isOpen]);

  const handleMainImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMainImage(file);
      setMainPreview(URL.createObjectURL(file));
    }
  };

  const handleAdditionalImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + additionalImages.length > maxAdditionalPhotos) {
      toast.error(t('dialogs.selectAtLeastOneImage'));
      return;
    }
    setAdditionalImages(prev => [...prev, ...files]);
    setAdditionalPreviews(prev => [...prev, ...files.map(f => URL.createObjectURL(f))]);
  };

  const removeAdditional = (idx: number) => {
    setAdditionalImages(prev => prev.filter((_, i) => i !== idx));
    setAdditionalPreviews(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLimitReached) {
      toast.error(t('dialogs.noMoreSlots'));
      return;
    }
    if (!user) {
      toast.error(t('errors.youMustLogin'));
      return;
    }
    if (!name.trim() || !category || !mainImage) {
      toast.error(t('dialogs.nameRequired'));
      return;
    }
    if (latitude === null || longitude === null) {
      toast.error(t('errors.waitingForLocation'));
      return;
    }
    setIsUploading(true);
    try {
      const newItem = {
        name: name.trim(),
        description: description.trim(),
        category,
        status,
        price: price === "" ? null : parseFloat(price),
        latitude,
        longitude,
        user_id: user.id
      };
      await addItem(newItem, mainImage, additionalImages);
      onAddSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error("Upload error:", error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{t('dialogs.addGoodTitle')}</DialogTitle>
          <DialogDescription>
            {isLimitReached ? `${t('dialogs.noMoreSlots')} (${userListingsCount}/${currentLimit}).` : t('dialogs.addGoodDescription')}
          </DialogDescription>
        </DialogHeader>
        {isLimitReached ? (
          <div className="py-6 flex flex-col items-center text-center space-y-4">
            <div className="bg-primary/10 p-4 rounded-full">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-lg">{t('dialogs.noMoreSlots')}</h4>
              <p className="text-sm text-muted-foreground max-w-[300px]">
                {t('dialogs.upgradeToPremium')}
              </p>
            </div>
            <Button asChild className="w-full rounded-xl" onClick={() => onOpenChange(false)}>
              <Link to="/premium">{t('buttons.upgradeNow')}</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="item-name">{t('dialogs.itemName')} *</Label>
              <Input
                id="item-name"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder={t('dialogs.itemName')}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t('dialogs.category')} *</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue placeholder={t('dialogs.category')} /></SelectTrigger>
                  <SelectContent>
                    {itemCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="item-price">{t('dialogs.price')}</Label>
                <Input
                  id="item-price"
                  type="number"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                  placeholder={t('dialogs.price')}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="item-desc">{t('dialogs.description')}</Label>
              <Textarea
                id="item-desc"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder={t('dialogs.description')}
              />
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>{t('dialogs.uploadImage')} *</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleMainImage}
                    className="hidden"
                    id="main-img"
                  />
                  <Label
                    htmlFor="main-img"
                    className="flex aspect-square w-24 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed border-muted-foreground/25 transition-colors hover:border-primary/50 bg-muted/30"
                  >
                    {mainPreview ? <img src={mainPreview} className="h-full w-full object-cover rounded-lg" alt="Preview" /> : <UploadCloud className="h-6 w-6 text-muted-foreground" />}
                  </Label>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label>{t('dialogs.addPhotos')} ({maxAdditionalPhotos})</Label>
                  {!isPremium && <Link to="/premium" className="text-[10px] text-yellow-600 font-bold flex items-center gap-1 hover:underline"><Crown className="h-2 w-2" /> {t('premium.upgradeTo')}</Link>}
                </div>
                <div className="flex flex-wrap gap-2">
                  {additionalPreviews.map((p, i) => (
                    <div key={i} className="relative h-20 w-20">
                      <img src={p} className="h-full w-full object-cover rounded-lg border" alt={`Preview ${i}`} />
                      <button
                        type="button"
                        onClick={() => removeAdditional(i)}
                        className="absolute -top-1 -right-1 rounded-full bg-destructive p-0.5 text-white shadow-sm"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  {additionalImages.length < maxAdditionalPhotos && (
                    <>
                      <Input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleAdditionalImages}
                        className="hidden"
                        id="add-img"
                      />
                      <Label
                        htmlFor="add-img"
                        className="flex h-20 w-20 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed transition-colors hover:border-primary/50 bg-muted/30"
                      >
                        <Plus className="h-5 w-5 text-muted-foreground" />
                      </Label>
                    </>
                  )}
                </div>
              </div>
            </div>
            <div className="pt-2">
              <p className="text-[10px] text-muted-foreground text-center">
                * {t('content.photosHelpTrust')}
              </p>
            </div>
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{t('common.cancel')}</Button>
              <Button type="submit" disabled={isUploading || geoLoading}>
                {isUploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />} 
                {t('common.submit')}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AddGoodDialog;