"use client";

import React, { useState, useEffect } from "react";
import { useReviews } from "@/context/ReviewsContext";
import { useSession } from "@/context/SessionContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star, User as UserIcon, Loader2, Flag } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import ReportDialog from "@/components/ReportDialog";

interface ReviewSectionProps {
  userId: string;
  userName: string;
}

const ReviewSection: React.FC<ReviewSectionProps> = ({ userId, userName }) => {
  const { fetchReviewsForUser, addReview, calculateAverageRating } = useReviews();
  const { user: currentUser } = useSession();
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newRating, setNewRating] = useState(5);
  const [newComment, setNewComment] = useState("");
  
  // Reporting state
  const [isReportOpen, setIsReportOpen] = useState(false);
  const [reportingReviewId, setReportingReviewId] = useState<string | null>(null);

  const loadReviews = async () => {
    setLoading(true);
    const data = await fetchReviewsForUser(userId);
    setReviews(data);
    setLoading(false);
  };

  useEffect(() => {
    if (userId) {
      loadReviews();
    }
  }, [userId]);

  const handleSubmitReview = async () => {
    if (!newComment.trim()) return;
    setIsSubmitting(true);
    try {
      await addReview(userId, newRating, newComment.trim());
      setNewComment("");
      setNewRating(5);
      await loadReviews();
    } catch (error) {
      // Error handled in context
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReportClick = (reviewId: string) => {
    setReportingReviewId(reviewId);
    setIsReportOpen(true);
  };

  const avgRating = calculateAverageRating(reviews);
  const canReview = currentUser && currentUser.id !== userId;

  return (
    <div className="space-y-6 mt-8">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-bold">Reviews for {userName}</h3>
        {reviews.length > 0 && (
          <div className="flex items-center gap-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  className={cn(
                    "h-4 w-4",
                    s <= Math.round(avgRating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                  )}
                />
              ))}
            </div>
            <span className="font-bold text-sm">{avgRating.toFixed(1)}</span>
            <span className="text-muted-foreground text-xs">({reviews.length})</span>
          </div>
        )}
      </div>

      {canReview && (
        <Card className="border-dashed bg-muted/20">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Leave a Review</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <span className="text-xs font-medium">Your Rating:</span>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button
                    key={s}
                    type="button"
                    onClick={() => setNewRating(s)}
                    className="focus:outline-none transition-transform active:scale-90 px-0.5"
                  >
                    <Star
                      className={cn(
                        "h-6 w-6 transition-colors",
                        s <= newRating ? "text-yellow-400 fill-yellow-400" : "text-gray-300 hover:text-yellow-200"
                      )}
                    />
                  </button>
                ))}
              </div>
            </div>
            <Textarea
              placeholder="What was your experience like with this neighbor?"
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="min-h-[80px] bg-background text-sm"
            />
            <Button 
              onClick={handleSubmitReview} 
              disabled={isSubmitting || !newComment.trim()}
              className="w-full rounded-xl font-bold"
            >
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Experience
            </Button>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground opacity-50" />
          </div>
        ) : reviews.length === 0 ? (
          <div className="text-center py-10 border rounded-xl border-dashed bg-muted/10">
            <Star className="h-8 w-8 text-muted-foreground/20 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">No reviews yet. Be the first to share your experience!</p>
          </div>
        ) : (
          reviews.map((review) => (
            <Card key={review.id} className="border-none shadow-sm relative group">
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <Avatar className="h-10 w-10 border shadow-sm shrink-0">
                    <AvatarImage src={review.reviewer_profile?.avatar_url} />
                    <AvatarFallback><UserIcon className="h-5 w-5" /></AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <p className="font-bold text-sm truncate">
                        {review.reviewer_profile?.username || 
                         (review.reviewer_profile ? `${review.reviewer_profile.first_name || ''} ${review.reviewer_profile.last_name || ''}`.trim() : "Neighbor")}
                      </p>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                          {new Date(review.created_at).toLocaleDateString()}
                        </span>
                        {currentUser && currentUser.id !== review.reviewer_id && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleReportClick(review.id)}
                            title="Report Review"
                          >
                            <Flag className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="flex">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star
                          key={s}
                          className={cn(
                            "h-3 w-3",
                            s <= review.rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"
                          )}
                        />
                      ))}
                    </div>
                    <p className="text-sm text-foreground/80 mt-2 leading-relaxed whitespace-pre-wrap">{review.comment}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {reportingReviewId && (
        <ReportDialog 
          isOpen={isReportOpen} 
          onOpenChange={setIsReportOpen} 
          targetId={reportingReviewId} 
          targetType="review" 
        />
      )}
    </div>
  );
};

export default ReviewSection;