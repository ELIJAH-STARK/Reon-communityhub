"use client";

import { useEffect } from "react";
import { App as CapacitorApp } from "@capacitor/app";
import { StatusBar, Style } from "@capacitor/status-bar";
import { SplashScreen } from "@capacitor/splash-screen";
import { Keyboard, KeyboardResize } from "@capacitor/keyboard";
import { useNavigate, useLocation } from "react-router-dom";
import { useTheme } from "next-themes";
import { Capacitor } from "@capacitor/core";

/**
 * MobileAppHandler coordinates native mobile features via Capacitor.
 * This ensures the app behaves correctly as a native APK or IPA.
 */
const MobileAppHandler = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { resolvedTheme } = useTheme();

  useEffect(() => {
    // Only execute on actual Android/iOS devices
    if (!Capacitor.isNativePlatform()) return;

    // 1. Splash Screen Management
    // Hide the splash screen manually once the React app has mounted
    const hideSplash = async () => {
      try {
        await SplashScreen.hide();
        console.log("[MobileAppHandler] Splash screen hidden");
      } catch (e) {
        console.warn("[MobileAppHandler] SplashScreen error:", e);
      }
    };
    hideSplash();

    // 2. Keyboard Configuration
    // Ensures the webview resizes properly when the keyboard appears so inputs aren't hidden
    try {
      Keyboard.setResizeMode({ mode: KeyboardResize.Body });
    } catch (e) {
      console.warn("[MobileAppHandler] Keyboard config error:", e);
    }

    // 3. Hardware Back Button (Android specific)
    const backButtonListener = CapacitorApp.addListener('backButton', ({ canGoBack }) => {
      if (location.pathname === '/') {
        // If we are on the home page, exit the app
        CapacitorApp.exitApp();
      } else if (canGoBack) {
        // Otherwise, go back in history
        window.history.back();
      } else {
        // Fallback to home
        navigate('/');
      }
    });

    return () => {
      backButtonListener.then(l => l.remove());
    };
  }, [navigate, location.pathname]);

  // 4. Status Bar Styling
  // Sync the system status bar color with the app's current theme
  useEffect(() => {
    const updateStatusBar = async () => {
      if (Capacitor.isNativePlatform()) {
        try {
          if (resolvedTheme === 'dark') {
            await StatusBar.setStyle({ style: Style.Dark });
            // Dark blue-slate to match tailwind slate-950
            await StatusBar.setBackgroundColor({ color: '#020617' }); 
          } else {
            await StatusBar.setStyle({ style: Style.Light });
            await StatusBar.setBackgroundColor({ color: '#ffffff' });
          }
        } catch (e) {
          console.warn("[MobileAppHandler] StatusBar error:", e);
        }
      }
    };
    updateStatusBar();
  }, [resolvedTheme]);

  return null;
};

export default MobileAppHandler;