"use client";

import React, { useState, useEffect, useId } from "react";
import { Loader2, UploadCloud, Plus, X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { serviceCategories } from "@/lib/constants";
import { useSession } from "@/context/SessionContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useRequests } from "@/context/RequestsContext";
import { useTranslation } from "@/hooks/useTranslation";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";

interface AddServiceDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onAddSuccess: () => void;
  addService: (service: any, mainFile?: File, additionalFiles?: File[]) => Promise<void>;
}

const AddServiceDialog: React.FC<AddServiceDialogProps> = ({ isOpen, onOpenChange, onAddSuccess, addService }) => {
  const { t } = useTranslation();
  const { user, isPremium } = useSession();
  const { uploadedItems } = useItems();
  const { uploadedServices } = useServices();
  const { requests } = useRequests();
  const { latitude, longitude, loading: geoLoading } = useGeolocation();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [status] = useState("available");
  const [price, setPrice] = useState("");
  const [mainImage, setMainImage] = useState<File | null>(null);
  const [mainPreview, setMainPreview] = useState<string | null>(null);
  const [additionalImages, setAdditionalImages] = useState<File[]>([]);
  const [additionalPreviews, setAdditionalPreviews] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [extraSlots, setExtraSlots] = useState(0);
  const dialogTitleId = useId();

  useEffect(() => {
    const fetchExtraSlots = async () => {
      if (user && isOpen) {
        const { data } = await supabase.from('profiles').select('extra_slots').eq('id', user.id).single();
        if (data) setExtraSlots(data.extra_slots || 0);
      }
    };
    fetchExtraSlots();
  }, [user, isOpen]);

  // Corrected: Total count includes all types
  const userListingsCount = (uploadedItems?.filter(i => i.user_id === user?.id).length || 0) +
    (uploadedServices?.filter(s => s.user_id === user?.id).length || 0) +
    (requests?.filter(r => r.user_id === user?.id).length || 0);

  const currentLimit = 10 + extraSlots;
  const isLimitReached = !isPremium && userListingsCount >= currentLimit;

  useEffect(() => {
    if (!isOpen) {
      setName("");
      setDescription("");
      setCategory("");
      setPrice("");
      setMainImage(null);
      setMainPreview(null);
      setAdditionalImages([]);
      setAdditionalPreviews([]);
      setIsUploading(false);
    }
  }, [isOpen]);

  const handleMainImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMainImage(file);
      setMainPreview(URL.createObjectURL(file));
    }
  };

  const handleAdditionalImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length + additionalImages.length > 4) {
      toast.error(t('dialogs.selectAtLeastOneImage'));
      return;
    }
    setAdditionalImages(prev => [...prev, ...files]);
    setAdditionalPreviews(prev => [...prev, ...files.map(f => URL.createObjectURL(f))]);
  };

  const removeAdditional = (idx: number) => {
    setAdditionalImages(prev => prev.filter((_, i) => i !== idx));
    setAdditionalPreviews(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isLimitReached) {
      toast.error(t('dialogs.upgradeToPremium'));
      return;
    }
    if (!user) {
      toast.error(t('errors.sessionNotFound'));
      return;
    }
    if (!name.trim()) {
      toast.error(t('dialogs.nameRequired'));
      return;
    }
    if (!category) {
      toast.error(t('dialogs.categoryRequired'));
      return;
    }
    setIsUploading(true);
    try {
      const newService = {
        name: name.trim(),
        description: description.trim(),
        category,
        status,
        price: price === "" ? null : parseFloat(price),
        latitude,
        longitude,
        user_id: user.id
      };
      await addService(newService, mainImage || undefined, additionalImages);
      onAddSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error("Service error:", error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto" aria-labelledby={dialogTitleId}>
        <DialogHeader>
          <DialogTitle id={dialogTitleId}>{t('dialogs.addServiceTitle')}</DialogTitle>
          <DialogDescription>
            {isLimitReached ? `${t('dialogs.limitReached')} (${userListingsCount}/${currentLimit}).` : t('dialogs.addServiceDescription')}
          </DialogDescription>
        </DialogHeader>
        {isLimitReached ? (
          <div className="py-6 flex flex-col items-center text-center space-y-4">
            <div className="bg-primary/10 p-4 rounded-full">
              <Sparkles className="h-8 w-8 text-primary" />
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-lg">{t('dialogs.goProForUnlimited')}</h4>
              <p className="text-sm text-muted-foreground max-w-[300px]">
                {t('dialogs.limitMessage', { current: userListingsCount, limit: currentLimit })}
              </p>
            </div>
            <Button asChild className="w-full rounded-xl" onClick={() => onOpenChange(false)}>
              <Link to="/premium">{t('buttons.upgradeToPremium')}</Link>
            </Button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="svc-name">{t('dialogs.serviceName')} *</Label>
              <Input
                id="svc-name"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder={t('dialogs.servicePlaceholder')}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>{t('dialogs.category')} *</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue placeholder={t('dialogs.category')} /></SelectTrigger>
                  <SelectContent>
                    {serviceCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="svc-price">{t('dialogs.price')}</Label>
                <Input
                  id="svc-price"
                  type="number"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                  placeholder={t('dialogs.negotiable')}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="svc-desc">{t('dialogs.description')}</Label>
              <Textarea
                id="svc-desc"
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder={t('dialogs.explainOffer')}
              />
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>{t('dialogs.coverPhoto')}</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={handleMainImage}
                    className="hidden"
                    id="service-main"
                  />
                  <Label
                    htmlFor="service-main"
                    className="flex aspect-square w-24 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed transition-colors hover:border-primary/50 bg-muted/30"
                  >
                    {mainPreview ? <img src={mainPreview} className="h-full w-full object-cover rounded-lg" alt="Preview" /> : <UploadCloud className="h-6 w-6 text-muted-foreground" />}
                  </Label>
                </div>
              </div>
              <div className="space-y-2">
                <Label>{t('dialogs.portfolioImages')}</Label>
                <div className="flex flex-wrap gap-2">
                  {additionalPreviews.map((p, i) => (
                    <div key={i} className="relative h-20 w-20">
                      <img src={p} className="h-full w-full object-cover rounded-lg border" alt={`Portfolio preview ${i}`} />
                      <button
                        type="button"
                        onClick={() => removeAdditional(i)}
                        className="absolute -top-1 -right-1 rounded-full bg-destructive p-0.5 text-white shadow-sm"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  {additionalImages.length < 4 && (
                    <>
                      <Input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={handleAdditionalImages}
                        className="hidden"
                        id="service-add"
                      />
                      <Label
                        htmlFor="service-add"
                        className="flex h-20 w-20 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed transition-colors hover:border-primary/50 bg-muted/30"
                      >
                        <Plus className="h-5 w-5 text-muted-foreground" />
                      </Label>
                    </>
                  )}
                </div>
              </div>
            </div>
            <DialogFooter className="pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{t('dialogs.cancel')}</Button>
              <Button type="submit" disabled={isUploading || geoLoading}>
                {isUploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {t('dialogs.shareService')}
              </Button>
            </DialogFooter>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default AddServiceDialog;