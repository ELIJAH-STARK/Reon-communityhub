"use client";

import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Loader2, ShieldCheck, AlertCircle, RefreshCcw } from "lucide-react";

interface SquarePaymentFormProps {
  amount: number;
  onSuccess: (sourceId: string) => Promise<void>;
  isProcessing: boolean;
}

declare global {
  interface Window {
    Square: any;
  }
}

const SquarePaymentForm: React.FC<SquarePaymentFormProps> = ({ amount, onSuccess, isProcessing }) => {
  const [card, setCard] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const initializationRetryRef = useRef(0);

  useEffect(() => {
    // Function to load script if missing
    const loadSquareScript = () => {
      return new Promise((resolve, reject) => {
        if (window.Square) {
          resolve(true);
          return;
        }
        const script = document.createElement('script');
        script.src = "https://sandbox.web.squarecdn.com/v1/payments.js";
        script.onload = () => resolve(true);
        script.onerror = () => reject(new Error("Failed to load script"));
        document.head.appendChild(script);
      });
    };

    const initializeSquare = async () => {
      try {
        // Ensure script is loaded
        await loadSquareScript();

        if (!window.Square) {
          if (initializationRetryRef.current < 20) { // Increased retries
            initializationRetryRef.current++;
            setTimeout(initializeSquare, 500);
            return;
          }
          throw new Error("Square SDK not found on window object.");
        }

        const payments = window.Square.payments(
          import.meta.env.VITE_SQUARE_APP_ID || "sandbox-sq0idb-your-id-here", 
          import.meta.env.VITE_SQUARE_LOCATION_ID || "L8Y1Z5K7Q1W2E"
        );

        const cardInstance = await payments.card();
        await cardInstance.attach('#card-container');
        setCard(cardInstance);
        setIsInitializing(false);
      } catch (e: any) {
        console.error("Square initialization failed", e);
        setError("Square SDK failed to load. Please check your connection or disable ad-blockers.");
        setIsInitializing(false);
      }
    };

    initializeSquare();

    return () => {
      if (card) {
        try {
          card.destroy();
        } catch (e) {}
      }
    };
  }, []);

  const handlePayment = async () => {
    if (!card || isProcessing) return;
    setError(null);

    try {
      const result = await card.tokenize();
      if (result.status === 'OK') {
        await onSuccess(result.token);
      } else {
        setError(result.errors[0].message);
      }
    } catch (e: any) {
      setError("Payment tokenization failed. Please check your card details.");
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in zoom-in duration-300">
      <div className="relative">
        <div 
          id="card-container" 
          className={	"p-4 bg-white rounded-lg border shadow-inner min-h-[90px] transition-opacity " + (isInitializing ? "opacity-20" : "opacity-100") }
        />
        
        {isInitializing && (
          <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Securing Connection...</p>
          </div>
        )}
      </div>
      
      {error && (
        <div className="flex flex-col gap-3 p-3 bg-destructive/10 text-destructive rounded-lg border border-destructive/20 text-xs font-medium">
          <div className="flex items-center gap-2">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{error}</span>
          </div>
          <Button variant="outline" size="sm" onClick={() => window.location.reload()} className="bg-white/50 h-7 text-[10px]">
            <RefreshCcw className="h-3 w-3 mr-1" /> Reload Page
          </Button>
        </div>
      )}
      
      <Button 
        onClick={handlePayment} 
        className="w-full h-12 rounded-xl font-bold text-lg shadow-lg" 
        disabled={isProcessing || isInitializing || !card}
      >
        {isProcessing ? (
          <>
            <Loader2 className="animate-spin mr-2 h-5 w-5" />
            Verifying...
          </>
        ) : (
          <>
            <ShieldCheck className="mr-2 h-5 w-5" />
            Pay ${amount.toFixed(2)} Securely
          </>
        )}
      </Button>
      
      <div className="flex flex-col items-center gap-1">
        <p className="text-[10px] text-muted-foreground text-center flex items-center justify-center gap-1">
          Payments processed by Square. Secure SSL Encrypted.
        </p>
      </div>
    </div>
  );
};

export default SquarePaymentForm;