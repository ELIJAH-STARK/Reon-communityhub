"use client";

import React from "react";
import { useSession } from "@/context/SessionContext";
import { useSystemSettingsContext } from "@/context/SystemSettingsContext";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Crown, Sparkles, X } from "lucide-react";
import { Link } from "react-router-dom";
import AdSenseUnit from "./AdSenseUnit";

interface AdBannerProps {
  position?: "feed" | "sidebar" | "grid";
  useExternalAd?: boolean;
}

const AdBanner: React.FC<AdBannerProps> = ({ position = "feed", useExternalAd = false }) => {
  const { isPremium, loading } = useSession();
  const { settings } = useSystemSettingsContext();
  const [isVisible, setIsVisible] = React.useState(true);

  // Never show ads to Premium members or while loading session, or when premium features disabled
  if (loading || isPremium || !isVisible || !settings.premiumEnabled) {
    return null;
  }

  // If you want to show a real Google Ad instead of an internal promo
  if (useExternalAd) {
    return (
      <div className="w-full py-4 flex justify-center relative group">
        <button 
          onClick={() => setIsVisible(false)} 
          className="absolute -top-2 -right-2 z-10 p-1 bg-background border rounded-full shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <X className="h-3 w-3" />
        </button>
        <AdSenseUnit slot="1234567890" /> {/* REPLACE with your actual Slot ID from AdSense */}
      </div>
    );
  }

  // Sidebar Layout
  if (position === "sidebar") {
    return (
      <Card className="p-4 bg-muted/30 border-dashed relative overflow-hidden group">
        <button onClick={() => setIsVisible(false)} className="absolute top-1 right-1 p-1 opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-foreground">
          <X className="h-3 w-3" />
        </button>
        <div className="space-y-3">
          <div className="bg-primary/10 w-fit p-2 rounded-lg">
            <Crown className="h-4 w-4 text-primary" />
          </div>
          <div className="space-y-1">
            <h4 className="font-bold text-sm">Tired of ads?</h4>
            <p className="text-xs text-muted-foreground">Go Premium for a clean, ad-free experience.</p>
          </div>
          <Button size="sm" variant="outline" className="w-full text-[10px] h-7 font-bold uppercase" asChild>
            <Link to="/premium">Upgrade Now</Link>
          </Button>
        </div>
      </Card>
    );
  }

  // Grid Layout
  if (position === "grid") {
    return (
      <Card className="h-full bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 border-dashed border-2 flex flex-col items-center justify-center p-6 text-center space-y-4 min-h-[300px]">
        <div className="bg-white dark:bg-white/10 p-3 rounded-2xl shadow-sm">
          <Sparkles className="h-6 w-6 text-primary" />
        </div>
        <div className="space-y-1">
          <span className="text-[10px] font-black text-primary uppercase tracking-widest">Sponsored</span>
          <h4 className="font-bold text-sm">Your Ad Here</h4>
          <p className="text-xs text-muted-foreground px-2">Reach everyone in this neighborhood instantly.</p>
        </div>
        <Button size="sm" className="rounded-full font-bold px-6" asChild>
          <Link to="/premium">Boost Post</Link>
        </Button>
      </Card>
    );
  }

  // Large Hero Layout
  return (
    <Card className="w-full overflow-hidden border-none bg-gradient-to-r from-slate-900 to-slate-800 text-white relative shadow-md">
      <button onClick={() => setIsVisible(false)} className="absolute top-2 right-2 p-1 text-white/40 hover:text-white transition-colors">
        <X className="h-4 w-4" />
      </button>
      <div className="p-6 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 bg-primary rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 rotate-3">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-bold bg-white/10 px-2 py-0.5 rounded uppercase tracking-widest text-white/60">Sponsored</span>
              <h3 className="text-lg font-bold">Boost Your Visibility</h3>
            </div>
            <p className="text-sm text-slate-300">Featured listings get 5x more inquiries.</p>
          </div>
        </div>
        <Button className="bg-white text-slate-900 hover:bg-slate-100 font-bold rounded-full px-8 shadow-xl" asChild>
          <Link to="/premium">Learn More</Link>
        </Button>
      </div>
      <div className="absolute -bottom-6 -left-6 h-24 w-24 bg-primary/20 blur-3xl rounded-full" />
    </Card>
  );
};

export default AdBanner;