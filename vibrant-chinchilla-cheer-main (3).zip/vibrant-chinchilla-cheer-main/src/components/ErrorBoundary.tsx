import React from "react";

type Props = {
  children: React.ReactNode;
  fallbackRender?: (error: Error | null) => React.ReactNode;
};

type State = {
  hasError: boolean;
  error: Error | null;
};

class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error) {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // Keep logging minimal and safe
    // eslint-disable-next-line no-console
    console.error("ErrorBoundary caught an error:", error, info);
  }

  render() {
    if (this.state.hasError) {
      if (this.props.fallbackRender) {
        try {
          return this.props.fallbackRender(this.state.error);
        } catch (e) {
          // If fallbackRender throws, fall through to default UI
          // eslint-disable-next-line no-console
          console.error("ErrorBoundary: fallbackRender threw:", e);
        }
      }

      return (
        <div className="p-4 rounded-md bg-red-50 text-red-700">
          <h4 className="font-semibold">Something went wrong</h4>
          <p className="text-sm">An unexpected error occurred while rendering this part of the app. Try refreshing the page.</p>
        </div>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;