"use client";

import React, { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Quote, BookOpen } from "lucide-react";
import { bibleQuotes } from "@/lib/bibleQuotes";

const BibleQuoteCard = () => {
  const dailyQuote = useMemo(() => {
    // We create a persistent "seed" based on the current date (YYYYMMDD)
    const date = new Date();
    const seed = date.getFullYear() * 10000 + (date.getMonth() + 1) * 100 + date.getDate();
    
    // Simple pseudo-random hash to jump around the list based on the date seed
    // This ensures every user sees the same "random" quote for that specific day
    const randomIndex = (seed * 9301 + 49297) % 233280 % bibleQuotes.length;
    
    return bibleQuotes[randomIndex];
  }, []);

  return (
    <Card className="overflow-hidden border-none bg-gradient-to-r from-primary/5 to-orange-500/5 shadow-sm">
      <CardContent className="p-6">
        <div className="flex flex-col items-center text-center space-y-3">
          <div className="bg-primary/10 p-2 rounded-full">
            <BookOpen className="h-5 w-5 text-primary" />
          </div>
          <div className="relative px-8">
            <Quote className="absolute top-0 left-0 h-4 w-4 text-primary/20 -rotate-180" />
            <p className="text-lg font-medium italic text-foreground/90 leading-relaxed">
              "{dailyQuote.text}"
            </p>
            <Quote className="absolute bottom-0 right-0 h-4 w-4 text-primary/20" />
          </div>
          <p className="text-sm font-bold text-primary tracking-wide">
            — {dailyQuote.reference}
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default BibleQuoteCard;