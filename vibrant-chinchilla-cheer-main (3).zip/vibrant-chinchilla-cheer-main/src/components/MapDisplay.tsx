"use client";

import React, { useState, useMemo } from "react";
// Switching to the specific maplibre entry point to fix Vite resolution errors
import { Map, Marker, Popup, NavigationControl, GeolocateControl } from "react-map-gl/maplibre";
import "maplibre-gl/dist/maplibre-gl.css";
import maplibregl from "maplibre-gl";
import { Badge } from "@/components/ui/badge";
import { Briefcase, User, X, CheckCircle2, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

interface MapDisplayProps {
  center: [number, number];
  zoom?: number;
  items?: any[];
  services?: any[];
  requests?: any[];
}

const MapDisplay = ({ center, zoom = 13, items = [], services = [], requests = [] }: MapDisplayProps) => {
  const [selectedMarker, setSelectedMarker] = useState<any>(null);
  
  const validItems = useMemo(() => 
    items.filter(i => typeof i.latitude === 'number' && typeof i.longitude === 'number'), 
    [items]
  );
  
  const validServices = useMemo(() => 
    services.filter(s => typeof s.latitude === 'number' && typeof s.longitude === 'number'), 
    [services]
  );
  
  const validRequests = useMemo(() => 
    requests.filter(r => typeof r.latitude === 'number' && typeof r.longitude === 'number'), 
    [requests]
  );
  
  const initialViewState = useMemo(() => ({
    latitude: center[0],
    longitude: center[1],
    zoom: zoom
  }), [center, zoom]);

  // Use environment variable for map style or default to carto voyager
  const mapStyle = import.meta.env.VITE_MAP_STYLE_URL || "https://basemaps.cartocdn.com/gl/voyager-gl-style/style.json";

  return (
    <div className="h-full w-full bg-muted relative overflow-hidden rounded-lg">
      <Map
        mapLib={maplibregl}
        initialViewState={initialViewState}
        style={{ width: '100%', height: '100%' }}
        mapStyle={mapStyle}
      >
        <NavigationControl position="top-right" />
        <GeolocateControl position="top-right" trackUserLocation={true} />
        
        {/* User Location Marker */}
        <Marker latitude={center[0]} longitude={center[1]}>
          <div className="bg-blue-600 p-1.5 rounded-full border-2 border-white shadow-xl">
            <User className="w-4 h-4 text-white" />
          </div>
        </Marker>
        
        {/* Items Markers */}
        {validItems.map((item) => (
          <Marker
            key={`item-${item.id}`}
            latitude={item.latitude}
            longitude={item.longitude}
            onClick={e => {
              e.originalEvent.stopPropagation();
              setSelectedMarker({ ...item, type: 'item', verified: item.is_seller_verified });
            }}
          >
            <div className="cursor-pointer transition-transform hover:scale-110 active:scale-95">
              <div className="p-1.5 rounded-full border-2 border-white shadow-lg bg-orange-500">
                <User className="w-4 h-4 text-white" />
              </div>
            </div>
          </Marker>
        ))}
        
        {/* Services Markers */}
        {validServices.map((service) => (
          <Marker
            key={`service-${service.id}`}
            latitude={service.latitude}
            longitude={service.longitude}
            onClick={e => {
              e.originalEvent.stopPropagation();
              setSelectedMarker({ ...service, type: 'service', verified: service.is_provider_verified });
            }}
          >
            <div className="cursor-pointer transition-transform hover:scale-110 active:scale-95">
              <div className="p-1.5 rounded-full border-2 border-white shadow-lg bg-blue-500">
                <Briefcase className="w-4 h-4 text-white" />
              </div>
            </div>
          </Marker>
        ))}
        
        {/* Requests Markers */}
        {validRequests.map((request) => (
          <Marker
            key={`request-${request.id}`}
            latitude={request.latitude}
            longitude={request.longitude}
            onClick={e => {
              e.originalEvent.stopPropagation();
              setSelectedMarker({ ...request, type: 'request' });
            }}
          >
            <div className="cursor-pointer transition-transform hover:scale-110 active:scale-95">
              <div className="p-1.5 rounded-full border-2 border-white shadow-lg bg-green-500">
                <HelpCircle className="w-4 h-4 text-white" />
              </div>
            </div>
          </Marker>
        ))}
        
        {/* Popup for selected marker */}
        {selectedMarker && (
          <Popup
            latitude={selectedMarker.latitude}
            longitude={selectedMarker.longitude}
            anchor="bottom"
            onClose={() => setSelectedMarker(null)}
            closeButton={false}
            className="z-50"
            offset={10}
          >
            <div className="p-2 min-w-[180px] max-w-[220px] relative bg-black text-white">
              <Button 
                variant="ghost" 
                size="icon" 
                className="absolute -top-1 -right-1 h-6 w-6 rounded-full text-white hover:bg-white/20"
                onClick={() => setSelectedMarker(null)}
              >
                <X className="h-3 w-3" />
              </Button>
              
              <div className="flex items-center gap-1.5 mb-1 pr-4">
                <h4 className="font-bold text-sm truncate text-white">{selectedMarker.name || selectedMarker.title}</h4>
                {selectedMarker.verified && (
                  <CheckCircle2 className="h-3 w-3 text-blue-500 fill-blue-500 text-white shrink-0" />
                )}
              </div>
              
              <p className="text-[10px] text-gray-300 mb-2 line-clamp-2">
                {selectedMarker.description}
              </p>
              
              <div className="flex flex-wrap gap-1 mb-3">
                <Badge variant="outline" className="text-[9px] px-1 py-0 h-4 border-gray-600 text-white bg-gray-900">
                  {selectedMarker.category}
                </Badge>
                <Badge 
                  variant="secondary" 
                  className="text-[9px] px-1 py-0 h-4 bg-white/10 text-white border-none"
                >
                  {selectedMarker.status}
                </Badge>
              </div>
              
              <a 
                href={
                  selectedMarker.type === 'item' ? `/goods/${selectedMarker.id}` :
                  selectedMarker.type === 'service' ? `/services/${selectedMarker.id}` :
                  `/requests`
                } 
                className="block w-full text-center py-1.5 rounded-md bg-white text-black text-[10px] font-bold hover:bg-gray-200 transition-colors"
              >
                {selectedMarker.type === 'request' ? "View Requests" : "View Details"}
              </a>
            </div>
          </Popup>
        )}
      </Map>
    </div>
  );
};

export default MapDisplay;