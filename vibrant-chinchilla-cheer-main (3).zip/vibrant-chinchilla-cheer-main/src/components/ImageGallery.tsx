"use client";

import React, { useState } from "react";
import { cn } from "@/lib/utils";

interface ImageGalleryProps {
  mainImage: string;
  additionalImages?: string[];
  alt: string;
}

const ImageGallery: React.FC<ImageGalleryProps> = ({ mainImage, additionalImages = [], alt }) => {
  const allImages = [mainImage, ...additionalImages].filter(Boolean);
  const [selectedImage, setSelectedImage] = useState(mainImage);

  if (allImages.length === 1) {
    return <img src={mainImage} alt={alt} className="w-full h-80 object-cover rounded-xl" />;
  }

  return (
    <div className="space-y-4">
      <div className="relative aspect-video w-full overflow-hidden rounded-xl border bg-muted">
        <img src={selectedImage} alt={alt} className="w-full h-full object-cover transition-all" />
      </div>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        {allImages.map((img, idx) => (
          <button
            key={idx}
            onClick={() => setSelectedImage(img)}
            className={cn(
              "relative h-20 w-20 shrink-0 overflow-hidden rounded-md border-2 transition-all",
              selectedImage === img ? "border-primary" : "border-transparent opacity-70 hover:opacity-100"
            )}
          >
            <img src={img} alt={`${alt} ${idx}`} className="h-full w-full object-cover" />
          </button>
        ))}
      </div>
    </div>
  );
};

export default ImageGallery;