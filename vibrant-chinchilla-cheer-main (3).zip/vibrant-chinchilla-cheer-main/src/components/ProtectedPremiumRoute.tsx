import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useSystemSettingsContext } from "@/context/SystemSettingsContext";

interface ProtectedPremiumRouteProps {
  children: React.ReactNode;
}

export const ProtectedPremiumRoute: React.FC<ProtectedPremiumRouteProps> = ({ children }) => {
  const navigate = useNavigate();
  const { settings, isLoading } = useSystemSettingsContext();

  useEffect(() => {
    if (!isLoading && !settings.premiumEnabled) {
      navigate("/", { replace: true });
    }
  }, [settings.premiumEnabled, isLoading, navigate]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!settings.premiumEnabled) {
    return null;
  }

  return <>{children}</>;
};

export default ProtectedPremiumRoute;
