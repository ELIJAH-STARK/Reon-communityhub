"use client";

import React, { useState, useEffect, useId } from "react";
import { Loader2, Edit, X, Plus, UploadCloud } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { itemCategories } from "@/lib/constants";
import { useSession } from "@/context/SessionContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useTranslation } from "@/hooks/useTranslation";

interface UploadedItem {
  id: string;
  name: string;
  description: string;
  category: string;
  image_url: string;
  additional_images: string[];
  latitude: number | null;
  longitude: number | null;
  user_id: string;
  status: string;
  price: number | null;
  discount_percentage: number | null;
}

interface EditGoodDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onEditSuccess: () => void;
  updateItem: (id: string, updates: any, mainFile?: File, newFiles?: File[], remainingUrls?: string[]) => Promise<void>;
  editingItem: UploadedItem | null;
}

const itemStatuses = ["available", "reserved", "sold"];

const EditGoodDialog: React.FC<EditGoodDialogProps> = ({ isOpen, onOpenChange, onEditSuccess, updateItem, editingItem }) => {
  const { t } = useTranslation();
  const { user, isPremium } = useSession();
  const { latitude, longitude, loading: geoLoading } = useGeolocation();

  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("available");
  const [price, setPrice] = useState("");
  const [discount, setDiscount] = useState("");
  
  // Gallery State
  const [mainImageFile, setMainImageFile] = useState<File | null>(null);
  const [mainPreview, setMainPreview] = useState<string | null>(null);
  const [existingUrls, setExistingUrls] = useState<string[]>([]);
  const [newImageFiles, setNewImageFiles] = useState<File[]>([]);
  const [newPreviews, setNewPreviews] = useState<string[]>([]);

  const [isUploading, setIsUploading] = useState(false);
  const dialogTitleId = useId();

  const maxTotal = isPremium ? 11 : 5;

  useEffect(() => {
    if (isOpen && editingItem) {
      setName(editingItem.name);
      setDescription(editingItem.description || "");
      setCategory(editingItem.category);
      setStatus(editingItem.status);
      setPrice(editingItem.price?.toString() || "");
      setDiscount(editingItem.discount_percentage?.toString() || "");
      setExistingUrls(editingItem.additional_images || []);
      setMainPreview(editingItem.image_url);
      setMainImageFile(null);
      setNewImageFiles([]);
      setNewPreviews([]);
    }
  }, [isOpen, editingItem]);

  const handleMainImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setMainImageFile(file);
      setMainPreview(URL.createObjectURL(file));
    }
  };

  const handleAddNewImages = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const currentTotal = 1 + existingUrls.length + newImageFiles.length;
    
    if (currentTotal + files.length > maxTotal) {
      toast.error(t('dialogs.selectAtLeastOneImage'));
      return;
    }

    setNewImageFiles(prev => [...prev, ...files]);
    setNewPreviews(prev => [...prev, ...files.map(f => URL.createObjectURL(f))]);
  };

  const removeExistingUrl = (url: string) => {
    setExistingUrls(prev => prev.filter(u => u !== url));
  };

  const removeNewFile = (index: number) => {
    setNewImageFiles(prev => prev.filter((_, i) => i !== index));
    setNewPreviews(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem || !user) return;

    setIsUploading(true);
    try {
      const updates = {
        name,
        description,
        category,
        status,
        price: price === "" ? null : parseFloat(price),
        discount_percentage: discount === "" ? null : parseFloat(discount),
        latitude: latitude || editingItem.latitude,
        longitude: longitude || editingItem.longitude
      };

      await updateItem(editingItem.id, updates, mainImageFile || undefined, newImageFiles, existingUrls);
      onEditSuccess();
      onOpenChange(false);
    } catch (error) {
      console.error(error);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle id={dialogTitleId}>{t('dialogs.editGood')}</DialogTitle>
          <DialogDescription>{t('dialogs.editGoodDescription')}</DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>{t('dialogs.itemName')}</Label>
            <Input value={name} onChange={e => setName(e.target.value)} required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('dialogs.category')}</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {itemCategories.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>{t('content.status')}</Label>
              <Select value={status} onValueChange={setStatus}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {itemStatuses.map(s => <SelectItem key={s} value={s}>{s.toUpperCase()}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>{t('dialogs.price')}</Label>
              <Input type="number" value={price} onChange={e => setPrice(e.target.value)} placeholder={t('dialogs.free')} />
            </div>
            <div className="space-y-2">
              <Label>{t('dialogs.discount')}</Label>
              <Input type="number" value={discount} onChange={e => setDiscount(e.target.value)} placeholder="0" />
            </div>
          </div>

          <div className="space-y-2">
            <Label>{t('dialogs.description')}</Label>
            <Textarea value={description} onChange={e => setDescription(e.target.value)} rows={3} />
          </div>

          <div className="space-y-4 pt-2">
            <Label className="text-primary font-bold">{t('dialogs.photoGallery')}</Label>
            
            {/* Main Image */}
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold text-muted-foreground">{t('dialogs.coverPhoto')}</span>
              <div className="flex items-center gap-4">
                <Input type="file" accept="image/*" onChange={handleMainImage} className="hidden" id="edit-main" />
                <Label htmlFor="edit-main" className="flex aspect-square w-24 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed border-primary/20 bg-muted/30 overflow-hidden">
                  {mainPreview ? <img src={mainPreview} className="h-full w-full object-cover" /> : <UploadCloud className="h-6 w-6" />}
                </Label>
              </div>
            </div>

            {/* Additional Images */}
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold text-muted-foreground">{t('dialogs.gallery')} ({existingUrls.length + newImageFiles.length} / {maxTotal - 1})</span>
              <div className="flex flex-wrap gap-2">
                {/* Existing */}
                {existingUrls.map((url, i) => (
                  <div key={`exist-${i}`} className="relative h-20 w-20">
                    <img src={url} className="h-full w-full object-cover rounded-lg border" />
                    <button type="button" onClick={() => removeExistingUrl(url)} className="absolute -top-1 -right-1 rounded-full bg-destructive p-0.5 text-white shadow-sm">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
                {/* New */}
                {newPreviews.map((p, i) => (
                  <div key={`new-${i}`} className="relative h-20 w-20">
                    <img src={p} className="h-full w-full object-cover rounded-lg border border-primary/40" />
                    <button type="button" onClick={() => removeNewFile(i)} className="absolute -top-1 -right-1 rounded-full bg-destructive p-0.5 text-white shadow-sm">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
                {/* Add More Button */}
                {(existingUrls.length + newImageFiles.length) < (maxTotal - 1) && (
                  <>
                    <Input type="file" accept="image/*" multiple onChange={handleAddNewImages} className="hidden" id="edit-add" />
                    <Label htmlFor="edit-add" className="flex h-20 w-20 cursor-pointer items-center justify-center rounded-lg border-2 border-dashed hover:border-primary/50 bg-muted/30">
                      <Plus className="h-5 w-5 text-muted-foreground" />
                    </Label>
                  </>
                )}
              </div>
            </div>
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>{t('dialogs.cancel')}</Button>
            <Button type="submit" disabled={isUploading}>
              {isUploading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {t('dialogs.saveChanges')}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default EditGoodDialog;