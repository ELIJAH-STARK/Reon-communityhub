"use client";

import { useEffect, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";

/**
 * PresenceSync updates the user's 'last_seen' timestamp in the database
 * every 3 minutes while the app is open.
 */
const PresenceSync = () => {
  const { user } = useSession();
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    const updatePresence = async () => {
      if (!user) return;

      try {
        await supabase
          .from('profiles')
          .update({ last_seen: new Date().toISOString() })
          .eq('id', user.id);
          
        console.log("[PresenceSync] Heartbeat sent");
      } catch (e) {
        // Fail silently
      }
    };

    if (user) {
      updatePresence(); // Initial update
      intervalRef.current = window.setInterval(updatePresence, 180000); // Every 3 mins
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [user]);

  return null;
};

export default PresenceSync;