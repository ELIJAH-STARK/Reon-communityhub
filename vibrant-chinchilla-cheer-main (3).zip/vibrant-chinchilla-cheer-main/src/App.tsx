"use client";

import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import NotFound from "./pages/NotFound";
import MainLayout from "./components/layout/MainLayout";
import Index from "./pages/Index";
import GoodsPage from "./pages/GoodsPage";
import ServicesPage from "./pages/ServicesPage";
import MyGoodsPage from "./pages/MyGoodsPage";
import MyServicesPage from "./pages/MyServicesPage";
import MapPage from "./pages/MapPage";
import SettingsPage from "./pages/SettingsPage";
import AboutUsPage from "./pages/AboutUsPage";
import PrivacyPolicyPage from "./pages/PrivacyPolicyPage";
import TermsOfServicePage from "./pages/TermsOfServicePage";
import GoodDetailPage from "./pages/GoodDetailPage";
import ServiceDetailPage from "./pages/ServiceDetailPage";
import RequestDetailPage from "./pages/RequestDetailPage";
import LoginPage from "./pages/LoginPage";
import ProfilePage from "./pages/ProfilePage";
import PublicProfilePage from "./pages/PublicProfilePage";
import MessagesPage from "./pages/MessagesPage";
import ChatPage from "./pages/ChatPage";
import FavoritesPage from "./pages/FavoritesPage";
import AdminReportsPage from "./pages/AdminReportsPage";
import AdminUsersPage from "./pages/AdminUsersPage";
import AdminAnnouncementsPage from "./pages/AdminAnnouncementsPage";
import AdminRevenuePage from "./pages/AdminRevenuePage";
import AdminDashboard from "./pages/AdminDashboard"; // Added import
import BannedPage from "./pages/BannedPage";
import PremiumPage from "./pages/PremiumPage";
import CheckoutPage from "./pages/CheckoutPage";
import { ItemsProvider } from "./context/ItemsContext";
import { ServicesProvider } from "./context/ServicesContext";
import { SessionContextProvider } from "./context/SessionContext";
import { MessagesProvider } from "./context/MessagesContext";
import { ReviewsProvider } from "./context/ReviewsContext";
import { FavoritesProvider } from "./context/FavoritesContext";
import { NotificationsProvider } from "./context/NotificationsContext";
import { SystemSettingsProvider } from "./context/SystemSettingsContext";
import { LanguageProvider } from "./context/LanguageContext";
import { ThemeProvider } from "next-themes";
import { UserPreferencesProvider, useUserPreferences } from "./context/UserPreferencesContext";
import ErrorBoundary from "./components/ErrorBoundary";
import { useEffect } from "react";
import { hexToHsl } from "./lib/utils";
import RequestsPage from "./pages/RequestsPage";
import MyRequestsPage from "./pages/MyRequestsPage";
import { RequestsProvider } from "./context/RequestsContext";
import MobileAppHandler from "./components/MobileAppHandler";
import ProtectedPremiumRoute from "./components/ProtectedPremiumRoute";

const queryClient = new QueryClient();

const AppContent = () => {
  const { preferences } = useUserPreferences();

  useEffect(() => {
    const hslColor = hexToHsl(preferences.accentColor);
    if (hslColor) {
      document.documentElement.style.setProperty('--primary', hslColor);
      document.documentElement.style.setProperty('--sidebar-primary', hslColor);
    }
  }, [preferences.accentColor]);

  return (
    <ErrorBoundary>
      <TooltipProvider>
        <Sonner />
        <BrowserRouter future={{ v7_relativeSplatPath: true, v7_startTransition: true }}>
          <MobileAppHandler />
          <SystemSettingsProvider>
            <SessionContextProvider>
              <MessagesProvider>
                <NotificationsProvider>
                  <ItemsProvider>
                    <ServicesProvider>
                      <RequestsProvider>
                        <ReviewsProvider>
                          <FavoritesProvider>
                          <Routes>
                            <Route path="/login" element={<LoginPage />} />
                            <Route path="/banned" element={<BannedPage />} />
                            <Route path="/" element={<MainLayout />}>
                              <Route index element={<Index />} />
                              <Route path="goods" element={<GoodsPage />} />
                              <Route path="goods/:id" element={<GoodDetailPage />} />
                              <Route path="services" element={<ServicesPage />} />
                              <Route path="services/:id" element={<ServiceDetailPage />} />
                              <Route path="requests" element={<RequestsPage />} />
                              <Route path="requests/:id" element={<RequestDetailPage />} />
                              <Route path="my-requests" element={<MyRequestsPage />} />
                              <Route path="my-goods" element={<MyGoodsPage />} />
                              <Route path="my-services" element={<MyServicesPage />} />
                              <Route path="map" element={<MapPage />} />
                              <Route path="messages" element={<MessagesPage />} />
                              <Route path="chat/:otherUserId/:itemId?/:serviceId?" element={<ChatPage />} />
                              <Route path="profile" element={<ProfilePage />} />
                              <Route path="profile/:id" element={<PublicProfilePage />} />
                              <Route path="favorites" element={<FavoritesPage />} />
                              <Route path="settings" element={<SettingsPage />} />
                              <Route path="premium" element={<ProtectedPremiumRoute><PremiumPage /></ProtectedPremiumRoute>} />
                              <Route path="checkout" element={<CheckoutPage />} />
                              <Route path="settings/about-us" element={<AboutUsPage />} />
                              <Route path="settings/privacy-policy" element={<PrivacyPolicyPage />} />
                              <Route path="settings/terms-of-service" element={<TermsOfServicePage />} />
                              <Route path="admin" element={<AdminDashboard />} /> {/* New Admin route */}
                              <Route path="admin/reports" element={<AdminReportsPage />} />
                              <Route path="admin/users" element={<AdminUsersPage />} />
                              <Route path="admin/announcements" element={<AdminAnnouncementsPage />} />
                              <Route path="admin/revenue" element={<AdminRevenuePage />} />
                            </Route>
                            <Route path="*" element={<NotFound />} />
                          </Routes>
                        </FavoritesProvider>
                      </ReviewsProvider>
                    </RequestsProvider>
                  </ServicesProvider>
                </ItemsProvider>
              </NotificationsProvider>
            </MessagesProvider>
          </SessionContextProvider>
          </SystemSettingsProvider>
        </BrowserRouter>
      </TooltipProvider>
    </ErrorBoundary>
  );
};

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
      <LanguageProvider>
        <UserPreferencesProvider>
          <AppContent />
        </UserPreferencesProvider>
      </LanguageProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;