import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./globals.css";
// Leaflet CSS removed to prevent conflicts with the new Mapbox-based engine

createRoot(document.getElementById("root")!).render(<App />);