"use client";
import React, { useState, useEffect, useCallback, useRef } from "react";

interface GeolocationState {
  latitude: number | null;
  longitude: number | null;
  error: string | null;
  loading: boolean;
  permissionStatus: PermissionState | null;
}

/**
 * useGeolocation provides a non-blocking hook to acquire user coordinates.
 * Updated to reduce caching for better real-time feel during movement.
 */
export function useGeolocation(): GeolocationState {
  const [state, setState] = useState<GeolocationState>({
    latitude: null,
    longitude: null,
    error: null,
    loading: true,
    permissionStatus: null,
  });

  const isAcquiring = useRef(false);

  const getLocation = useCallback(() => {
    if (isAcquiring.current) return;
    isAcquiring.current = true;

    if (!navigator.geolocation) {
      setState(prev => ({ ...prev, error: "Geolocation not supported", loading: false }));
      return;
    }

    // We use a 5-second timeout to allow the GPS to warm up without hanging the UI
    const options: PositionOptions = {
      enableHighAccuracy: true, // Switched to true for better precision
      timeout: 5000, 
      maximumAge: 10000, // Reduced from 5 mins to 10 seconds for "Live" accuracy
    };

    navigator.geolocation.getCurrentPosition(
      (position) => {
        setState({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          error: null,
          loading: false,
          permissionStatus: "granted",
        });
        isAcquiring.current = false;
      },
      (err) => {
        setState(prev => ({
          ...prev,
          error: err.code === 3 ? "GPS timed out" : "Location unavailable",
          loading: false,
        }));
        isAcquiring.current = false;
      },
      options
    );
  }, []);

  useEffect(() => {
    const checkPerms = async () => {
      if (!navigator.permissions) return;
      try {
        const result = await navigator.permissions.query({ name: "geolocation" as PermissionName });
        setState(prev => ({ ...prev, permissionStatus: result.state }));
        result.onchange = () => setState(prev => ({ ...prev, permissionStatus: result.state }));
      } catch (e) {}
    };

    checkPerms();
    getLocation();
  }, [getLocation]);

  return state;
}