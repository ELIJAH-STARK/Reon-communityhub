"use client";

import { Haptics, ImpactStyle, NotificationType } from "@capacitor/haptics";
import { Capacitor } from "@capacitor/core";

/**
 * useHaptics provides methods to trigger physical vibrations on mobile devices.
 * It fails silently on web/desktop.
 */
export function useHaptics() {
  const isNative = Capacitor.isNativePlatform();

  const impact = async (style: ImpactStyle = ImpactStyle.Medium) => {
    if (isNative) {
      try {
        await Haptics.impact({ style });
      } catch (e) {}
    }
  };

  const notification = async (type: NotificationType = NotificationType.Success) => {
    if (isNative) {
      try {
        await Haptics.notification({ type });
      } catch (e) {}
    }
  };

  const selection = async () => {
    if (isNative) {
      try {
        await Haptics.selectionStart();
      } catch (e) {}
    }
  };

  return { impact, notification, selection };
}