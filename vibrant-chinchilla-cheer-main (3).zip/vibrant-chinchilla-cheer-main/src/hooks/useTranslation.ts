import { useLanguage } from '../context/LanguageContext';

interface UseTranslationReturn {
  t: (key: string, defaultValue?: string) => string;
}

/**
 * Hook to use translations in components
 * Usage: const { t } = useTranslation();
 *        const homeLabel = t('common.home');
 *        const customLabel = t('non.existent.key', 'Default Home');
 */
export const useTranslation = (): UseTranslationReturn => {
  const { t } = useLanguage();

  return {
    t,
  };
};

export default useTranslation;
