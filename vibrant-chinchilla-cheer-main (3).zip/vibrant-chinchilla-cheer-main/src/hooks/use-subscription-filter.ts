"use client";

import { useMemo } from "react";
import { useSession } from "@/context/SessionContext";

/**
 * useSubscriptionFilter takes a set of items, services, and requests
 * and identifies which ones are 'held' (grayed out) because the user's
 * subscription has expired and they exceed the 10-item free limit.
 */
export function useSubscriptionFilter(goods: any[], services: any[], requests: any[]) {
  const { isPremium, hasExtraSlots } = useSession();

  const allUserListings = useMemo(() => {
    // Combine all types into one sorted list by date
    const combined = [
      ...goods.map(g => ({ ...g, type: 'good' })),
      ...services.map(s => ({ ...s, type: 'service' })),
      ...requests.map(r => ({ ...r, type: 'request' }))
    ].sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

    const isSubscriptionActive = isPremium || hasExtraSlots;
    const limit = 10;

    return combined.map((listing, index) => {
      // If subscription is expired/inactive, everything after the 10th item is held
      const isHeld = !isSubscriptionActive && index >= limit;
      return {
        ...listing,
        isHeld
      };
    });
  }, [goods, services, requests, isPremium, hasExtraSlots]);

  const heldIds = useMemo(() => 
    new Set(allUserListings.filter(l => l.isHeld).map(l => l.id)), 
  [allUserListings]);

  return { allUserListings, heldIds };
}