import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const useSystemSettings = () => {
  const queryClient = useQueryClient();

  const { data: settings, isLoading } = useQuery({
    queryKey: ["site-settings"],
    queryFn: async () => {
      // We'll use a 'settings' table or fallback to a default if it doesn't exist yet
      const { data, error } = await supabase
        .from("site_settings")
        .select("*")
        .single();

      if (error && error.code !== "PGRST116") { // PGRST116 is 'no rows returned'
        console.error("Error fetching settings:", error);
      }
      
      // Default state if nothing in DB
      return data || { premium_enabled: true };
    },
  });

  const togglePremium = useMutation({
    mutationFn: async (enabled: boolean) => {
      const { error } = await supabase
        .from("site_settings")
        .upsert({ id: 1, premium_enabled: enabled });

      if (error) throw error;
      return enabled;
    },
    onSuccess: (enabled) => {
      queryClient.setQueryData(["site-settings"], (old: any) => ({ ...old, premium_enabled: enabled }));
      toast.success(`Premium features \${enabled ? "enabled" : "disabled"}`);
    },
    onError: (error: any) => {
      toast.error("Failed to update settings: " + error.message);
    },
  });

  return {
    premiumEnabled: settings?.premium_enabled ?? true,
    isLoading,
    updatePremium: togglePremium.mutate,
    isUpdating: togglePremium.isPending
  };
};