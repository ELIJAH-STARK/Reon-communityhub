"use client";

import React, { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, DollarSign, Package2, ShieldAlert, TrendingUp, Lock, Users, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

const AdminAuditPage = () => {
  const [stats, setStats] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [heldListings, setHeldListings] = useState<any[]>([]);
  const [bannedUsers, setBannedUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [statsRes, transRes, heldRes, bannedRes] = await Promise.all([
        supabase.from('admin_revenue_stats').select('*'),
        supabase.from('transactions').select('*, profiles(first_name, last_name, username)').order('created_at', { ascending: false }).limit(20),
        supabase.from('held_listings_audit_view').select('*'),
        supabase.from('banned_users_view').select('*')
      ]);

      if (statsRes.data) setStats(statsRes.data);
      if (transRes.data) setTransactions(transRes.data);
      if (heldRes.data) setHeldListings(heldRes.data);
      if (bannedRes.data) setBannedUsers(bannedRes.data);
    } catch (err) {
      toast.error("Failed to load audit data.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  // Group stats for the summary cards (combining 1slot and 4slot)
  const groupedStats = useMemo(() => {
    const summary = {
      premium: { total: 0, count: 0 },
      slots: { total: 0, count: 0 }
    };

    stats.forEach(s => {
      if (s.item_type === 'premium') {
        summary.premium.total += s.total_revenue || 0;
        summary.premium.count += s.count || 0;
      } else {
        summary.slots.total += s.total_revenue || 0;
        summary.slots.count += s.count || 0;
      }
    });

    return summary;
  }, [stats]);

  const totalRevenue = stats.reduce((acc, curr) => acc + (curr.total_revenue || 0), 0);

  if (loading) return (
    <div className="flex justify-center py-20">
      <Loader2 className="animate-spin h-8 w-8 text-primary" />
    </div>
  );

  return (
    <div className="container max-w-6xl mx-auto py-8 space-y-8 px-4">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <TrendingUp className="h-8 w-8 text-primary" />
          Hub Analytics & Audit
        </h1>
        <p className="text-muted-foreground">Monitoring community growth and platform health.</p>
      </div>

      <Tabs defaultValue="revenue" className="w-full">
        <TabsList className="grid w-full grid-cols-3 max-w-md bg-muted/50 p-1 rounded-xl">
          <TabsTrigger value="revenue" className="rounded-lg">Revenue</TabsTrigger>
          <TabsTrigger value="listings" className="rounded-lg">Capacity</TabsTrigger>
          <TabsTrigger value="safety" className="rounded-lg">Safety</TabsTrigger>
        </TabsList>

        <TabsContent value="revenue" className="space-y-6 mt-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader className="pb-2">
                <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Total Revenue</CardDescription>
                <CardTitle className="text-3xl font-black text-primary">${totalRevenue.toFixed(2)}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs font-bold text-green-600">All-time processed</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Subscriptions</CardDescription>
                <CardTitle className="text-2xl font-bold">${groupedStats.premium.total.toFixed(2)}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">{groupedStats.premium.count} premium members</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Extra Slots</CardDescription>
                <CardTitle className="text-2xl font-bold">${groupedStats.slots.total.toFixed(2)}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-xs text-muted-foreground">{groupedStats.slots.count} slot purchases</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <DollarSign className="h-5 w-5 text-primary" />
                Recent Transactions
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Neighbor</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {transactions.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">No transactions recorded.</TableCell></TableRow>
                  ) : (
                    transactions.map((t) => (
                      <TableRow key={t.id}>
                        <TableCell className="font-medium">{t.profiles?.username || "Neighbor"}</TableCell>
                        <TableCell><Badge variant="secondary" className="text-[9px] uppercase">{t.item_type}</Badge></TableCell>
                        <TableCell className="font-bold text-primary">${t.amount.toFixed(2)}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{new Date(t.created_at).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="listings" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Lock className="h-5 w-5 text-orange-500" />
                Held Listings Audit
              </CardTitle>
              <CardDescription>Items hidden from the public view because user is over their limit.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Owner</TableHead>
                    <TableHead>Hidden Listing</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Created</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {heldListings.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-12 text-muted-foreground">No hidden listings found. All neighbors are within limits!</TableCell></TableRow>
                  ) : (
                    heldListings.map((h) => (
                      <TableRow key={h.listing_id}>
                        <TableCell className="font-medium">{h.user_name || "Neighbor"}</TableCell>
                        <TableCell className="text-sm">{h.listing_name}</TableCell>
                        <TableCell><Badge variant="outline" className="text-[9px] uppercase">{h.listing_type}</Badge></TableCell>
                        <TableCell className="text-xs text-muted-foreground">{new Date(h.listing_created_at).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="safety" className="mt-6">
          <Card className="border-destructive/20">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2 text-destructive">
                <ShieldAlert className="h-5 w-5" />
                Restricted Accounts
              </CardTitle>
              <CardDescription>Audit log of users currently blocked from the platform.</CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Reason</TableHead>
                    <TableHead>Until</TableHead>
                    <TableHead>Last Modified</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {bannedUsers.length === 0 ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-12 text-muted-foreground">Clean slate! No neighbors are restricted.</TableCell></TableRow>
                  ) : (
                    bannedUsers.map((b) => (
                      <TableRow key={b.id}>
                        <TableCell className="font-bold">{b.first_name} {b.last_name}</TableCell>
                        <TableCell className="text-xs text-destructive italic">{b.ban_reason || "No reason provided"}</TableCell>
                        <TableCell className="text-xs">{b.banned_until ? new Date(b.banned_until).toLocaleDateString() : "Permanent"}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{new Date(b.last_modified).toLocaleDateString()}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default AdminAuditPage;