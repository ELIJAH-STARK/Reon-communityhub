"use client";

import React from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { AlertTriangle, LogIn, Mail } from "lucide-react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

const BannedPage = () => {
  const handleLogout = async () => {
    // Clear any stored guest credentials to prevent auto-login loops
    localStorage.removeItem('hub_guest_credentials');
    localStorage.removeItem('previousGuestUserId');
    
    try {
      // Force sign out
      await supabase.auth.signOut();
    } catch (e) {
      console.error("BannedPage: Error during signout", e);
    }
    
    // Hard redirect to login page to completely reset app state
    window.location.href = "/login";
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-muted/30 p-4">
      <Card className="max-w-md w-full border-destructive/20 shadow-xl animate-in fade-in zoom-in duration-300">
        <CardHeader className="text-center space-y-2">
          <div className="mx-auto bg-destructive/10 p-3 rounded-full w-fit">
            <AlertTriangle className="h-10 w-10 text-destructive" />
          </div>
          <CardTitle className="text-2xl font-bold text-destructive">Account Restricted</CardTitle>
          <CardDescription>
            Your access to the Community Hub has been suspended due to a violation of our community standards.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 text-center">
          <div className="bg-muted p-4 rounded-lg text-sm italic text-muted-foreground">
            "We maintain a safe environment by enforcing our guidelines strictly. Restricted accounts are reviewed by our moderation team."
          </div>
          <p className="text-sm text-muted-foreground">
            If you believe this restriction was applied in error, please contact our support team for a review of your case.
          </p>
        </CardContent>
        <CardFooter className="flex flex-col gap-2">
          <Button variant="default" className="w-full" onClick={handleLogout}>
            <LogIn className="h-4 w-4 mr-2" />
            Go to Sign In
          </Button>
          <Button variant="ghost" className="w-full text-xs text-muted-foreground" asChild>
            <a href="mailto:support@communityhub.com">
              <Mail className="h-3 w-3 mr-2" />
              Appeal Suspension
            </a>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default BannedPage;