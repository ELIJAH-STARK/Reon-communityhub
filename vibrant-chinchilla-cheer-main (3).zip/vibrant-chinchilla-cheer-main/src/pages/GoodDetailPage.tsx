"use client";

import React, { useState, useEffect, useMemo } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useItems } from "@/context/ItemsContext";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Loader2, MessageSquare, User as UserIcon, Share2, Map as MapIcon, ChevronRight, CheckCircle2, Crown, ExternalLink, Flag, Circle } from "lucide-react";
import MapDisplay from "@/components/MapDisplay";
import ImageGallery from "@/components/ImageGallery";
import ReportDialog from "@/components/ReportDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import ReviewSection from "@/components/ReviewSection";
import { cn } from "@/lib/utils";

const GoodDetailPage = () => {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const { uploadedItems, loadingItems } = useItems();
  const { user, loading: sessionLoading } = useSession();
  const navigate = useNavigate();

  const [sellerProfile, setSellerProfile] = useState<any>(null);
  const [loadingSellerInfo, setLoadingSellerInfo] = useState(true);
  const [isReportOpen, setIsReportOpen] = useState(false);

  const item = uploadedItems.find((i) => i.id === id);

  const relatedItems = useMemo(() => {
    if (!item) return [];
    return uploadedItems
      .filter((i) => i.category === item.category && i.id !== item.id && i.status === 'available')
      .slice(0, 3);
  }, [item, uploadedItems]);

  useEffect(() => {
    const fetchSellerInfo = async () => {
      if (!item?.user_id) {
        setLoadingSellerInfo(false);
        return;
      }

      setLoadingSellerInfo(true);
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', item.user_id)
        .single();

      if (profileData) {
        setSellerProfile(profileData);
      }
      setLoadingSellerInfo(false);
    };

    if (item) {
      fetchSellerInfo();
    }
  }, [item]);

  const handleMessageSeller = () => {
    if (!user) {
      toast.error(t('auth.pleaseLogInToMessage'));
      return;
    }
    if (user.id === item?.user_id) {
      toast.info(t('pages.cannotMessageYourself'));
      return;
    }
    if (item?.user_id) {
      navigate(`/chat/${item.user_id}/${item.id}`);
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: item?.name || "Check this out on the Hub",
      text: item?.description || "Found this in our neighborhood!",
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success("Link copied to clipboard!");
      }
    } catch (err) {
      console.error("Share failed", err);
    }
  };

  if (loadingItems || sessionLoading || loadingSellerInfo) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!item) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-8">
        <h3 className="text-2xl font-bold">{t('pages.goodNotFound')}</h3>
        <Button variant="outline" className="mt-4" asChild><Link to="/goods">{t('pages.backToGoods')}</Link></Button>
      </div>
    );
  }

  // Displaying unique username as identity
  const sellerDisplayName = sellerProfile?.username || 
                             [sellerProfile?.first_name, sellerProfile?.last_name].filter(Boolean).join(' ') || 
                             "Neighbor";

  const itemLocation: [number, number] | null = item.latitude && item.longitude ? [item.latitude, item.longitude] : null;
  
  const isOnline = sellerProfile?.last_seen 
    ? (new Date().getTime() - new Date(sellerProfile.last_seen).getTime()) < 300000 
    : false;

  const mapPoints = [];
  if (itemLocation) {
    mapPoints.push({ ...item, type: 'item' });
  }
  if (sellerProfile?.live_location_enabled && sellerProfile.latitude && sellerProfile.longitude) {
    mapPoints.push({
      id: `seller-${sellerProfile.id}`,
      name: `${sellerDisplayName} (Current)`,
      latitude: sellerProfile.latitude,
      longitude: sellerProfile.longitude,
      type: 'service',
      status: 'Online',
      description: 'The seller is currently here.'
    });
  }

  return (
    <div className="container max-w-5xl mx-auto py-8 space-y-8 px-4">
      {item.is_seller_verified && (
        <div className="bg-blue-500 text-white py-2 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md animate-in fade-in slide-in-from-top-4 duration-500">
          <CheckCircle2 className="h-5 w-5 fill-current text-white" />
          <span className="font-bold text-sm uppercase tracking-wider">{t('pages.purchasingVerified')}</span>
        </div>
      )}

      <div className="flex flex-wrap gap-4 justify-between items-center">
        <Button variant="outline" asChild size="sm">
          <Link to="/goods">
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t('pages.backToGoods')}
          </Link>
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleShare}>
            <Share2 className="h-4 w-4 mr-2" /> {t('pages.share')}
          </Button>
          {user?.id !== item.user_id && (
            <>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive" onClick={() => setIsReportOpen(true)}>
                <Flag className="h-4 w-4 mr-2" /> Report
              </Button>
              <Button size="sm" onClick={handleMessageSeller}>
                <MessageSquare className="h-4 w-4 mr-2" /> {t('pages.message')}
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <ImageGallery 
            mainImage={item.image_url} 
            additionalImages={item.additional_images} 
            alt={item.name} 
          />
          
          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <h1 className="text-4xl font-extrabold tracking-tight">{item.name}</h1>
                <Badge variant="outline" className="text-muted-foreground uppercase tracking-widest text-[10px]">{item.category}</Badge>
              </div>
              <Badge variant={item.status === "available" ? "default" : "secondary"} className="h-6">
                {item.status.toUpperCase()}
              </Badge>
            </div>
            
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold text-primary">
                {item.price === 0 ? t('pages.free') : item.price === null ? t('pages.offer') : `$${item.price.toFixed(2)}`}
              </span>
            </div>

            <Separator className="my-6" />

            <div className="prose prose-sm dark:prose-invert max-w-none">
              <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-2">{t('pages.description')}</h3>
              <p className="text-lg leading-relaxed whitespace-pre-wrap">{item.description}</p>
            </div>
          </div>

          <Card className="overflow-hidden border-none shadow-sm bg-muted/30">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base">
                <MapPin className="h-5 w-5 text-primary" /> {t('pages.locationDetail')}
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/map" className="text-xs">
                  <MapIcon className="h-4 w-4 mr-2" /> {t('pages.openFullMap')}
                </Link>
              </Button>
            </CardHeader>
            <CardContent>
              {itemLocation ? (
                <div className="h-80 rounded-2xl overflow-hidden border shadow-inner">
                  <MapDisplay center={itemLocation} items={mapPoints} zoom={15} />
                </div>
              ) : (
                <p className="text-muted-foreground italic text-center py-8">{t('pages.locationNotProvided')}</p>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border shadow-sm">
            <CardHeader>
              <CardTitle className="text-base">{t('pages.neighborInfo')}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <Link to={`/profile/${item.user_id}`} className="group relative shrink-0">
                  <Avatar className="h-14 w-14 border-2 group-hover:border-primary transition-colors">
                    <AvatarImage src={sellerProfile?.avatar_url || undefined} />
                    <AvatarFallback><UserIcon className="h-6 w-6" /></AvatarFallback>
                  </Avatar>
                  {item.is_seller_verified && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-1 border-2 border-background">
                      <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                    </div>
                  )}
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/profile/${item.user_id}`} className="hover:text-primary transition-colors">
                    <h4 className="font-black text-lg truncate flex items-center gap-1">
                      {sellerDisplayName} 
                      {sellerProfile?.is_premium && <Crown className="h-4 w-4 text-yellow-500 fill-current" />}
                      <ExternalLink className="h-3 w-3 opacity-50" />
                    </h4>
                  </Link>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={cn("h-5 text-[9px] uppercase tracking-tighter flex gap-1 items-center", isOnline ? "text-green-600 border-green-200 bg-green-50" : "text-muted-foreground")}>
                      <Circle className={cn("h-1.5 w-1.5 fill-current", isOnline && "animate-pulse")} />
                      {isOnline ? t('pages.online') : t('pages.away')}
                    </Badge>
                    {item.is_seller_verified && (
                      <Badge className="bg-blue-500 hover:bg-blue-600 h-5 text-[8px] uppercase">{t('pages.verified')}</Badge>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 pt-2">
                {user?.id !== item.user_id && (
                  <Button className="w-full rounded-full" onClick={handleMessageSeller}>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    {t('pages.messageNeighbor')}
                  </Button>
                )}
                <Button variant="outline" className="w-full rounded-full h-10" asChild>
                  <Link to={`/profile/${item.user_id}`}>{t('pages.viewFullProfile')}</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <ReviewSection userId={item.user_id} userName={sellerDisplayName} />
        </div>
      </div>

      <ReportDialog 
        isOpen={isReportOpen} 
        onOpenChange={setIsReportOpen} 
        targetId={item.id} 
        targetType="good" 
      />
    </div>
  );
};

const Separator = ({ className }: { className?: string }) => (
  <div className={`h-px w-full bg-border ${className}`} />
);

export default GoodDetailPage;