"use client";
import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Megaphone, Trash2, Loader2, Plus, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

const AdminAnnouncementsPage = () => {
  const [announcements, setAnnouncements] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [type, setType] = useState("info");
  const navigate = useNavigate();

  const fetchAnnouncements = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('announcements')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setAnnouncements(data || []);
    } catch (error: any) {
      toast.error("Failed to fetch announcements: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnnouncements();
  }, []);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;
    
    setIsSubmitting(true);
    try {
      const { error } = await supabase
        .from('announcements')
        .insert({ title, content, type });
      
      if (error) throw error;
      
      toast.success("Announcement published!");
      setTitle("");
      setContent("");
      fetchAnnouncements(); // Refresh the list
    } catch (error: any) {
      toast.error("Failed to post: " + error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('announcements')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      
      // Update local state immediately
      setAnnouncements(prev => prev.filter(a => a.id !== id));
      toast.success("Announcement removed.");
    } catch (error: any) {
      toast.error("Delete failed: " + error.message);
    }
  };

  if (loading) return (
    <div className="flex justify-center py-20">
      <Loader2 className="animate-spin h-8 w-8 text-primary" />
    </div>
  );

  return (
    <div className="container max-w-4xl mx-auto py-8 space-y-8 px-4">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => navigate(-1)} className="rounded-full">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Megaphone className="h-8 w-8 text-primary" />
          Community Announcements
        </h1>
      </div>
      
      <Card className="shadow-lg border-primary/20">
        <CardHeader>
          <CardTitle className="text-lg">Create New Announcement</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleCreate} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Title</Label>
                <Input 
                  value={title} 
                  onChange={e => setTitle(e.target.value)} 
                  placeholder="e.g. Weekend Hub Maintenance" 
                />
              </div>
              <div className="space-y-2">
                <Label>Alert Type</Label>
                <Select value={type} onValueChange={setType}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="info">Information (Blue)</SelectItem>
                    <SelectItem value="warning">Warning (Orange)</SelectItem>
                    <SelectItem value="destructive">Urgent (Red)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Message Content</Label>
              <Textarea 
                value={content} 
                onChange={e => setContent(e.target.value)} 
                placeholder="What do neighbors need to know?" 
              />
            </div>
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? <Loader2 className="animate-spin mr-2 h-4 w-4" /> : <Plus className="mr-2 h-4 w-4" />}
              Publish Announcement
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <div className="space-y-4">
        <h2 className="text-xl font-bold">Previous Posts</h2>
        {announcements.length === 0 ? (
          <p className="text-muted-foreground text-center py-12 border-2 border-dashed rounded-xl">
            No previous announcements.
          </p>
        ) : (
          announcements.map(a => (
            <Card key={a.id} className="relative group">
              <CardContent className="p-4 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold">{a.title}</h3>
                    <Badge 
                      variant={a.type === 'info' ? 'secondary' : a.type === 'warning' ? 'outline' : 'destructive'} 
                      className="text-[10px] uppercase"
                    >
                      {a.type}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{a.content}</p>
                  <p className="text-[10px] text-muted-foreground/60">{new Date(a.created_at).toLocaleString()}</p>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => handleDelete(a.id)}
                  className="text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminAnnouncementsPage;