"use client";
import React, { useMemo } from "react";
import { useFavorites } from "@/context/FavoritesContext";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useTranslation } from "@/hooks/useTranslation";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Link } from "react-router-dom";
import { Heart, Package2, Briefcase, Loader2, CheckCircle2 } from "lucide-react";
import FavoriteButton from "@/components/FavoriteButton";
import { Badge } from "@/components/ui/badge";

const FavoritesPage = () => {
  const { t } = useTranslation();
  const { favorites, loadingFavorites } = useFavorites();
  const { uploadedItems } = useItems();
  const { uploadedServices } = useServices();

  const favoritedItems = useMemo(() => {
    const itemIds = favorites.filter(f => f.item_id).map(f => f.item_id);
    return uploadedItems.filter(item => itemIds.includes(item.id));
  }, [favorites, uploadedItems]);

  const favoritedServices = useMemo(() => {
    const serviceIds = favorites.filter(f => f.service_id).map(f => f.service_id);
    return uploadedServices.filter(service => serviceIds.includes(service.id));
  }, [favorites, uploadedServices]);

  if (loadingFavorites) {
    return (
      <div className="flex flex-1 items-center justify-center p-8">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="container max-w-4xl mx-auto py-8 space-y-6 px-4">
      <div className="flex flex-col gap-2">
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Heart className="h-8 w-8 text-red-500 fill-red-500" />
          {t('pages.myFavorites')}
        </h1>
        <p className="text-muted-foreground">{t('pages.savedItems')}</p>
      </div>

      <Tabs defaultValue="goods" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-md">
          <TabsTrigger value="goods" className="flex items-center gap-2">
            <Package2 className="h-4 w-4" />
            {t('navigation.goods')} ({favoritedItems.length})
          </TabsTrigger>
          <TabsTrigger value="services" className="flex items-center gap-2">
            <Briefcase className="h-4 w-4" />
            {t('navigation.services')} ({favoritedServices.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="goods" className="mt-6">
          {favoritedItems.length === 0 ? (
            <div className="text-center py-20 border-2 border-dashed rounded-lg bg-muted/30">
              <Package2 className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-muted-foreground">{t('pages.youHaventSaved')}</p>
              <Link to="/goods" className="text-primary hover:underline mt-2 inline-block">{t('pages.browseGoods')}</Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {favoritedItems.map(item => {
                const hasDiscount = item.price != null && item.discount_percentage != null && item.discount_percentage > 0;
                const discountedPrice = hasDiscount ? (item.price! * (1 - item.discount_percentage! / 100)).toFixed(2) : null;

                return (
                  <Link to={`/goods/${item.id}`} key={item.id} className="group">
                    <Card className="overflow-hidden hover:shadow-md transition-shadow relative">
                      <div className="absolute top-2 right-2 z-10">
                        <FavoriteButton id={item.id} type="item" />
                      </div>
                      
                      {hasDiscount && (
                        <div className="absolute top-2 left-2 z-10">
                          <Badge className="bg-red-500 hover:bg-red-600 text-[9px] px-1.5 py-0">
                            -{item.discount_percentage}% 
                          </Badge>
                        </div>
                      )}
                      
                      <div className="flex flex-col">
                        <div className="relative w-full h-40 overflow-hidden bg-muted">
                          <img src={item.image_url} alt={item.name} className="w-full h-full object-cover" />
                          {item.is_seller_verified && (
                            <div className="absolute bottom-0 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-1 px-2 flex items-center justify-center gap-1.5">
                              <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                              <span className="text-[9px] font-bold text-white uppercase tracking-wider">Verified Neighbor</span>
                            </div>
                          )}
                        </div>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-1">
                            <h3 className="font-bold group-hover:text-primary transition-colors">{item.name}</h3>
                          </div>
                          <p className="text-xs text-muted-foreground mb-2">{item.category}</p>
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-auto gap-2">
                            <div className="flex flex-col">
                              {item.price === 0 ? (
                                <span className="text-sm font-bold text-green-600">Free</span>
                              ) : item.price === null ? (
                                <span className="text-sm font-bold text-primary">Offer</span>
                              ) : (
                                <div className="flex flex-wrap items-baseline gap-1">
                                  <span className="text-sm font-bold text-primary">
                                    ${discountedPrice || item.price.toFixed(2)}
                                  </span>
                                  {hasDiscount && (
                                    <span className="text-[10px] text-muted-foreground line-through opacity-60">
                                      ${item.price.toFixed(2)}
                                    </span>
                                  )}
                                </div>
                              )}
                            </div>
                            <Badge variant="outline" className="text-[10px] w-fit">{item.status}</Badge>
                          </div>
                        </CardContent>
                      </div>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>

        <TabsContent value="services" className="mt-6"> 
          {favoritedServices.length === 0 ? (
            <div className="text-center py-20 border-2 border-dashed rounded-lg bg-muted/30">
              <Briefcase className="h-12 w-12 text-muted-foreground/50 mx-auto mb-4" />
              <p className="text-muted-foreground">{t('pages.youHaventSaved')} {t('navigation.services').toLowerCase()}.</p>
              <Link to="/services" className="text-primary hover:underline mt-2 inline-block">{t('pages.browseServices')}</Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {favoritedServices.map(service => {
                const hasDiscount = service.price != null && service.discount_percentage != null && service.discount_percentage > 0;
                const discountedPrice = hasDiscount ? (service.price! * (1 - service.discount_percentage! / 100)).toFixed(2) : null;

                return (
                  <Link to={`/services/${service.id}`} key={service.id} className="group">
                    <Card className="hover:shadow-md transition-shadow relative overflow-hidden">
                      <div className="absolute top-2 right-2 z-10">
                        <FavoriteButton id={service.id} type="service" />
                      </div>
                      
                      {hasDiscount && (
                        <div className="absolute top-2 left-2 z-10">
                          <Badge className="bg-red-500 hover:bg-red-600 text-[9px] px-1.5 py-0">
                            -{service.discount_percentage}% 
                          </Badge>
                        </div>
                      )}
                      
                      <CardContent className="p-4 pt-6">
                        <div className="flex justify-between items-start mb-1">
                          <div className="flex items-center gap-1.5">
                            <h3 className="font-bold group-hover:text-primary transition-colors">{service.name}</h3>
                            {service.is_provider_verified && (
                              <CheckCircle2 className="h-3 w-3 text-blue-500 fill-current" />
                            )}
                          </div>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">{service.category}</p>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-auto gap-2">
                          <div className="flex flex-col">
                            {service.price === 0 ? (
                              <span className="text-sm font-bold text-green-600">Free</span>
                            ) : service.price === null ? (
                              <span className="text-sm font-bold text-primary">Negotiable</span>
                            ) : (
                              <div className="flex flex-wrap items-baseline gap-1">
                                <span className="text-sm font-bold text-primary">
                                  ${discountedPrice || service.price.toFixed(2)}
                                </span>
                                {hasDiscount && (
                                  <span className="text-[10px] text-muted-foreground line-through opacity-60">
                                    ${service.price.toFixed(2)}
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                          <Badge variant="outline" className="text-[10px] w-fit">{service.status}</Badge>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                );
              })}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default FavoritesPage;