"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, User as UserIcon, ArrowLeft, Check, AlertCircle, MapPin, LocateFixed, Crown, PackagePlus, Circle, Sparkles, Save, Trash2, ShieldAlert, History } from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useRequests } from "@/context/RequestsContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import DeleteConfirmationDialog from "@/components/DeleteConfirmationDialog";

const ProfilePage = () => {
  const { t } = useTranslation();
  const { user, loading: sessionLoading, isPremium, previousGuestUserId, clearPreviousGuestUserId, refreshProfile: refreshSessionProfile } = useSession();
  const { uploadedItems, refreshItems } = useItems();
  const { uploadedServices, refreshServices } = useServices();
  const { requests, refreshRequests } = useRequests();
  const { latitude: currentLat, longitude: currentLng, loading: geoLoading } = useGeolocation();
  const navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [avatarUrl, setAvatarUrl] = useState("");
  const [liveLocationEnabled, setLiveLocationEnabled] = useState(false);
  const [globalAddress, setGlobalAddress] = useState("");
  const [savedLat, setSavedLat] = useState<number | null>(null);
  const [savedLng, setSavedLng] = useState<number | null>(null);
  const [extraSlots, setExtraSlots] = useState(0);
  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [isMerging, setIsMerging] = useState(false);

  // Username validation state
  const [isUsernameAvailable, setIsUsernameAvailable] = useState<boolean | null>(null);
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [initialUsername, setInitialUsername] = useState("");
  const [selectedAvatarFile, setSelectedAvatarFile] = useState<File | null>(null);
  const [avatarPreviewUrl, setAvatarPreviewUrl] = useState<string | null>(null);

  // Account Deletion State
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);

  useEffect(() => {
    const fetchProfileData = async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      try {
        const { data, error } = await supabase
          .from("profiles")
          .select("username, first_name, last_name, avatar_url, latitude, longitude, live_location_enabled, global_address, extra_slots")
          .eq("id", user.id)
          .single();
        if (!error && data) {
          setUsername(data.username || "");
          setInitialUsername(data.username || "");
          setFirstName(data.first_name || "");
          setLastName(data.last_name || "");
          setAvatarUrl(data.avatar_url || "");
          setAvatarPreviewUrl(data.avatar_url);
          setLiveLocationEnabled(data.live_location_enabled || false);
          setGlobalAddress(data.global_address || "");
          setSavedLat(data.latitude);
          setSavedLng(data.longitude);
          setExtraSlots(data.extra_slots || 0);
        }
      } catch (err) {
        console.error("Error fetching profile data:", err);
      } finally {
        setLoading(false);
      }
    };
    if (!sessionLoading && user) fetchProfileData();
  }, [user, sessionLoading]);

  // Handle username availability check
  useEffect(() => {
    const checkUsername = async () => {
      if (!username || username.trim() === initialUsername) {
        setIsUsernameAvailable(null);
        setSuggestions([]);
        return;
      }
      if (username.length < 3) {
        setIsUsernameAvailable(false);
        return;
      }
      setCheckingUsername(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('username')
        .ilike('username', username.trim())
        .neq('id', user?.id)
        .maybeSingle();
      if (!error) {
        const available = !data;
        setIsUsernameAvailable(available);
        if (!available) {
          const random = Math.floor(Math.random() * 999);
          setSuggestions([
            `${username}${random}`,
            `${username}_hub`,
            `${username}_local`
          ]);
        } else {
          setSuggestions([]);
        }
      }
      setCheckingUsername(false);
    };
    const timer = setTimeout(checkUsername, 500);
    return () => clearTimeout(timer);
  }, [username, initialUsername, user?.id]);

  const userListingsCount = (uploadedItems?.filter(i => i.user_id === user?.id).length || 0) +
    (uploadedServices?.filter(s => s.user_id === user?.id).length || 0) +
    (requests?.filter(r => r.user_id === user?.id).length || 0);

  const currentLimit = 10 + extraSlots;
  const usagePercentage = isPremium ? 0 : Math.min(100, (userListingsCount / currentLimit) * 100);

  const handlePinLocation = () => {
    if (currentLat && currentLng) {
      setSavedLat(currentLat);
      setSavedLng(currentLng);
      toast.success("Coordinates updated!");
    } else {
      toast.error("Waiting for GPS...");
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    if (username !== initialUsername && isUsernameAvailable === false) {
      toast.error("Username is already in use by another neighbor.");
      return;
    }
    setIsSaving(true);
    try {
      let newAvatarUrl = avatarUrl;
      if (selectedAvatarFile) {
        const fileExt = selectedAvatarFile.name.split('.').pop();
        const fileName = `${user.id}/avatar_${Date.now()}.${fileExt}`;
        const filePath = `public/${fileName}`;
        const { error: uploadError } = await supabase.storage.from('avatars').upload(filePath, selectedAvatarFile, {
          upsert: true
        });
        if (uploadError) throw uploadError;
        const { data: publicUrlData } = supabase.storage.from('avatars').getPublicUrl(filePath);
        newAvatarUrl = publicUrlData.publicUrl;
      }

      const { error: profileError } = await supabase.from("profiles").upsert({
        id: user.id,
        username: username.trim(),
        first_name: firstName.trim(),
        last_name: lastName.trim(),
        avatar_url: newAvatarUrl,
        live_location_enabled: liveLocationEnabled,
        global_address: globalAddress.trim(),
        latitude: savedLat,
        longitude: savedLng,
        updated_at: new Date().toISOString(),
      });
      if (profileError) throw profileError;

      setInitialUsername(username.trim());
      setAvatarUrl(newAvatarUrl);
      setSelectedAvatarFile(null);
      setIsUsernameAvailable(null);
      await refreshSessionProfile();
      toast.success("Profile saved successfully!");
    } catch (err: any) {
      console.error("Save failed:", err);
      toast.error("Save failed: " + (err.message || "Unknown error"));
    } finally {
      setIsSaving(false);
    }
  };

  const handleMergeHistory = async () => {
    if (!user || !previousGuestUserId) return;
    setIsMerging(true);
    try {
      const { data, error } = await supabase.functions.invoke('merge-accounts', {
        body: { 
          guestUserId: previousGuestUserId,
          existingUserId: user.id
        }
      });

      if (error) throw error;
      if (data?.success) {
        toast.success(t('messages.mergedSuccessfully'));
        clearPreviousGuestUserId();
        // Refresh all local data contexts
        refreshItems();
        refreshServices();
        refreshRequests();
        refreshSessionProfile();
      } else {
        throw new Error(data?.error || "Merge failed");
      }
    } catch (err: any) {
      console.error("Merge error:", err);
      toast.error("Failed to merge history: " + err.message);
    } finally {
      setIsMerging(false);
    }
  };

  const handleDeleteAccount = async () => {
    if (!user) return;
    setIsDeletingAccount(true);
    try {
      const { data, error } = await supabase.functions.invoke('delete-user-account');
      if (error) throw error;
      if (data?.success) {
        toast.success(t('errors.accountDeleted'));
        localStorage.removeItem('hub_guest_credentials');
        await supabase.auth.signOut();
        navigate("/", { replace: true });
      } else {
        throw new Error(data?.error || "Unknown deletion error");
      }
    } catch (err: any) {
      console.error("Deletion failed:", err);
      toast.error("Failed to delete account: " + err.message);
    } finally {
      setIsDeletingAccount(false);
      setIsDeleteDialogOpen(false);
    }
  };

  if (sessionLoading || loading) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-8 text-center space-y-4">
        <div className="bg-muted p-6 rounded-full"><UserIcon className="h-12 w-12 text-muted-foreground" /></div>
        <h3 className="text-2xl font-bold">{t('pages.authRequired')}</h3>
        <Button asChild><Link to="/login">{t('buttons.signIn')}</Link></Button>
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col items-center p-4 md:p-8 max-w-2xl mx-auto w-full pb-20">
      <div className="w-full space-y-8">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full">
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <h1 className="text-3xl font-bold">{t('pages.profilePage')}</h1>
          </div>
          {isPremium && (
            <Badge className="bg-yellow-500 text-white font-bold px-3 py-1 flex gap-1.5 shadow-lg border-none animate-in zoom-in duration-500">
              <Crown className="h-3.5 w-3.5 fill-current" />
              {t('premium.hubSupporter')}
            </Badge>
          )}
        </div>

        {/* Merge Banner for recently logged in users who were guests */}
        {previousGuestUserId && (
          <Card className="border-orange-500/20 bg-orange-500/5 animate-in slide-in-from-top-4 duration-500">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-bold flex items-center gap-2 text-orange-700">
                <History className="h-4 w-4" />
                {t('messages.unmergedData')}
              </CardTitle>
              <CardDescription>
                {t('messages.foundListings')}
              </CardDescription>
            </CardHeader>
            <CardContent className="flex gap-2">
              <Button 
                size="sm" 
                className="bg-orange-600 hover:bg-orange-700 text-white rounded-full font-bold"
                onClick={handleMergeHistory}
                disabled={isMerging}
              >
                {isMerging ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Sparkles className="h-4 w-4 mr-2" />}
                {t('messages.mergeHistory')}
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="rounded-full text-muted-foreground"
                onClick={clearPreviousGuestUserId}
                disabled={isMerging}
              >
                {t('buttons.discardHistory')}
              </Button>
            </CardContent>
          </Card>
        )}

        <Card className="border-primary/20 bg-primary/5">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-bold flex items-center gap-2">
              <PackagePlus className="h-4 w-4 text-primary" />
              {t('pages.accountCapacity')}
              <span className="text-primary">{userListingsCount} / {isPremium ? '∞' : currentLimit}</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!isPremium && (
              <div className="h-2 w-full bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all duration-500"
                  style={{ width: `${usagePercentage}%` }}
                />
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="shadow-lg border-none">
          <CardHeader>
            <CardTitle>{t('pages.profileDetails')}</CardTitle>
            <CardDescription>{t('pages.profileDetailsDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex flex-col items-center gap-4">
              <div className="relative group">
                <Avatar className="h-28 w-28 border-4 border-background shadow-xl">
                  <AvatarImage src={avatarPreviewUrl || undefined} />
                  <AvatarFallback className="text-3xl font-bold bg-muted">{firstName?.[0] || '?'}</AvatarFallback>
                </Avatar>
                <Label
                  htmlFor="avatar-up"
                  className="absolute inset-0 flex items-center justify-center bg-black/40 text-white opacity-0 group-hover:opacity-100 transition-opacity rounded-full cursor-pointer text-xs font-bold"
                >
                  {t('buttons.updatePhoto')}
                </Label>
                <Input
                  id="avatar-up"
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      setSelectedAvatarFile(file);
                      setAvatarPreviewUrl(URL.createObjectURL(file));
                    }
                  }}
                  className="hidden"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="uName" className="flex items-center gap-2">
                {t('pages.uniqueUsername')}
                {checkingUsername && <Loader2 className="h-3 w-3 animate-spin" />}
                {isUsernameAvailable === true && username !== initialUsername && <Check className="h-3 w-3 text-green-500" />}
                {isUsernameAvailable === false && <AlertCircle className="h-3 w-3 text-destructive" />}
              </Label>
              <div className="relative">
                <Input
                  id="uName"
                  value={username}
                  onChange={e => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                  className={cn(
                    "font-mono",
                    isUsernameAvailable === false && "border-destructive focus-visible:ring-destructive",
                    isUsernameAvailable === true && "border-green-500 focus-visible:ring-green-500"
                  )}
                  placeholder={t('pages.usernamePlaceholder')}
                />
              </div>
              {isUsernameAvailable === false && suggestions.length > 0 && (
                <div className="space-y-2 animate-in fade-in duration-300">
                  <p className="text-[10px] text-destructive font-bold uppercase">{t('pages.alreadyTaken')}</p>
                  <div className="flex flex-wrap gap-2">
                    {suggestions.map(s => (
                      <button
                        key={s}
                        onClick={() => setUsername(s)}
                        className="text-[10px] bg-muted hover:bg-primary/10 hover:text-primary px-2 py-1 rounded-full border transition-colors font-mono"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fName">{t('pages.firstName')}</Label>
                <Input id="fName" value={firstName} onChange={e => setFirstName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="lName">{t('pages.lastName')}</Label>
                <Input id="lName" value={lastName} onChange={e => setLastName(e.target.value)} />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="gAddr">{t('pages.globalHomeAddress')}</Label>
              <Input
                id="gAddr"
                value={globalAddress}
                onChange={e => setGlobalAddress(e.target.value)}
                placeholder={t('pages.addressPlaceholder')}
              />
            </div>

            <div className="p-4 rounded-xl bg-primary/5 border border-primary/10 space-y-4">
              <div className="flex items-center justify-between">
                <Label className="text-sm font-bold flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> {t('pages.locationPrecision')}</Label>
                <Button variant="outline" size="sm" onClick={handlePinLocation} disabled={geoLoading}>
                  <LocateFixed className="h-4 w-4 mr-2" />
                  {geoLoading ? t('pages.detecting') : t('buttons.pinCurrent')}
                </Button>
              </div>
              <div className="flex items-center justify-between pt-2">
                <div className="space-y-0.5">
                  <Label className="text-xs font-bold">{t('pages.liveTracking')}</Label>
                  <p className="text-[10px] text-muted-foreground italic">{t('pages.liveTrackingDesc')}</p>
                </div>
                <Switch checked={liveLocationEnabled} onCheckedChange={setLiveLocationEnabled} />
              </div>
            </div>

            <Button
              className="w-full h-12 rounded-xl text-lg font-bold shadow-lg"
              onClick={handleSaveProfile}
              disabled={isSaving || (username !== initialUsername && isUsernameAvailable === false)}
            >
              {isSaving ? (
                <Loader2 className="h-5 w-5 animate-spin mr-2" />
              ) : (
                <Save className="h-5 w-5 mr-2" />
              )}
              {t('buttons.updateHubProfile')}
            </Button>
          </CardContent>
        </Card>

        {/* Danger Zone */}
        <Card className="border-destructive/20 bg-destructive/5 mt-12">
          <CardHeader>
            <CardTitle className="text-destructive flex items-center gap-2">
              <ShieldAlert className="h-5 w-5" />
              {t('pages.dangerZone')}
            </CardTitle>
            <CardDescription>{t('pages.dangerZoneDesc')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div className="space-y-1">
                <h4 className="text-sm font-bold">{t('pages.deleteAccount')}</h4>
                <p className="text-xs text-muted-foreground">{t('pages.deleteAccountDesc')}</p>
              </div>
              <Button
                variant="destructive"
                size="sm"
                className="rounded-full font-bold px-6"
                onClick={() => setIsDeleteDialogOpen(true)}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                {t('buttons.deleteAccount')}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <DeleteConfirmationDialog
        isOpen={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onConfirm={handleDeleteAccount}
        isLoading={isDeletingAccount}
        title={t('pages.deleteAccountConfirm')}
        description={t('pages.deleteAccountWarning')}
      />
    </div>
  );
};

export default ProfilePage;