"use client";

import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Crown, ArrowLeft, PlusCircle, Milestone, Info, AlertCircle } from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { useSystemSettingsContext } from "@/context/SystemSettingsContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const PremiumPage = () => {
  const { user, isGuest, isPremium } = useSession();
  const { settings } = useSystemSettingsContext();
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [currentSlots, setCurrentSlots] = useState(10);
  const [streakInfo, setStreakInfo] = useState<{ boughtInWindow: number; needed: number } | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;
      
      // Fetch current slot capacity
      const { data: profile } = await supabase.from('profiles').select('extra_slots').eq('id', user.id).single();
      
      if (profile) {
        setCurrentSlots(10 + (profile.extra_slots || 0));
        
        // Calculate Streak Status (Strict 90-day Window)
        if (!isPremium) {
          const now = new Date();
          const threeMonthsAgo = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
          
          const { data: transactions } = await supabase
            .from('slot_transactions')
            .select('slot_count')
            .eq('user_id', user.id)
            .gte('created_at', threeMonthsAgo.toISOString());

          const boughtInWindow = (transactions || []).reduce((sum, t) => sum + t.slot_count, 0);
          const needed = Math.max(0, 20 - boughtInWindow);
          
          setStreakInfo({ boughtInWindow, needed });
        }
      }
    };
    fetchData();
  }, [user, isPremium]);

  const handleUpgradeClick = (type: 'premium' | '1slot' | '4slot') => {
    if (isGuest) {
      toast.error(t('premium.registerFirst'));
      navigate("/login?redirect=/premium");
      return;
    }
    // Fixed: Removed the backslash that was escaping the variable interpolation
    navigate(`/checkout?type=${type}`);
  };

  return (
    <div className="container max-w-4xl mx-auto py-8 space-y-8 px-4">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => navigate(-1)} className="rounded-full">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">{t('premium.membershipCapacity')}</h1>
      </div>

      {/* Premium Features Disabled Message */}
      {!settings.premiumEnabled && (
        <Card className="bg-yellow-50 border-yellow-200">
          <CardContent className="p-6 flex items-start gap-4">
            <div className="flex-shrink-0 mt-0.5">
              <AlertCircle className="h-5 w-5 text-yellow-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-yellow-900 mb-1">{t('premium.premiumDisabled')}</h3>
              <p className="text-sm text-yellow-800">
                {t('premium.premiumDisabledMessage')}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Streak Progress Bar */}
      {!isPremium && streakInfo && settings.premiumEnabled && (
        <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-purple-200">
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <Milestone className="h-4 w-4 text-purple-600" />
                <span className="font-bold text-sm text-purple-900">{t('premium.pathToPremium')}</span>
              </div>
              <p className="text-xs text-purple-700 leading-relaxed">
                {t('premium.buySlotsChallengeDescription').replace('{needed}', String(streakInfo.needed))}
              </p>
            </div>
            <div className="text-right">
              <span className="text-xl font-black text-purple-700">{streakInfo.boughtInWindow}/20</span>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Show message when premium is disabled */}
        {!settings.premiumEnabled ? (
          <Card className="lg:col-span-2 bg-gray-50">
            <CardContent className="p-8 text-center">
              <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-bold text-gray-900 mb-2">{t('premium.upgradesUnavailable')}</h3>
              <p className="text-sm text-gray-600">
                {t('premium.upgradesUnavailableMessage')}
              </p>
            </CardContent>
          </Card>
        ) : (
          <>
        {/* Premium Card */}
        <Card className="border-primary/50 shadow-xl relative overflow-hidden bg-gradient-to-b from-primary/5 to-transparent h-full flex flex-col rounded-3xl">
          <div className="absolute top-0 right-0 p-4">
            <Badge className="bg-primary hover:bg-primary font-bold px-3 py-1">{t('premium.bestValue')}</Badge>
          </div>
          <CardHeader className="text-center pt-12 pb-8">
            <Crown className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
            <CardTitle className="text-3xl font-black">{t('premium.hubSupporter')}</CardTitle>
            <CardDescription>{t('premium.unlimitedEverything')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6 text-center flex-1">
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-5xl font-extrabold">$29.99</span>
              <span className="text-muted-foreground font-medium">/ {t('premium.perYear')}</span>
            </div>
            <ul className="space-y-3 text-sm font-medium text-left max-w-[240px] mx-auto">
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-500 shrink-0" /> {t('premium.unlimitedListings')}</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-500 shrink-0" /> {t('premium.featuredPlacement')}</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-500 shrink-0" /> {t('premium.supporterBadge')}</li>
              <li className="flex items-center gap-2"><Check className="h-4 w-4 text-green-500 shrink-0" /> {t('premium.prioritySupport')}</li>
            </ul>
          </CardContent>
          <CardFooter className="pb-8">
            <Button 
              className="w-full h-12 text-lg font-bold rounded-2xl shadow-lg" 
              onClick={() => handleUpgradeClick('premium')} 
              disabled={isPremium}
            >
              {isPremium ? t('premium.alreadySupporter') : t('premium.unlock1YearPremium')}
            </Button>
          </CardFooter>
        </Card>

        {/* Individual Slots Card */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold px-2">{t('premium.buyMoreSlots')}</h2>
          <Card className="border-dashed rounded-3xl flex flex-col">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <PlusCircle className="h-5 w-5 text-blue-500" /> {t('premium.payAsYouGo')}
              </CardTitle>
              <CardDescription>{t('premium.capacityBoost')}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between p-4 rounded-2xl border bg-muted/30">
                <div>
                  <h4 className="font-bold">{t('premium.singleSlot')}</h4>
                  <p className="text-xs text-muted-foreground">{t('premium.singleSlotExpiry')}</p>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="font-bold rounded-full" 
                  onClick={() => handleUpgradeClick('1slot')} 
                  disabled={isPremium}
                >
                  $1.99
                </Button>
              </div>

              <div className="flex items-center justify-between p-4 rounded-2xl border border-blue-200 bg-blue-50/30">
                <div>
                  <h4 className="font-bold">{t('premium.slotBundle')}</h4>
                  <p className="text-xs text-muted-foreground">{t('premium.slotBundleDesc')}</p>
                </div>
                <Button 
                  variant="default" 
                  size="sm" 
                  className="bg-blue-600 hover:bg-blue-700 font-bold rounded-full" 
                  onClick={() => handleUpgradeClick('4slot')} 
                  disabled={isPremium}
                >
                  $6.99
                </Button>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 p-3 rounded-xl flex gap-3 items-start">
                <Info className="h-5 w-5 text-yellow-600 shrink-0 mt-0.5" />
                <p className="text-[11px] text-yellow-800 leading-tight">
                  <span className="font-bold">{t('premium.challenge')}:</span> {t('premium.challengeDescription')}
                </p>
              </div>
            </CardContent>
            <CardFooter>
              <p className="text-[10px] text-muted-foreground italic">
                * {t('premium.slotsExpireNote')}
              </p>
            </CardFooter>
          </Card>
        </div>
          </>
        )}
      </div>
    </div>
  );
};

export default PremiumPage;