"use client";
import React, { useState, useMemo } from "react";
import { useRequests } from "@/context/RequestsContext";
import { Button } from "@/components/ui/button";
import { Loader2, AlertCircle, RefreshCcw, Plus, MessageSquare, MapPin, Sparkles, ArrowRight, HelpCircle } from "lucide-react";
import { toast } from "sonner";
import { Link, useNavigate } from "react-router-dom";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { itemCategories, serviceCategories } from "@/lib/constants";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useGeolocation } from "@/hooks/use-geolocation";
import { calculateDistance, cn } from "@/lib/utils";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";

const RequestsPage = () => {
  const { requests, loading, error, refreshRequests } = useRequests();
  const { latitude, longitude } = useGeolocation();
  const navigate = useNavigate();
  const { user } = useSession();
  const { t } = useTranslation();
  
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");
  const [selectedStatus, setSelectedStatus] = useState<string>("open");
  
  const handleRetry = () => {
    refreshRequests();
    toast.info("Retrying database connection...");
  };

  const { topFeatured, displayList } = useMemo(() => {
    // 1. Filter base requests
    // CRITICAL: Filter out held items
    let base = [...requests].filter(r => !r.is_held);
    
    if (selectedCategory !== "All Categories") {
      base = base.filter(r => r.category === selectedCategory);
    }
    
    if (selectedStatus !== "All Statuses") {
      base = base.filter(r => r.status === selectedStatus);
    }

    // 2. Separate
    const featuredMatches = base.filter(r => r.is_featured);
    const regularMatches = base.filter(r => !r.is_featured);

    // 3. Hero Selection
    const top = [...featuredMatches].sort(() => 0.5 - Math.random()).slice(0, 3);
    const topIds = new Set(top.map(t => t.id));

    // 4. Injection pool
    const injectionPool = featuredMatches.filter(r => !topIds.has(r.id));

    // 5. Build list with 1-in-5 injection
    const result: any[] = [];
    let injectIdx = 0;

    regularMatches.forEach((req, index) => {
      // Calculate distance if possible
      let finalReq = req;
      if (latitude && longitude && req.latitude && req.longitude) {
        finalReq = { ...req, distance: calculateDistance(latitude, longitude, req.latitude, req.longitude) };
      }
      
      result.push(finalReq);
      
      if ((index + 1) % 5 === 0 && injectionPool.length > 0) {
        let f = injectionPool[injectIdx % injectionPool.length];
        if (latitude && longitude && f.latitude && f.longitude) {
          f = { ...f, distance: calculateDistance(latitude, longitude, f.latitude, f.longitude) };
        }
        result.push(f);
        injectIdx++;
      }
    });

    return { topFeatured: top, displayList: result };
  }, [requests, selectedCategory, selectedStatus, latitude, longitude]);

  const categories = useMemo(() => {
    const allCategories = [...itemCategories, ...serviceCategories];
    return ["All Categories", ...Array.from(new Set(allCategories)).sort()];
  }, []);

  const statuses = ["All Statuses", "open", "in_progress", "fulfilled"];

  return (
    <div className="flex flex-1 flex-col items-center p-4">
      <div className="w-full max-w-5xl flex flex-col items-center gap-4 text-center">
        <div className="space-y-1">
          <h3 className="text-2xl md:text-3xl font-bold tracking-tight text-primary">{t('requests.communityRequests')}</h3>
          <p className="text-sm text-muted-foreground">{t('requests.neighborsHelpingNeighbors')}</p>
        </div>
        
        <div className="flex flex-wrap justify-center gap-4 bg-card p-4 rounded-2xl border shadow-sm w-full">
          <div className="flex flex-col items-start gap-1">
            <span className="text-[10px] font-bold text-muted-foreground uppercase ml-1">Category</span>
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[180px] rounded-xl h-10 font-medium">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {categories.map(cat => (
                  <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-col items-start gap-1">
            <span className="text-[10px] font-bold text-muted-foreground uppercase ml-1">{t('content.status')}</span>
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[140px] rounded-xl h-10 font-medium">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="rounded-xl">
                {statuses.map(status => (
                  <SelectItem key={status} value={status}>
                    {status === "open" ? t('requests.open') : status === "in_progress" ? t('requests.inProgress') : status === "fulfilled" ? t('requests.fulfilled') : t('requests.allStatuses')}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center ml-auto pt-5">
            <Button asChild className="rounded-full shadow-md font-bold px-6">
              <Link to="/my-requests">
                <Plus className="h-4 w-4 mr-2" />
                {t('requests.postRequest')}
              </Link>
            </Button>
          </div>
        </div>
        
        {loading ? (
          <div className="flex flex-col items-center gap-4 py-20">
            <Loader2 className="h-10 w-10 animate-spin text-primary" />
            <span className="text-muted-foreground font-medium">{t('requests.scanningNeeds')}</span>
          </div>
        ) : error ? (
          <div className="bg-destructive/10 text-destructive p-8 rounded-3xl flex flex-col items-center gap-4 border border-destructive/20 w-full">
            <AlertCircle className="h-10 w-10" />
            <p className="font-bold">{t('requests.syncError')}: {error}</p>
            <Button onClick={handleRetry} variant="outline" size="sm" className="rounded-full">
              <RefreshCcw className="h-4 w-4 mr-2" /> {t('requests.retryConnection')}
            </Button>
          </div>
        ) : (
          <div className="w-full space-y-6">
            {/* TOP FEATURED SECTION */}
            {topFeatured.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {topFeatured.map(request => (
                  <Link to={`/requests/${request.id}`} key={`top-featured-${request.id}`} className="group">
                    <Card className="h-full hover:shadow-xl transition-all border-yellow-500/40 bg-yellow-500/5 ring-1 ring-yellow-500/20 rounded-3xl overflow-hidden relative group-hover:-translate-y-1">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-3 gap-4">
                          <div className="flex-1 text-left">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge className="bg-yellow-500 text-white text-[8px] font-black px-2 py-0.5 border-none shadow-sm flex items-center gap-1">
                                <Sparkles className="h-2 w-2 fill-current" />
                                FEATURED
                              </Badge>
                            </div>
                            <h5 className="font-black text-lg leading-tight group-hover:text-primary transition-colors line-clamp-2">{request.title}</h5>
                          </div>
                          <Badge variant="outline" className="text-[10px] uppercase font-black bg-yellow-500/10 text-yellow-700 border-yellow-200 h-5">
                            {request.status.replace('_', ' ')}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mt-1 line-clamp-3 mb-6 text-left leading-relaxed font-medium">
                          {request.description}
                        </p>
                        <div className="flex justify-between items-center mt-auto pt-4 border-t border-yellow-500/10">
                          <Badge variant="outline" className="text-[9px] font-bold uppercase h-5 bg-background">{request.category}</Badge>
                          <div className="flex items-center gap-1 text-[10px] font-black text-primary uppercase tracking-widest">
                            Help Neighbor <ArrowRight className="h-3 w-3" />
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            )}

            {/* MAIN SCROLL LIST WITH INJECTED FEATURED */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {displayList.map((request, idx) => (
                <Link to={`/requests/${request.id}`} key={`${request.id}-${idx}`} className="group">
                  <Card className={cn(
                    "h-full hover:shadow-xl transition-all rounded-3xl border shadow-sm group-hover:-translate-y-1",
                    request.is_featured && "border-yellow-500/30 bg-yellow-500/5 ring-1 ring-yellow-500/10"
                  )}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-3 gap-4">
                        <div className="text-left">
                          {request.is_featured && <Badge className="bg-yellow-500 text-white text-[8px] font-black px-2 py-0.5 border-none mb-2 block w-fit">FEATURED</Badge>}
                          <h5 className="font-black text-lg leading-tight group-hover:text-primary transition-colors line-clamp-2">{request.title}</h5>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline" className="text-[9px] font-bold uppercase h-5 bg-muted/30">{request.category}</Badge>
                            {request.distance !== undefined && (
                              <Badge className="text-[9px] font-bold bg-primary/10 text-primary border-none h-5">
                                <MapPin className="h-2.5 w-2.5 mr-1" />{(request.distance / 1000).toFixed(1)} km
                              </Badge>
                            )}
                          </div>
                        </div>
                        <Badge 
                          variant={request.status === "open" ? "default" : request.status === "in_progress" ? "secondary" : "outline"}
                          className="text-[10px] font-bold uppercase h-5 shrink-0"
                        >
                          {request.status.replace('_', ' ')}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-3 mb-6 text-left leading-relaxed font-medium">{request.description}</p>
                      <div className="flex justify-between items-center mt-auto pt-4 border-t border-dashed">
                        <span className="text-[9px] font-bold text-muted-foreground uppercase">{new Date(request.created_at).toLocaleDateString()}</span>
                        <div className="flex items-center gap-1 text-[10px] font-black text-primary uppercase tracking-widest">Details <ArrowRight className="h-3 w-3" /></div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>

            {displayList.length === 0 && topFeatured.length === 0 && (
              <div className="text-center py-32 border-2 border-dashed rounded-[2rem] bg-muted/10">
                <HelpCircle className="h-16 w-16 text-muted-foreground/20 mx-auto mb-4" />
                <p className="text-muted-foreground font-bold text-lg">No requests match your current search.</p>
                <Button variant="link" onClick={() => { setSelectedCategory("All Categories"); setSelectedStatus("open"); }} className="mt-2 text-primary font-black uppercase tracking-widest">
                  Clear All Filters
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default RequestsPage;