"use client";

import React from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "@/hooks/useTranslation";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Shield, Lock, Eye, MapPin } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const PrivacyPolicyPage = () => {
  const { t } = useTranslation();
  return (
    <div className="container max-w-4xl mx-auto py-8 px-4 space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild className="rounded-full">
          <Link to="/settings">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">{t('pages.privacyPolicyPage')}</h1>
        <p>View full terms and privacy policy on  </p> <br>
                <a href="https://elijah-stark.github.io/Reon-communityhub/">Full documentation</a><br>
      </div>

      <Card className="border-none shadow-sm bg-muted/30">
        <CardContent className="p-6 space-y-6 text-sm md:text-base leading-relaxed text-muted-foreground">
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <Shield className="h-5 w-5 text-primary" />
              
              <h2 className="text-xl font-bold">{t('pages.dataCollection')}</h2>
            </div>
            <p>
              {t('pages.dataCollectionDesc')}
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <MapPin className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">{t('pages.locationData')}</h2>
            </div>
            <p>
              {t('pages.locationDataDesc')}
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <Lock className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">{t('pages.dataSecurity')}</h2>
            </div>
            <p>
              {t('pages.dataSecurityDesc1')}
            </p>
            <p>
              {t('pages.dataSecurityDesc2')}
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <Eye className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">{t('pages.yourRights')}</h2>
            </div>
            <p>
              {t('pages.yourRightsDesc')}
            </p>
          </section>

          <div className="pt-6 border-t">
            <p className="text-xs italic">{t('pages.privacyLastUpdated')}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default PrivacyPolicyPage;
