"use client";

import React, { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";
import { useReviews } from "@/context/ReviewsContext";
import { useTranslation } from "@/hooks/useTranslation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, User as UserIcon, ArrowLeft, Package2, Briefcase, Store, MessageSquare, Star, CheckCircle2, Crown, Circle } from "lucide-react";
import ReviewSection from "@/components/ReviewSection";
import { cn } from "@/lib/utils";

const PublicProfilePage = () => {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const { user: currentUser } = useSession();
  const { fetchReviewsForUser, calculateAverageRating } = useReviews();
  const navigate = useNavigate();

  const [profile, setProfile] = useState<any>(null);
  const [goods, setGoods] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [reviews, setReviews] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      if (!id) return;
      setLoading(true);
      setError(null);

      try {
        // Fetch Goods and Services with is_held filter
        const [profileRes, reviewsData, goodsRes, servicesRes] = await Promise.all([
          supabase.from('profiles').select('*').eq('id', id).maybeSingle(),
          fetchReviewsForUser(id),
          supabase.from('goods').select('*').eq('user_id', id).eq('is_held', false).order('created_at', { ascending: false }),
          supabase.from('services').select('*').eq('user_id', id).eq('is_held', false).order('created_at', { ascending: false })
        ]);

        if (profileRes.data) setProfile(profileRes.data);
        setReviews(reviewsData);
        if (goodsRes.data) setGoods(goodsRes.data);
        if (servicesRes.data) setServices(servicesRes.data);
      } catch (err) {
        console.error("Error fetching public profile data:", err);
        setError("Unable to load profile data.");
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [id, fetchReviewsForUser]);

  if (loading && !profile) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center min-h-[400px] gap-4">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!profile && !loading) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-8">
        <h3 className="text-2xl font-bold">{t('pages.userNotFound')}</h3>
        <Button variant="outline" className="mt-4" onClick={() => navigate(-1)}>{t('pages.goBack')}</Button>
      </div>
    );
  }

  // Set the primary identity to the unique username
  const displayName = profile?.username || "Neighbor";
  const fullName = [profile?.first_name, profile?.last_name].filter(Boolean).join(' ');
  const avgRating = calculateAverageRating(reviews);

  const isOnline = profile?.last_seen 
    ? (new Date().getTime() - new Date(profile.last_seen).getTime()) < 300000 
    : false;

  return (
    <div className="container max-w-5xl mx-auto py-8 space-y-8 px-4">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => navigate(-1)} className="rounded-full">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">{t('pages.neighborProfile')}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1 space-y-6">
          <Card className="text-center overflow-hidden border-none shadow-md">
            <div className={`h-24 bg-gradient-to-r ${profile?.is_premium ? 'from-yellow-400/30 to-orange-500/10' : 'from-primary/20 to-primary/5'}`} />
            <CardContent className="-mt-12 pb-6">
              <div className="relative inline-block">
                <Avatar className={`h-24 w-24 mx-auto border-4 border-background mb-4 shadow-xl ${profile?.is_premium ? 'ring-2 ring-yellow-400 ring-offset-4' : ''}`}>
                  <AvatarImage src={profile?.avatar_url || undefined} />
                  <AvatarFallback><UserIcon className="h-12 w-12" /></AvatarFallback>
                </Avatar>
                {profile?.is_verified && (
                  <div className="absolute bottom-4 right-0 bg-blue-500 rounded-full p-1 border-2 border-background shadow-sm">
                    <CheckCircle2 className="h-4 w-4 text-white fill-current" />
                  </div>
                )}
                {profile?.is_premium && (
                  <div className="absolute -top-2 -right-2 bg-yellow-500 rounded-full p-1.5 border-2 border-background shadow-lg animate-bounce">
                    <Crown className="h-4 w-4 text-white fill-current" />
                  </div>
                )}
              </div>
              
              <div className="flex flex-col items-center justify-center gap-1">
                <div className="flex items-center gap-1.5">
                  <h2 className="text-2xl font-black tracking-tight">{displayName}</h2>
                  {profile?.is_premium && <Crown className="h-4 w-4 text-yellow-500 fill-current" />}
                </div>
                {fullName && <p className="text-sm font-medium text-muted-foreground">{fullName}</p>}
                
                <div className="flex flex-wrap justify-center gap-1 mt-2">
                  {profile?.is_verified && <Badge variant="secondary" className="bg-blue-50 text-blue-700 border-blue-100 text-[8px] uppercase tracking-tighter h-4">Verified</Badge>}
                  {profile?.is_premium && <Badge className="bg-yellow-500 text-white text-[8px] uppercase tracking-tighter h-4 border-none shadow-sm">Supporter</Badge>}
                </div>
              </div>
              
              {reviews.length > 0 && (
                <div className="flex items-center justify-center gap-1 mt-3">
                  <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                  <span className="font-bold text-sm">{avgRating.toFixed(1)}</span>
                  <span className="text-muted-foreground text-xs">({reviews.length})</span>
                </div>
              )}

              <div className="flex flex-col items-center gap-2 mt-4">
                <Badge variant="outline" className={cn("flex gap-1.5 items-center px-3 py-1 font-bold text-[10px] uppercase", isOnline ? "text-green-600 border-green-200 bg-green-50" : "text-muted-foreground")}>
                  <Circle className={cn("h-2 w-2 fill-current", isOnline ? "animate-pulse" : "opacity-50")} />
                  {isOnline ? 'Online Now' : 'Last seen ' + (profile?.last_seen ? new Date(profile.last_seen).toLocaleDateString() : 'recently')}
                </Badge>
                {currentUser && currentUser.id !== profile?.id && (
                  <Button className="w-full mt-4 rounded-full" onClick={() => navigate(`/chat/${profile.id}`)}>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    Message Neighbor
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2 space-y-8">
          <Tabs defaultValue="offerings" className="w-full">
            <TabsList className="grid w-full grid-cols-2 max-w-[400px] mb-8">
              <TabsTrigger value="offerings">{t('pages.offerings')}</TabsTrigger>
              <TabsTrigger value="reviews">{t('pages.reviews')}</TabsTrigger>
            </TabsList>
            
            <TabsContent value="offerings" className="space-y-8">
              <section>
                <div className="flex items-center gap-2 mb-4">
                  <Package2 className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-bold">{t('pages.goodsForSale')}</h3>
                </div>
                {goods.length === 0 ? (
                  <p className="text-sm text-muted-foreground italic bg-muted/30 p-4 rounded-lg border border-dashed text-center">{t('pages.noGoodsListed')}</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {goods.map(item => (
                      <Link to={`/goods/${item.id}`} key={item.id}>
                        <Card className="overflow-hidden hover:shadow-md transition-shadow h-full">
                          <img src={item.image_url} alt={item.name} className="w-full h-32 object-cover" />
                          <CardContent className="p-3">
                            <h4 className="font-bold text-sm truncate">{item.name}</h4>
                            <div className="flex justify-between items-center mt-2">
                              <span className="text-xs font-bold text-primary">${item.price?.toFixed(2) || 'Free'}</span>
                              <Badge variant="outline" className="text-[10px] uppercase">{item.status}</Badge>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                )}
              </section>

              <section>
                <div className="flex items-center gap-2 mb-4">
                  <Briefcase className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-bold">{t('pages.servicesOffered')}</h3>
                </div>
                {services.length === 0 ? (
                  <p className="text-sm text-muted-foreground italic bg-muted/30 p-4 rounded-lg border border-dashed text-center">{t('pages.noServicesListed')}</p>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {services.map(service => (
                      <Link to={`/services/${service.id}`} key={service.id}>
                        <Card className="overflow-hidden hover:shadow-md transition-shadow h-full">
                          {service.image_url ? (
                            <img src={service.image_url} alt={service.name} className="w-full h-32 object-cover" />
                          ) : (
                            <div className="w-full h-32 bg-primary/5 flex items-center justify-center">
                              <Briefcase className="h-8 w-8 text-primary/20" />
                            </div>
                          )}
                          <CardContent className="p-3">
                            <h4 className="font-bold text-sm truncate">{service.name}</h4>
                            <div className="flex justify-between items-center mt-2">
                              <span className="text-xs font-bold text-primary">${service.price?.toFixed(2) || 'Free'}</span>
                              <Badge variant="outline" className="text-[10px] uppercase">{service.status}</Badge>
                            </div>
                          </CardContent>
                        </Card>
                      </Link>
                    ))}
                  </div>
                )}
              </section>
            </TabsContent>

            <TabsContent value="reviews">
              <ReviewSection userId={id} reviews={reviews} />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

export default PublicProfilePage;