"use client";

import React from "react";
import { ShoppingBag, Handshake, Map, Home, Briefcase, Settings } from "lucide-react";
import FeatureCard from "@/components/FeatureCard";
import { useTranslation } from "@/hooks/useTranslation";

const HomePage = () => {
  const { t } = useTranslation();

  return (
    <div className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed shadow-sm p-4 md:p-8 text-center">
      <div className="flex flex-col items-center gap-4">
        <h1 className="text-4xl font-bold tracking-tight">{t('pages.welcomeHub')}</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mt-2">
          {t('pages.connectNeighbors')}
        </p>

        <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 w-full max-w-3xl">
          <FeatureCard
            icon={ShoppingBag}
            title={t('pages.browseGoods')}
            description={t('pages.browseGoodsDesc')}
            href="/goods"
          />
          <FeatureCard
            icon={Handshake}
            title={t('pages.exploreServices')}
            description={t('pages.exploreServicesDesc')}
            href="/services"
          />
          <FeatureCard
            icon={Map}
            title={t('pages.viewMap')}
            description={t('pages.viewMapDesc')}
            href="/map"
          />
          <FeatureCard
            icon={Home}
            title={t('pages.myGoods')}
            description={t('pages.myGoodsDesc')}
            href="/my-goods"
          />
          <FeatureCard
            icon={Briefcase}
            title={t('pages.myServices')}
            description={t('pages.myServicesDesc')}
            href="/my-services"
          />
          <FeatureCard
            icon={Settings}
            title={t('common.settings')}
            description={t('pages.settingsDesc')}
            href="/settings"
          />
        </div>
      </div>
    </div>
  );
};

export default HomePage;