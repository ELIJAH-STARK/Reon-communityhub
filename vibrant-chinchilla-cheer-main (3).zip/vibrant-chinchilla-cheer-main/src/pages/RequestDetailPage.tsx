"use client";

import React, { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useRequests } from "@/context/RequestsContext";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  MapPin, 
  Loader2, 
  MessageSquare, 
  User as UserIcon, 
  Flag, 
  Share2, 
  Clock,
  HelpCircle,
  ExternalLink,
  CheckCircle2,
  Crown,
  Circle
} from "lucide-react";
import MapDisplay from "@/components/MapDisplay";
import ReportDialog from "@/components/ReportDialog";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";

const RequestDetailPage = () => {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const { requests, loading: requestsLoading } = useRequests();
  const { user, loading: sessionLoading } = useSession();
  const navigate = useNavigate();

  const [requesterProfile, setRequesterProfile] = useState<any>(null);
  const [loadingProfile, setLoadingProfile] = useState(true);
  const [isReportOpen, setIsReportOpen] = useState(false);

  const request = requests.find((r) => r.id === id);

  useEffect(() => {
    const fetchRequesterInfo = async () => {
      if (!request?.user_id) {
        setLoadingProfile(false);
        return;
      }

      setLoadingProfile(true);
      const { data } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', request.user_id)
        .single();

      if (data) {
        setRequesterProfile(data);
      }
      setLoadingProfile(false);
    };

    if (request) {
      fetchRequesterInfo();
    }
  }, [request]);

  const handleRespond = () => {
    if (!user) {
      toast.error(t('pages.mustLoginToHelp'));
      return;
    }
    if (user.id === request?.user_id) {
      toast.info(t('pages.ownRequest'));
      return;
    }
    if (request?.user_id) {
      navigate(`/chat/${request.user_id}`);
    }
  };

  const handleShare = async () => {
    try {
      if (navigator.share) {
        await navigator.share({
          title: request?.title || "Community Request",
          text: `A neighbor needs help: ${request?.title}`,
          url: window.location.href,
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success(t('pages.linkCopied'));
      }
    } catch (err) {
      console.error("Share failed", err);
    }
  };

  if (requestsLoading || sessionLoading || loadingProfile) {
    return (
      <div className="flex h-[400px] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!request) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <HelpCircle className="h-12 w-12 text-muted-foreground opacity-20" />
        <h3 className="text-2xl font-bold">{t('pages.requestNotFound')}</h3>
        <Button variant="outline" asChild><Link to="/requests">{t('navigation.requests')}</Link></Button>
      </div>
    );
  }

  const requesterDisplayName = requesterProfile?.username || 
                               [requesterProfile?.first_name, requesterProfile?.last_name].filter(Boolean).join(' ') || 
                               "Neighbor";

  const requestLocation: [number, number] | null = request.latitude && request.longitude ? [request.latitude, request.longitude] : null;
  
  const isOnline = requesterProfile?.last_seen 
    ? (new Date().getTime() - new Date(requesterProfile.last_seen).getTime()) < 300000 
    : false;

  return (
    <div className="container max-w-5xl mx-auto py-8 space-y-8 px-4">
      <div className="flex flex-wrap gap-4 justify-between items-center">
        <Button variant="outline" asChild size="sm" className="rounded-full">
          <Link to="/requests">
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t('navigation.requests')}
          </Link>
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleShare} className="rounded-full">
            <Share2 className="h-4 w-4 mr-2" /> {t('pages.share')}
          </Button>
          {user?.id !== request.user_id && (
            <>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive rounded-full" onClick={() => setIsReportOpen(true)}>
                <Flag className="h-4 w-4 mr-2" /> {t('common.reports')}
              </Button>
              <Button size="sm" onClick={handleRespond} className="rounded-full shadow-lg">
                <MessageSquare className="h-4 w-4 mr-2" /> {t('helpNeighbor')}
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="space-y-4">
            <div className="flex justify-between items-start gap-4">
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="text-[10px] uppercase font-bold tracking-widest text-primary">
                    {request.category}
                  </Badge>
                  {request.is_featured && (
                    <Badge className="bg-yellow-500 text-white text-[10px] font-bold px-2 py-0">
                      FEATURED
                    </Badge>
                  )}
                </div>
                <h1 className="text-4xl font-black tracking-tight">{request.title}</h1>
                <div className="flex items-center gap-4 text-xs text-muted-foreground font-medium">
                  <span className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5" />
                    Posted {new Date(request.created_at).toLocaleDateString()}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <div className={cn("h-2 w-2 rounded-full", request.status === 'open' ? 'bg-green-500' : 'bg-orange-500')} />
                    Status: {request.status.replace('_', ' ')}
                  </span>
                </div>
              </div>
            </div>

            <div className="bg-card border rounded-2xl p-6 shadow-sm">
              <h3 className="text-xs font-black uppercase tracking-widest text-muted-foreground mb-4">{t('Details')}</h3>
              <p className="text-lg leading-relaxed whitespace-pre-wrap text-foreground/90">
                {request.description || t('pages.noAdditionalDetails')}
              </p>
            </div>
          </div>

          <Card className="overflow-hidden border-none shadow-sm bg-muted/30 rounded-2xl">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="flex items-center gap-2 text-base font-bold">
                <MapPin className="h-5 w-5 text-primary" /> {t('Area')}
              </CardTitle>
              <Button variant="ghost" size="sm" asChild className="text-xs font-bold text-primary">
                <Link to="/map">{t('pages.openFullMap')}</Link>
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              {requestLocation ? (
                <div className="h-72 w-full">
                  <MapDisplay 
                    center={requestLocation} 
                    requests={[request]} 
                    zoom={15} 
                  />
                </div>
              ) : (
                <div className="py-12 text-center text-muted-foreground italic bg-muted/20">
                  {t('pages.locationNotProvided')}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border shadow-md rounded-2xl overflow-hidden">
            <CardHeader className="bg-primary/5 border-b pb-4">
              <CardTitle className="text-sm font-black uppercase tracking-widest text-primary/70">{t('requests.postedBy')}</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-6">
              <div className="flex items-center gap-4">
                <Link to={`/profile/${request.user_id}`} className="group relative shrink-0">
                  <Avatar className="h-16 w-16 border-2 transition-all group-hover:border-primary group-hover:scale-105">
                    <AvatarImage src={requesterProfile?.avatar_url || undefined} />
                    <AvatarFallback className="bg-muted text-xl font-bold">
                      {requesterDisplayName[0]}
                    </AvatarFallback>
                  </Avatar>
                  {requesterProfile?.is_verified && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-1 border-2 border-background shadow-sm">
                      <CheckCircle2 className="h-3.5 w-3.5 text-white fill-current" />
                    </div>
                  )}
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/profile/${request.user_id}`} className="hover:text-primary transition-colors flex items-center gap-1.5">
                    <h4 className="font-black text-xl truncate">
                      {requesterDisplayName}
                    </h4>
                    {requesterProfile?.is_premium && <Crown className="h-4 w-4 text-yellow-500 fill-current" />}
                  </Link>
                  <div className="flex flex-wrap items-center gap-2 mt-1">
                    <Badge variant="outline" className={cn(
                      "h-5 text-[9px] font-bold uppercase tracking-tighter flex gap-1 items-center",
                      isOnline ? "text-green-600 border-green-200 bg-green-50" : "text-muted-foreground bg-muted/50"
                    )}>
                      <Circle className={cn("h-1.5 w-1.5 fill-current", isOnline && "animate-pulse")} />
                      {isOnline ? t('requests.activeNow') : t('requests.lastSeen') + ' ' + (requesterProfile?.last_seen ? new Date(requesterProfile.last_seen).toLocaleDateString() : t('requests.recently'))}
                    </Badge>
                  </div>
                </div>
              </div>
              
              <div className="space-y-3">
                {user?.id !== request.user_id && (
                  <Button className="w-full rounded-xl h-11 font-bold shadow-md" onClick={handleRespond}>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    {t('requests.contactNeighbor')}
                  </Button>
                )}
                <Button variant="outline" className="w-full rounded-xl h-11 font-bold" asChild>
                  <Link to={`/profile/${request.user_id}`}>
                    {t('requests.viewProfile')}
                    <ExternalLink className="ml-2 h-4 w-4 opacity-50" />
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="bg-primary/5 rounded-2xl p-6 border border-primary/10">
            <h4 className="font-bold text-sm mb-2 flex items-center gap-2">
              <HelpCircle className="h-4 w-4 text-primary" />
              {t('requests.safetyFirst')}
            </h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              {t('requests.safetyTips')}
            </p>
          </div>
        </div>
      </div>

      <ReportDialog 
        isOpen={isReportOpen} 
        onOpenChange={setIsReportOpen} 
        targetId={request.id} 
        targetType="good" // Using good as generic target type for listings
      />
    </div>
  );
};

export default RequestDetailPage;