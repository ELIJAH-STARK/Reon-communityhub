"use client";

import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate, Link } from "react-router-dom";
import { useSession } from "@/context/SessionContext";
import { useSystemSettingsContext } from "@/context/SystemSettingsContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, ShieldCheck, CheckCircle2, AlertCircle, CreditCard, Wallet, Coins } from "lucide-react";
import CheckoutSummary from "@/components/checkout/CheckoutSummary";
import SquarePaymentForm from "@/components/SquarePaymentForm";
import PayPalPaymentForm from "@/components/checkout/PayPalPaymentForm";
import CryptoPaymentForm from "@/components/checkout/CryptoPaymentForm";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const CheckoutPage = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { user, isGuest, refreshProfile } = useSession();
  const { settings } = useSystemSettingsContext();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const typeParam = searchParams.get("type");
  const type = (typeParam === '4slot' || typeParam === '1slot' || typeParam === 'premium') 
    ? typeParam 
    : 'premium';
  
  const getAmount = () => {
    switch (type) {
      case 'premium': return 29.99;
      case '4slot': return 6.99;
      case '1slot': return 1.99;
      default: return 29.99;
    }
  };

  useEffect(() => {
    if (isGuest) {
      toast.error("Please register to complete your purchase.");
      navigate("/login?redirect=/checkout");
    }
  }, [isGuest, navigate]);

  const handlePaymentSuccess = async (sourceId?: string) => {
    if (!user) return;
    
    setIsProcessing(true);
    setError(null);

    try {
      // If we have a sourceId, it's Square
      if (sourceId) {
        const { data, error: functionError } = await supabase.functions.invoke('process-square-payment', {
          body: {
            sourceId,
            amount: getAmount(),
            itemType: type,
            userId: user.id
          }
        });
        if (functionError) throw functionError;
        if (data?.error) throw new Error(data.error);
      }

      setIsSuccess(true);
      await refreshProfile();
      toast.success("Transaction successful!");
    } catch (err: any) {
      console.error("Payment processing error:", err);
      setError(err.message || "Something went wrong during payment verification.");
      toast.error("Payment verification failed.");
    } finally {
      setIsProcessing(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="container max-w-lg mx-auto py-20 px-4 text-center space-y-6">
        <div className="bg-green-500/10 h-20 w-20 rounded-full flex items-center justify-center mx-auto animate-in zoom-in duration-500">
          <CheckCircle2 className="h-10 w-10 text-green-500" />
        </div>
        <div className="space-y-2">
          <h1 className="text-3xl font-black">Thank You!</h1>
          <p className="text-muted-foreground">
            {type === 'crypto' 
              ? "Your request has been submitted for verification. Benefits will apply soon."
              : "Your transaction was successful. Your account benefits are now active."}
          </p>
        </div>
        <Button asChild className="w-full h-12 rounded-xl text-lg font-bold">
          <Link to="/profile">Go to My Dashboard</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="container max-w-5xl mx-auto py-8 px-4 space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full">
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <h1 className="text-2xl font-bold">Complete Upgrade</h1>
      </div>

      {/* Premium Disabled Message */}
      {!settings.premiumEnabled && type === 'premium' && (
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-6 flex items-start gap-4">
            <div className="flex-shrink-0 mt-0.5">
              <AlertCircle className="h-5 w-5 text-red-600" />
            </div>
            <div className="flex-1">
              <h3 className="font-bold text-red-900 mb-1">Premium Purchases Disabled</h3>
              <p className="text-sm text-red-800 mb-4">
                Premium upgrades are currently disabled by the administrator. Existing premium members retain their benefits.
              </p>
              <Button asChild variant="outline">
                <Link to="/profile">Return to Dashboard</Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {!settings.premiumEnabled && type === 'premium' ? (
        <Card>
          <CardContent className="p-12 text-center">
            <AlertCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-lg font-bold mb-2">Unable to Process Purchase</h2>
            <p className="text-muted-foreground">
              This type of purchase is currently unavailable. Please try again later.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="space-y-6">
          <h2 className="text-xl font-bold flex items-center gap-2">
            <ShieldCheck className="h-5 w-5 text-primary" />
            Order Summary
          </h2>
          <CheckoutSummary type={type} />
        </div>

        <div className="space-y-6">
          <h2 className="text-xl font-bold">Choose Payment Method</h2>
          
          <Tabs defaultValue="card" className="w-full">
            <TabsList className="grid w-full grid-cols-3 h-12 p-1 bg-muted rounded-2xl mb-6">
              <TabsTrigger value="card" className="rounded-xl flex items-center gap-2 text-xs font-bold">
                <CreditCard className="h-4 w-4" /> <span className="hidden sm:inline">Card</span>
              </TabsTrigger>
              <TabsTrigger value="paypal" className="rounded-xl flex items-center gap-2 text-xs font-bold">
                <Wallet className="h-4 w-4" /> <span className="hidden sm:inline">PayPal</span>
              </TabsTrigger>
              <TabsTrigger value="crypto" className="rounded-xl flex items-center gap-2 text-xs font-bold">
                <Coins className="h-4 w-4" /> <span className="hidden sm:inline">Crypto</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="card">
              <div className="bg-card border rounded-3xl p-6 shadow-sm">
                <SquarePaymentForm 
                  amount={getAmount()}
                  onSuccess={handlePaymentSuccess} 
                  isProcessing={isProcessing} 
                />
              </div>
            </TabsContent>

            <TabsContent value="paypal">
              <div className="bg-card border rounded-3xl p-6 shadow-sm">
                <PayPalPaymentForm 
                  amount={getAmount()}
                  onSuccess={handlePaymentSuccess}
                  isProcessing={isProcessing}
                  setIsProcessing={setIsProcessing}
                  itemType={type}
                  userId={user?.id || ""}
                />
              </div>
            </TabsContent>

            <TabsContent value="crypto">
              <div className="bg-card border rounded-3xl p-6 shadow-sm">
                <CryptoPaymentForm 
                  amount={getAmount()}
                  itemType={type}
                  userId={user?.id || ""}
                  onSuccess={() => setIsSuccess(true)}
                />
              </div>
            </TabsContent>
          </Tabs>

          <div className="text-center">
            <p className="text-[10px] text-muted-foreground uppercase tracking-widest font-black">
              Safe & Secure Checkout
            </p>
          </div>
        </div>
      </div>
        </>
      )}
    </div>
  );
};

export default CheckoutPage;