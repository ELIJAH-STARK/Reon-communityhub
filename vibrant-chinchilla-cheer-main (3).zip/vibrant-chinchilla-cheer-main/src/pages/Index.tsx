"use client";
import React, { useMemo, useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ShoppingBag, Handshake, Map, Home, Briefcase, Settings, ChevronRight, Package2, ArrowRight, Loader2, RefreshCcw, AlertTriangle, MapPin, CheckCircle2, Sparkles, Crown, Megaphone, HelpCircle } from "lucide-react";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useRequests } from "@/context/RequestsContext"; 
import { useGeolocation } from "@/hooks/use-geolocation";
import { useTranslation } from "@/hooks/useTranslation";
import { calculateDistance, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import BibleQuoteCard from "@/components/BibleQuoteCard";
import { useSession } from "@/context/SessionContext";
import AdBanner from "@/components/AdBanner";
import { supabase } from "@/integrations/supabase/client";
import { Color } from "maplibre-gl";

const Index = () => {
  const { t } = useTranslation();
  const { uploadedItems, loadingItems, errorItems, refreshItems } = useItems();
  const { uploadedServices, loadingServices, errorServices, refreshServices } = useServices();
  const { requests, loading: loadingRequests } = useRequests(); 
  const { latitude, longitude } = useGeolocation();
  const { isPremium } = useSession();
  
  const [latestAnnouncement, setLatestAnnouncement] = useState<any>(null);
  
  useEffect(() => {
    const fetchAnnouncement = async () => {
      const { data } = await supabase
        .from('announcements')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      if (data) setLatestAnnouncement(data);
    };
    
    fetchAnnouncement();
  }, []);

  const userLocation: [number, number] | null = latitude && longitude ? [latitude, longitude] : null;
  
  // Get featured and visible items
  const featuredItems = useMemo(() => {
    return uploadedItems.filter(i => i.is_featured && !i.is_held).map(i => ({ ...i, type: 'good' }));
  }, [uploadedItems]);
  
  const featuredServices = useMemo(() => {
    return uploadedServices.filter(s => s.is_featured && !s.is_held).map(s => ({ ...s, type: 'service' }));
  }, [uploadedServices]);

  const featuredRequests = useMemo(() => {
    return requests.filter(r => r.is_featured && !r.is_held).map(r => ({ ...r, type: 'request' }));
  }, [requests]);
  
  const hubSpotlightItems = useMemo(() => {
    const combined = [...featuredItems, ...featuredServices, ...featuredRequests];
    return combined.sort(() => 0.5 - Math.random()).slice(0, 4);
  }, [featuredItems, featuredServices, featuredRequests]);
  
  const nearbyGoods = useMemo(() => {
    if (!userLocation) return uploadedItems.filter(i => !i.is_featured && !i.is_held).slice(0, 4);
    
    return [...uploadedItems]
      .filter(item => 
        item.latitude && 
        item.longitude && 
        item.status === 'available' && 
        !item.is_featured &&
        !item.is_held
      )
      .map(item => ({
        ...item,
        distance: calculateDistance(
          userLocation[0],
          userLocation[1],
          item.latitude!,
          item.longitude!
        )
      }))
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 4);
  }, [uploadedItems, userLocation]);
  
  const latestServices = uploadedServices.filter(s => !s.is_held).slice(0, 4);

  return (
    <div className="flex flex-1 flex-col gap-8 pb-12">
      {/* Global Announcement Banner */}
      {latestAnnouncement && (
        <section className="px-4 -mb-4">
          <div className={cn(
            "p-3 rounded-2xl border flex items-center gap-4 animate-in fade-in slide-in-from-top-4 duration-700",
            latestAnnouncement.type === 'destructive' 
              ? "bg-red-50 border-red-200 text-red-800" 
              : latestAnnouncement.type === 'warning' 
                ? "bg-orange-50 border-orange-200 text-orange-800" 
                : "bg-blue-50 border-blue-200 text-blue-800"
          )}>
            <div className={cn(
              "p-2 rounded-full",
              latestAnnouncement.type === 'destructive' 
                ? "bg-red-100" 
                : latestAnnouncement.type === 'warning' 
                  ? "bg-orange-100" 
                  : "bg-blue-100"
            )}>
              <Megaphone className="h-5 w-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="font-bold text-sm truncate">{latestAnnouncement.title}</h4>
              <p className="text-xs opacity-90 line-clamp-1">{latestAnnouncement.content}</p>
            </div>
            <span className="text-[10px] font-bold uppercase tracking-widest hidden sm:inline">Just Now</span>
          </div>
        </section>
      )}
      
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary/10 via-orange-50 to-primary/5 p-8 md:p-12 text-center">
        <div className="absolute top-0 right-0 -m-12 h-64 w-64 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute bottom-0 left-0 -m-12 h-64 w-64 rounded-full bg-orange-400/10 blur-3xl" />
        <div className="relative flex flex-col items-center gap-4">
          <Badge style={{ color: "black" }} variant="outline" className="animate-pulse border-primary/20 bg-primary/5 text-primary">
            {t('pages.welcomeToCommunityHub')}
          </Badge>
          <h1 className="max-w-3xl text-4xl font-extrabold tracking-tight md:text-5xl lg:text-6xl">
            {t('pages.everythingYouNeed')} <br />
            <span className="bg-gradient-to-r from-primary to-orange-500 bg-clip-text text-transparent">
              {t('pages.rightInYourNeighborhood')}
            </span>
          </h1>
          <p style={{ color: "orange" }} className="max-w-2xl text-lg text-muted-foreground">
            {t('pages.connectNeighborsToTrade')}
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-4">
            <Button size="lg" asChild className="h-12 px-8 rounded-full shadow-lg hover:shadow-primary/20 transition-all">
              <Link to="/goods">{t('pages.browseGoods')}</Link>
            </Button>
            <Button size="lg" variant="outline" asChild className="h-12 px-8 rounded-full">
              <Link to="/map">{t('pages.viewMap')}</Link>
            </Button>
          </div>
        </div>
      </section>
      
      <section className="max-w-3xl mx-auto w-full px-4">
        <BibleQuoteCard />
      </section>
      
      {/* Internal Ad / Premium CTA */}
      <section className="px-4">
        <AdBanner />
      </section>
      
      {/* Hub Spotlight (Premium Feature) */}
      {hubSpotlightItems.length > 0 && (
        <section className="space-y-4 px-4">
          <div className="flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-yellow-500 fill-yellow-500" />
            <h2 className="text-2xl font-bold tracking-tight">{t('pages.hubSpotlight')}</h2>
            <Badge variant="secondary" className="ml-2 bg-yellow-500/10 text-yellow-600 border-yellow-500/20">{t('pages.featured')}</Badge>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {hubSpotlightItems.map((item: any) => (
              <Link 
                to={
                  item.type === 'service' ? `/services/${item.id}` : 
                  item.type === 'request' ? `/requests/${item.id}` : 
                  `/goods/${item.id}`
                } 
                key={`${item.type}-${item.id}`} 
                className="group"
              >
                <Card className="overflow-hidden border-yellow-500/30 bg-yellow-500/5 shadow-sm transition-all hover:shadow-md h-full flex flex-col relative ring-1 ring-yellow-500/20">
                  <div className="aspect-square relative">
                    {item.image_url ? (
                      <img 
                        src={item.image_url} 
                        alt={item.name || item.title} 
                        className="h-full w-full object-cover transition-transform group-hover:scale-105" 
                      />
                    ) : (
                      <div className="h-full w-full bg-primary/5 flex items-center justify-center">
                        {item.type === 'service' ? <Briefcase className="h-10 w-10 text-primary/20" /> : <HelpCircle className="h-10 w-10 text-primary/20" />}
                      </div>
                    )}
                    <div className="absolute top-2 left-2 bg-yellow-500 text-white text-[8px] font-bold px-2 py-0.5 rounded-full shadow-lg flex items-center gap-1">
                      <Sparkles className="h-2 w-2 fill-current" />
                      {t('pages.featured').toUpperCase()}
                    </div>
                  </div>
                  <CardContent className="p-3">
                    <h3 className="font-semibold text-sm truncate">{item.name || item.title}</h3>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-primary font-bold text-sm">
                        {item.type === 'good' ? (item.price === 0 ? t('common.free') : `$${item.price}`) : 
                         item.type === 'service' ? t('priceOptions.negotiable') : t('priceOptions.helpWanted')}
                      </span>
                      <span className="text-[10px] text-muted-foreground uppercase font-bold">{item.category}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}
      
      <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-7 gap-4 px-4">
        {[
          { icon: ShoppingBag, label: t('pages.navGoods'), href: "/goods", color: "bg-blue-50 text-blue-600" },
          { icon: Handshake, label: t('pages.navServices'), href: "/services", color: "bg-green-50 text-green-600" },
          { icon: HelpCircle, label: t('pages.navRequests'), href: "/requests", color: "bg-purple-50 text-purple-600" },
          { icon: Map, label: t('pages.navMap'), href: "/map", color: "bg-orange-50 text-orange-600" },
          { icon: Home, label: t('pages.navMyGoods'), href: "/my-goods", color: "bg-purple-50 text-purple-600" },
          { icon: Briefcase, label: t('pages.navMyServices'), href: "/my-services", color: "bg-amber-50 text-amber-600" },
          { icon: Settings, label: t('pages.navSettings'), href: "/settings", color: "bg-slate-50 text-slate-600" },
        ].map((item) => (
          <Link key={item.label} to={item.href} className="group">
            <Card className="h-full border-none shadow-sm transition-all group-hover:shadow-md group-hover:-translate-y-1">
              <CardContent className="flex flex-col items-center gap-3 p-4">
                <div className={cn("p-3 rounded-2xl transition-transform group-hover:scale-110", item.color)}>
                  <item.icon className="h-6 w-6" />
                </div>
                <span className="font-semibold text-sm">{item.label}</span>
              </CardContent>
            </Card>
          </Link>
        ))}
      </section>
      
      <section className="space-y-4 px-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <MapPin className="h-6 w-6 text-primary" />
              {userLocation ? t('pages.treasuresNearYou') : t('pages.newestTreasures')}
            </h2>
            <p className="text-sm text-muted-foreground">{t('pages.findWhatYouNeed')}</p>
          </div>
          <Button variant="ghost" asChild>
            <Link to="/goods" className="flex items-center gap-2">
              {t('pages.viewAll')} <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
        
        {loadingItems ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : errorItems ? (
          <div className="py-12 flex flex-col items-center gap-4 bg-destructive/5 rounded-2xl border border-dashed border-destructive/20 text-center">
            <AlertTriangle className="h-10 w-10 text-destructive/50" />
            <p className="text-sm text-muted-foreground">{t('pages.unableToLoadItems')}</p>
            <Button variant="outline" size="sm" onClick={refreshItems}><RefreshCcw className="h-4 w-4 mr-2" /> {t('pages.retry')}</Button>
          </div>
        ) : nearbyGoods.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {nearbyGoods.map((item: any) => (
              <Link to={`/goods/${item.id}`} key={item.id} className="group">
                <Card className="overflow-hidden border-none shadow-sm transition-all hover:shadow-md h-full flex flex-col relative">
                  <div className="aspect-square relative">
                    <img src={item.image_url} alt={item.name} className="h-full w-full object-cover transition-transform group-hover:scale-105" />
                    {item.distance !== undefined && (
                      <Badge className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-md text-[9px] border-none">
                        {(item.distance / 1000).toFixed(1)} {t('pages.kmAway')}
                      </Badge>
                    )}
                    {item.price === 0 && <Badge className="absolute top-2 left-2 bg-green-500">{t('common.free')}</Badge>}
                    {item.is_seller_verified && (
                      <div className="absolute bottom-10 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-0.5 px-2 flex items-center justify-center gap-1">
                        <CheckCircle2 className="h-2.5 w-2.5 text-white fill-current" />
                        <span className="text-[8px] font-bold text-white uppercase">{t('pages.verifiedNeighbor')}</span>
                      </div>
                    )}
                  </div>
                  <CardContent className="p-3">
                    <h3 className="font-semibold text-sm truncate">{item.name}</h3>
                    <div className="flex items-center justify-between mt-1">
                      <span className="text-primary font-bold text-sm">
                        {item.price ? `$${item.price}` : t('common.free')}
                      </span>
                      <span className="text-[10px] text-muted-foreground uppercase font-bold">{item.category}</span>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center text-muted-foreground bg-muted/20 rounded-2xl border-2 border-dashed">
            <Package2 className="h-10 w-10 mx-auto mb-2 opacity-20" />
            <p>{t('pages.noItemsNearby')}</p>
          </div>
        )}
      </section>
      
      <section className="space-y-4 px-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h2 className="text-2xl font-bold tracking-tight">{t('pages.skilledNeighbors')}</h2>
            <p className="text-sm text-muted-foreground">{t('pages.expertHelpFromVerified')}</p>
          </div>
          <Button variant="ghost" asChild>
            <Link to="/services" className="flex items-center gap-2">
              {t('pages.viewAll')} <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
        
        {loadingServices ? (
          <div className="flex justify-center py-12"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>
        ) : latestServices.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {latestServices.map((service) => (
              <Link to={`/services/${service.id}`} key={service.id} className="group">
                <Card className="overflow-hidden border-none shadow-sm transition-all hover:shadow-md h-full flex flex-col relative">
                  <div className="h-32 bg-primary/5 relative">
                    {service.image_url ? (
                      <img src={service.image_url} alt={service.name} className="h-full w-full object-cover" />
                    ) : (
                      <div className="h-full w-full flex items-center justify-center">
                        <Briefcase className="h-8 w-8 text-primary/20" />
                      </div>
                    )}
                    {service.is_provider_verified && (
                      <div className="absolute bottom-0 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-0.5 px-2 flex items-center justify-center gap-1">
                        <CheckCircle2 className="h-2.5 w-2.5 text-white fill-current" />
                        <span className="text-[8px] font-bold text-white uppercase">{t('pages.verifiedNeighbor')}</span>
                      </div>
                    )}
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-sm">{service.name}</h3>
                    <p className="text-xs text-muted-foreground line-clamp-2 mt-1">{service.description}</p>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="text-xs font-bold bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                        {service.category}
                      </span>
                      <ArrowRight className="h-4 w-4 text-primary opacity-0 -translate-x-2 transition-all group-hover:opacity-100 group-hover:translate-x-0" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        ) : (
          <div className="py-12 text-center text-muted-foreground bg-muted/20 rounded-2xl border-2 border-dashed">
            <Briefcase className="h-10 w-10 mx-auto mb-2 opacity-20" />
            <p>{t('pages.noServicesYet')}</p>
          </div>
        )}
      </section>
    </div>
  );
};

export default Index;