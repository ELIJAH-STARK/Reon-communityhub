"use client";

import React, { useState, useEffect, useMemo } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useServices } from "@/context/ServicesContext";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MapPin, Loader2, MessageSquare, User as UserIcon, Briefcase, ExternalLink, Flag, Share2, Map as MapIcon, ChevronRight, CheckCircle2, Crown, Circle } from "lucide-react";
import MapDisplay from "@/components/MapDisplay";
import ImageGallery from "@/components/ImageGallery";
import ReportDialog from "@/components/ReportDialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import ReviewSection from "@/components/ReviewSection";
import { cn } from "@/lib/utils";

const ServiceDetailPage = () => {
  const { t } = useTranslation();
  const { id } = useParams<{ id: string }>();
  const { uploadedServices, loadingServices } = useServices();
  const { user, loading: sessionLoading } = useSession();
  const navigate = useNavigate();

  const [providerProfile, setProviderProfile] = useState<any>(null);
  const [loadingProviderInfo, setLoadingProviderInfo] = useState(true);
  const [isReportOpen, setIsReportOpen] = useState(false);

  const service = uploadedServices.find((s) => s.id === id);

  const relatedServices = useMemo(() => {
    if (!service) return [];
    return uploadedServices
      .filter((s) => s.category === service.category && s.id !== service.id && s.status === 'available')
      .slice(0, 3);
  }, [service, uploadedServices]);

  useEffect(() => {
    const fetchProviderInfo = async () => {
      if (!service?.user_id) {
        setLoadingProviderInfo(false);
        return;
      }

      setLoadingProviderInfo(true);
      const { data: profileData } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', service.user_id)
        .single();

      if (profileData) {
        setProviderProfile(profileData);
      }
      setLoadingProviderInfo(false);
    };

    if (service) {
      fetchProviderInfo();
    }
  }, [service]);

  const handleMessageProvider = () => {
    if (!user) {
      toast.error(t('auth.pleaseLogInToMessage'));
      return;
    }
    if (user.id === service?.user_id) {
      toast.info(t('pages.cannotMessageYourself'));
      return;
    }
    if (service?.user_id) {
      navigate(`/chat/${service.user_id}/_/${service.id}`);
    }
  };

  const handleShare = async () => {
    const shareData = {
      title: service?.name || "Local Service Recommendation",
      text: `Check out ${service?.name} in our neighborhood!`,
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success("Link copied!");
      }
    } catch (err) {
      console.error("Share error", err);
    }
  };

  if (loadingServices || sessionLoading || loadingProviderInfo) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!service) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center p-8">
        <h3 className="text-2xl font-bold">{t('pages.serviceNotFound')}</h3>
        <Button variant="outline" className="mt-4" asChild><Link to="/services">{t('pages.backToServices')}</Link></Button>
      </div>
    );
  }

  // Set the primary identity to the unique username
  const providerDisplayName = providerProfile?.username || 
                               [providerProfile?.first_name, providerProfile?.last_name].filter(Boolean).join(' ') || 
                               "Neighbor";

  const serviceLocation: [number, number] | null = service.latitude && service.longitude ? [service.latitude, service.longitude] : null;

  const isOnline = providerProfile?.last_seen 
    ? (new Date().getTime() - new Date(providerProfile.last_seen).getTime()) < 300000 
    : false;

  const mapPoints = [];
  if (serviceLocation) {
    mapPoints.push({ ...service, type: 'service' });
  }
  if (providerProfile?.live_location_enabled && providerProfile.latitude && providerProfile.longitude) {
    mapPoints.push({
      id: `provider-${providerProfile.id}`,
      name: `${providerDisplayName} (Live)`,
      latitude: providerProfile.latitude,
      longitude: providerProfile.longitude,
      type: 'item',
      status: 'Active',
      description: 'Provider is currently active at this location.'
    });
  }

  return (
    <div className="container max-w-5xl mx-auto py-8 space-y-8 px-4">
      {service.is_provider_verified && (
        <div className="bg-blue-500 text-white py-2 px-4 rounded-xl flex items-center justify-center gap-2 shadow-md animate-in fade-in slide-in-from-top-4 duration-500">
          <CheckCircle2 className="h-5 w-5 fill-current text-white" />
          <span className="font-bold text-sm uppercase tracking-wider">{t('pages.verifiedProfessional')}</span>
        </div>
      )}

      <div className="flex flex-wrap gap-4 justify-between items-center">
        <Button variant="outline" asChild size="sm">
          <Link to="/services">
            <ArrowLeft className="h-4 w-4 mr-2" />
            {t('pages.backToServices')}
          </Link>
        </Button>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleShare}>
            <Share2 className="h-4 w-4 mr-2" /> Share
          </Button>
          {user?.id !== service.user_id && (
            <>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive" onClick={() => setIsReportOpen(true)}>
                <Flag className="h-4 w-4 mr-2" /> Report
              </Button>
              <Button size="sm" onClick={handleMessageProvider}>
                <MessageSquare className="h-4 w-4 mr-2" /> Message
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <ImageGallery 
            mainImage={service.image_url || ''} 
            additionalImages={service.additional_images} 
            alt={service.name} 
          />

          <div className="space-y-4">
            <div className="flex justify-between items-start">
              <div className="space-y-1">
                <h1 className="text-4xl font-extrabold tracking-tight">{service.name}</h1>
                <Badge variant="outline" className="text-muted-foreground text-[10px] tracking-widest uppercase">{service.category}</Badge>
              </div>
              <Badge variant={service.status === "available" ? "default" : "secondary"}>
                {service.status.toUpperCase()}
              </Badge>
            </div>

            <div className="flex items-center gap-3">
              {service.price === 0 ? (
                <span className="text-3xl font-bold text-green-600">{t('pages.free')}</span>
              ) : service.price === null ? (
                <span className="text-3xl font-bold text-primary">{t('pages.negotiable')}</span>
              ) : (
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-primary">
                    ${service.discount_percentage ? (service.price * (1 - service.discount_percentage / 100)).toFixed(2) : service.price.toFixed(2)}
                  </span>
                  {service.discount_percentage && (
                    <span className="text-xl text-muted-foreground line-through opacity-50">${service.price.toFixed(2)}</span>
                  )}
                </div>
              )}
            </div>

            <div className="h-px bg-border my-6" />

            <div className="prose prose-sm dark:prose-invert max-w-none">
              <h3 className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-2">Service Details</h3>
              <p className="text-lg leading-relaxed text-foreground/80">{service.description}</p>
            </div>
          </div>

          <Card className="border-none shadow-sm bg-muted/20 overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between bg-muted/40 px-6 py-4">
              <CardTitle className="text-base flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" /> Service Map
              </CardTitle>
              <Button variant="ghost" size="sm" asChild>
                <Link to="/map" className="text-xs">Explore Area</Link>
              </Button>
            </CardHeader>
            <CardContent className="p-0">
              {serviceLocation ? (
                <div className="h-80 w-full overflow-hidden">
                  <MapDisplay center={serviceLocation} services={mapPoints} zoom={15} />
                </div>
              ) : (
                <div className="py-12 text-center text-muted-foreground italic">Location data unavailable.</div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border shadow-sm overflow-hidden">
            <CardHeader className="bg-primary/5 border-b">
              <CardTitle className="text-sm">Service Provider</CardTitle>
            </CardHeader>
            <CardContent className="pt-6 space-y-4">
              <div className="flex items-center gap-4">
                <Link to={`/profile/${service.user_id}`} className="shrink-0 group relative">
                  <Avatar className="h-14 w-14 border-2 group-hover:border-primary transition-colors">
                    <AvatarImage src={providerProfile?.avatar_url || undefined} />
                    <AvatarFallback><UserIcon className="h-6 w-6" /></AvatarFallback>
                  </Avatar>
                  {service.is_provider_verified && (
                    <div className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-1 border-2 border-background">
                      <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                    </div>
                  )}
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/profile/${service.user_id}`} className="hover:text-primary transition-colors">
                    <h4 className="font-black text-lg flex items-center gap-1 truncate">
                      {providerDisplayName} 
                      {providerProfile?.is_premium && <Crown className="h-4 w-4 text-yellow-500 fill-current" />}
                      <ExternalLink className="h-3 w-3 opacity-50" />
                    </h4>
                  </Link>
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="outline" className={cn("h-5 text-[9px] uppercase tracking-widest flex gap-1 items-center", isOnline ? "text-green-600 border-green-200 bg-green-50" : "text-muted-foreground")}>
                      <Circle className={cn("h-1.5 w-1.5 fill-current", isOnline && "animate-pulse")} />
                      {isOnline ? t('pages.online') : t('pages.away')}
                    </Badge>
                    {service.is_provider_verified && (
                      <Badge className="bg-blue-500 hover:bg-blue-600 h-5 text-[8px] uppercase">{t('pages.verified')}</Badge>
                    )}
                  </div>
                </div>
              </div>
              
              <div className="space-y-2 pt-2">
                {user?.id !== service.user_id && (
                  <Button className="w-full rounded-full" onClick={handleMessageProvider}>
                    <MessageSquare className="h-4 w-4 mr-2" />
                    {t('pages.messageProvider')}
                  </Button>
                )}
                <Button variant="outline" className="w-full rounded-full h-10" asChild>
                  <Link to={`/profile/${service.user_id}`}>{t('pages.viewProfile')}</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <ReviewSection userId={service.user_id} userName={providerDisplayName} />
        </div>
      </div>

      <ReportDialog 
        isOpen={isReportOpen} 
        onOpenChange={setIsReportOpen} 
        targetId={service.id} 
        targetType="service" 
      />
    </div>
  );
};

export default ServiceDetailPage;