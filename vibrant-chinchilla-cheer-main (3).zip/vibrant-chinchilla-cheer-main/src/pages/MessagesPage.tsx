"use client";

import { useEffect } from "react";
import { MessageSquare, Loader2, User as UserIcon, Package2, Briefcase, Trash, Check, CheckCheck } from "lucide-react";
import { useSession } from "@/context/SessionContext";
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useMessages } from "@/context/MessagesContext";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

const MessagesPage = () => {
  const { user, loading: sessionLoading } = useSession();
  const { conversations, loadingConversations, errorMessages, fetchConversations, deleteConversation } = useMessages();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      fetchConversations();
    }
  }, [user, fetchConversations]);

  const handleDeleteConversation = (e: React.MouseEvent, conversation: any) => {
    e.preventDefault();
    e.stopPropagation();
    if (confirm("Are you sure you want to delete this conversation? This will delete all messages for both parties.")) {
      deleteConversation(conversation.otherUserId, conversation.itemId, conversation.serviceId);
    }
  };

  if (sessionLoading || loadingConversations) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed shadow-sm p-4">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
        <p className="text-muted-foreground mt-2">Loading conversations...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed shadow-sm p-4">
        <h3 className="text-2xl font-bold tracking-tight">Authentication Required</h3>
        <p className="text-sm text-muted-foreground mt-2">
          It seems there was an issue loading your session. Please try signing in.
        </p>
        <Button variant="outline" className="mt-4" asChild>
          <Link to="/login">Go to Login</Link>
        </Button>
      </div>
    );
  }

  if (errorMessages) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center rounded-lg border border-dashed shadow-sm p-4">
        <h3 className="text-2xl font-bold tracking-tight text-red-500">Error</h3>
        <p className="text-sm text-muted-foreground mt-2">
          Failed to load conversations: {errorMessages}
        </p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/")}>
          Back to Home
        </Button>
      </div>
    );
  }

  return (
    <div className="flex flex-1 flex-col items-center rounded-lg border border-dashed shadow-sm p-4 md:p-8 max-w-3xl mx-auto w-full">
      <div className="flex flex-col items-center gap-1 text-center mb-6">
        <MessageSquare className="h-12 w-12 text-muted-foreground" />
        <h3 className="text-2xl font-bold tracking-tight mt-4">Your Conversations</h3>
        <p className="text-sm text-muted-foreground max-w-md mt-2">
          Here are your active chats. Unread messages are highlighted.
        </p>
      </div>

      {conversations.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-full text-muted-foreground">
          <p>No conversations yet. Start one from a good or service detail page!</p>
        </div>
      ) : (
        <div className="w-full space-y-4">
          {conversations.map((conversation) => {
            const chatLink = conversation.itemId
              ? `/chat/${conversation.otherUserId}/${conversation.itemId}`
              : conversation.serviceId
                ? `/chat/${conversation.otherUserId}/_/${conversation.serviceId}`
                : `/chat/${conversation.otherUserId}`;

            const isLastMessageFromMe = conversation.lastMessageSenderId === user.id;

            return (
              <div key={conversation.id} className="group relative">
                <Link to={chatLink} className="block">
                  <Card className={cn(
                    "hover:bg-accent transition-colors cursor-pointer border-l-4",
                    conversation.unreadCount > 0 ? "border-l-primary bg-primary/5" : "border-l-transparent"
                  )}>
                    <CardContent className="flex items-center p-4 gap-4 pr-12">
                      <div className="relative">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={conversation.otherUserAvatar || undefined} alt={conversation.otherUserName} />
                          <AvatarFallback>
                            <UserIcon className="h-6 w-6" />
                          </AvatarFallback>
                        </Avatar>
                        {conversation.unreadCount > 0 && (
                          <span className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] text-primary-foreground font-bold">
                            {conversation.unreadCount}
                          </span>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center mb-1">
                          <p className={cn("font-semibold truncate", conversation.unreadCount > 0 && "text-primary")}>
                            {conversation.otherUserName}
                          </p>
                          <span className="text-[10px] text-muted-foreground whitespace-nowrap">
                            {new Date(conversation.lastMessageTime).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                          </span>
                        </div>
                        {(conversation.itemName || conversation.serviceName) && (
                          <div className="flex items-center gap-1 text-[10px] text-muted-foreground mb-1 uppercase tracking-wider font-bold">
                            {conversation.itemName ? <Package2 className="h-2.5 w-2.5" /> : <Briefcase className="h-2.5 w-2.5" />}
                            <span className="truncate">{conversation.itemName || conversation.serviceName}</span>
                          </div>
                        )}
                        <div className="flex items-center gap-1">
                          {isLastMessageFromMe && (
                            <span className="shrink-0">
                              {conversation.lastMessageIsRead ? (
                                <CheckCheck className="h-3 w-3 text-primary" />
                              ) : (
                                <Check className="h-3 w-3 text-muted-foreground" />
                              )}
                            </span>
                          )}
                          <p className={cn(
                            "text-xs truncate",
                            conversation.unreadCount > 0 ? "text-foreground font-medium" : "text-muted-foreground"
                          )}>
                            {conversation.lastMessageContent}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-destructive opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={(e) => handleDeleteConversation(e, conversation)}
                >
                  <Trash className="h-4 w-4" />
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default MessagesPage;