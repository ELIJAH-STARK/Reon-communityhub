"use client";
import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Loader2, ShieldAlert, CheckCircle, ExternalLink, RefreshCcw, AlertTriangle, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Link, useNavigate } from "react-router-dom";

const AdminReportsPage = () => {
  const { user, loading: sessionLoading } = useSession();
  const [reports, setReports] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  const fetchReports = async () => {
    if (!user || sessionLoading) return;
    setLoading(true);
    setError(null);
    
    try {
      // 1. Verify Admin Role for security UI
      const { data: profile, error: roleError } = await supabase
        .from('profiles')
        .select('role')
        .eq('id', user.id)
        .single();
      
      if (roleError) {
        console.error("Error fetching profile:", roleError);
        setError("Failed to verify admin privileges.");
        setLoading(false);
        return;
      }
      
      if (profile?.role !== 'admin') {
        toast.error("Access Denied: Admin privileges required.");
        navigate("/");
        return;
      }
      
      // 2. Fetch reports with joined profile info
      const { data: reportsData, error: fetchError } = await supabase
        .from('reports')
        .select(` *, reporter:profiles!reporter_id(first_name, last_name) `)
        .order('created_at', { ascending: false });
      
      if (fetchError) {
        console.error("Error fetching reports:", fetchError);
        setError(fetchError.message);
      } else {
        setReports(reportsData || []);
      }
    } catch (err: any) {
      console.error("Unexpected error:", err);
      setError(err.message || "An unexpected error occurred");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!sessionLoading) {
      fetchReports();
    }
  }, [user, sessionLoading]);

  const handleResolve = async (id: string) => {
    const { error: resolveError } = await supabase
      .from('reports')
      .update({ status: 'resolved' })
      .eq('id', id);
    
    if (resolveError) {
      toast.error("Failed to resolve: " + resolveError.message);
    } else {
      setReports(prev => prev.map(r => r.id === id ? { ...r, status: 'resolved' } : r));
      toast.success("Report marked as resolved.");
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to permanently delete this report from the database?")) {
      return;
    }

    try {
      const { error: deleteError } = await supabase
        .from('reports')
        .delete()
        .eq('id', id);
      
      if (deleteError) {
        toast.error("Database error: " + deleteError.message);
      } else {
        // Update local state immediately after successful DB deletion
        setReports(prev => prev.filter(r => r.id !== id));
        toast.success("Report permanently deleted.");
      }
    } catch (err: any) {
      toast.error("System error: " + err.message);
    }
  };

  if (sessionLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
        <p className="text-muted-foreground">Loading session...</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <Loader2 className="animate-spin h-8 w-8 text-primary" />
        <p className="text-muted-foreground">Loading moderation data...</p>
      </div>
    );
  }

  return (
    <div className="container max-w-5xl mx-auto py-8 space-y-6 px-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <ShieldAlert className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">Community Moderation</h1>
        </div>
        <Button variant="outline" size="sm" onClick={fetchReports}>
          <RefreshCcw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>
      
      {error && (
        <div className="bg-destructive/10 text-destructive p-4 rounded-lg flex items-center gap-2">
          <AlertTriangle className="h-5 w-5" />
          <span>{error}</span>
        </div>
      )}
      
      <div className="grid gap-4">
        {reports.length === 0 ? (
          <div className="text-center py-20 border rounded-lg border-dashed bg-muted/20">
            <ShieldAlert className="h-10 w-10 text-muted-foreground/30 mx-auto mb-3" />
            <p className="text-muted-foreground font-medium">No active reports. The community is safe!</p>
          </div>
        ) : (
          reports.map((report) => (
            <Card key={report.id} className={report.status === 'resolved' ? 'opacity-60 grayscale-[0.5]' : ''}>
              <CardHeader className="pb-2">
                <div className="flex justify-between items-start flex-wrap gap-4">
                  <div className="space-y-1">
                    <CardTitle className="text-lg flex items-center gap-2">
                      {report.reason}
                      <Badge variant={report.status === 'pending' ? 'destructive' : 'secondary'}>
                        {report.status.toUpperCase()}
                      </Badge>
                    </CardTitle>
                    <p className="text-sm text-muted-foreground">
                      Reported by {report.reporter ? `${report.reporter.first_name || ''} ${report.reporter.last_name || ''}` : "Neighbor"} 
                      <span className="mx-2">•</span>
                      {new Date(report.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    {report.status === 'pending' && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
                        onClick={() => handleResolve(report.id)}
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Mark Resolved
                      </Button>
                    )}
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="text-destructive hover:bg-destructive/10"
                      onClick={() => handleDelete(report.id)}
                      title="Delete report forever"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                    <Button size="sm" variant="ghost" asChild>
                      <Link 
                        to={report.target_type === 'good' 
                          ? `/goods/${report.target_id}` 
                          : report.target_type === 'service' 
                            ? `/services/${report.target_id}` 
                            : `/chat/${report.target_id}`
                        }
                      >
                        <ExternalLink className="h-4 w-4 mr-2" />
                        View Content
                      </Link>
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="bg-muted/40 p-4 rounded-lg">
                  <p className="text-xs font-bold uppercase text-muted-foreground mb-2 tracking-wider">Reporter's Details</p>
                  <p className="text-sm leading-relaxed">{report.description || "No detailed description provided."}</p>
                </div>
                <div className="mt-4 text-[10px] text-muted-foreground font-mono bg-muted/20 px-2 py-1 rounded inline-flex uppercase">
                  Target: {report.target_type} ID: {report.target_id}
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminReportsPage;