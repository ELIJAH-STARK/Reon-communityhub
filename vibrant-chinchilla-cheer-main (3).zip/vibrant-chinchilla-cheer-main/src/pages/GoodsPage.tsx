"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import { itemCategories } from "@/lib/constants";
import { useItems, UploadedItem } from "@/context/ItemsContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { calculateDistance, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Loader2, MapPin, Search, SlidersHorizontal, RefreshCcw, AlertTriangle, CheckCircle2, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import FavoriteButton from "@/components/FavoriteButton";
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
import AdBanner from "@/components/AdBanner";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";

const GoodsPage = () => {
  const { uploadedItems, loadingItems, errorItems, refreshItems, performSmartSearch } = useItems();
  const { latitude, longitude } = useGeolocation();
  const { isPremium } = useSession();
  const { t } = useTranslation();
  
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [isSmartSearch, setIsSmartSearch] = useState(false);
  const [smartResults, setSmartResults] = useState<UploadedItem[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);

  const [selectedStatus, setSelectedStatus] = useState<string>("available");
  const [sortBy, setSortBy] = useState<string>("newest");
  const [maxDistance, setMaxDistance] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  
  const categoriesRef = useRef<HTMLDivElement>(null);
  const userLocation: [number, number] | null = latitude && longitude ? [latitude, longitude] : null;

  useEffect(() => {
    const handleSmartLookup = async () => {
      if (!isSmartSearch || searchTerm.trim().length < 3) {
        setSmartResults(null);
        return;
      }
      setIsSearching(true);
      const results = await performSmartSearch(searchTerm);
      setSmartResults(results);
      setIsSearching(false);
    };

    const timer = setTimeout(handleSmartLookup, 1000);
    return () => clearTimeout(timer);
  }, [searchTerm, isSmartSearch, performSmartSearch]);

  const { topFeatured, displayList } = useMemo(() => {
    let baseItems = (isSmartSearch && smartResults ? [...smartResults] : [...uploadedItems])
      .filter(item => !item.is_held); 
    
    if (selectedCategory !== "All Categories") {
      baseItems = baseItems.filter(item => item.category === selectedCategory);
    }
    
    if (selectedStatus !== "All Statuses") {
      baseItems = baseItems.filter(item => item.status === selectedStatus);
    }
    
    if (!isSmartSearch && searchTerm.trim() !== "") {
      const lower = searchTerm.toLowerCase();
      baseItems = baseItems.filter(item => 
        item.name.toLowerCase().includes(lower) || 
        item.description?.toLowerCase().includes(lower)
      );
    }
    
    if (maxDistance !== "all" && userLocation) {
      const limit = parseInt(maxDistance) * 1000;
      baseItems = baseItems.filter(item => {
        if (!item.latitude || !item.longitude) return false;
        const dist = calculateDistance(userLocation[0], userLocation[1], item.latitude, item.longitude);
        return dist <= limit;
      });
    }

    baseItems.sort((a, b) => {
      if (sortBy === "price_asc") return (a.price || 0) - (b.price || 0);
      if (sortBy === "price_desc") return (b.price || 0) - (a.price || 0);
      if (sortBy === "closest" && userLocation && a.latitude && a.longitude && b.latitude && b.longitude) {
        const distA = calculateDistance(userLocation[0], userLocation[1], a.latitude, a.longitude);
        const distB = calculateDistance(userLocation[0], userLocation[1], b.latitude, b.longitude);
        return distA - distB;
      }
      return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
    });

    const featuredMatches = baseItems.filter(i => i.is_featured);
    const regularMatches = baseItems.filter(i => !i.is_featured);
    const top = [...featuredMatches].sort(() => 0.5 - Math.random()).slice(0, 3);
    const topIds = new Set(top.map(t => t.id));
    const injectionPool = featuredMatches.filter(i => !topIds.has(i.id));

    const result: UploadedItem[] = [];
    let injectIdx = 0;

    regularMatches.forEach((item, index) => {
      result.push(item);
      if ((index + 1) % 5 === 0 && injectionPool.length > 0) {
        result.push(injectionPool[injectIdx % injectionPool.length]);
        injectIdx++;
      }
    });

    return { topFeatured: top, displayList: result };
  }, [uploadedItems, smartResults, isSmartSearch, selectedCategory, searchTerm, selectedStatus, sortBy, maxDistance, userLocation]);

  const categories = ["All Categories", ...itemCategories];

  return (
    <div className="flex flex-1 flex-col items-center p-3 md:p-4">
      <div className="w-full max-w-5xl space-y-4 md:space-y-6">
        <div className="text-center space-y-1">
          <h3 className="text-2xl md:text-3xl font-bold tracking-tight text-primary">Explore Goods</h3>
          <p className="text-sm text-muted-foreground">Discover treasures in your neighborhood</p>
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder={isSmartSearch ? "Describe what you're looking for..." : "Search goods..."} 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)} 
                className="pl-9 h-10 rounded-xl" 
              />
              {isSearching && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-primary" />}
            </div>
            <div className="flex gap-2">
              <Button 
                variant={isSmartSearch ? "default" : "outline"} 
                onClick={() => setIsSmartSearch(!isSmartSearch)}
                className="rounded-xl h-10 px-4 flex gap-2 items-center"
              >
                <Sparkles className={cn("h-4 w-4", isSmartSearch ? "fill-current" : "")} />
                <span className="text-xs font-bold uppercase tracking-wider">{t('content.aiSearch')}</span>
              </Button>
              <Button 
                variant="outline" 
                size="icon" 
                onClick={() => setShowFilters(!showFilters)} 
                className={cn("h-10 w-10 rounded-xl transition-colors", showFilters && "bg-primary/5 border-primary text-primary")}
              >
                <SlidersHorizontal className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div ref={categoriesRef} className="w-full overflow-x-auto no-scrollbar py-1">
            <div className="flex gap-2 min-w-max px-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={cn(
                    "px-5 py-2 rounded-full text-[11px] font-bold uppercase tracking-wider transition-all whitespace-nowrap border-2",
                    selectedCategory === cat 
                      ? "bg-primary text-primary-foreground border-primary shadow-md scale-105" 
                      : "bg-background text-muted-foreground border-transparent hover:border-primary/20"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <Collapsible open={showFilters} onOpenChange={setShowFilters}>
            <CollapsibleContent className="space-y-4 bg-muted/30 p-4 rounded-2xl border border-dashed animate-in fade-in slide-in-from-top-2">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">{t('content.range')}</Label>
                  <Select value={maxDistance} onValueChange={setMaxDistance}>
                    <SelectTrigger className="h-9 rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('content.anyDistance')}</SelectItem>
                      <SelectItem value="5">{t('content.within5km')}</SelectItem>
                      <SelectItem value="10">{t('content.within10km')}</SelectItem>
                      <SelectItem value="25">{t('content.within25km')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">{t('content.status')}</Label>
                  <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                    <SelectTrigger className="h-9 rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="All Statuses">{t('content.allGoods')}</SelectItem>
                      <SelectItem value="available">{t('content.onlyAvailable')}</SelectItem>
                      <SelectItem value="reserved">{t('content.reserved')}</SelectItem>
                      <SelectItem value="sold">{t('content.sold')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">{t('content.orderBy')}</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="h-9 rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">{t('content.newestFirst')}</SelectItem>
                      <SelectItem value="price_asc">{t('content.priceLowest')}</SelectItem>
                      <SelectItem value="price_desc">{t('content.priceHighest')}</SelectItem>
                      <SelectItem value="closest" disabled={!userLocation}>{t('content.closestToMe')}</SelectItem>
                      {isSmartSearch && <SelectItem value="relevance">{t('content.aiRelevance')}</SelectItem>}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>

        <div className="w-full">
          <AdBanner position="feed" />
        </div>
        
        {loadingItems ? (
          <div className="flex flex-col items-center py-20 gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-muted-foreground text-sm font-medium">{t('content.scanningTreasures')}</p>
          </div>
        ) : errorItems ? (
          <div className="flex flex-col items-center py-20 gap-4 bg-muted/20 rounded-2xl border border-dashed">
            <AlertTriangle className="h-10 w-10 text-destructive/50" />
            <p className="text-muted-foreground font-medium">{errorItems}</p>
            <Button variant="outline" onClick={refreshItems} className="rounded-full">
              <RefreshCcw className="h-4 w-4 mr-2" />
              {t('content.reconnectHub')}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-6">
            {topFeatured.map((item) => {
              const distance = item.latitude && item.longitude && userLocation 
                ? (calculateDistance(userLocation[0], userLocation[1], item.latitude, item.longitude) / 1000).toFixed(1) 
                : null;
              const hasDiscount = item.price != null && item.discount_percentage != null && item.discount_percentage > 0;
              const discountedPrice = hasDiscount 
                ? (item.price! * (1 - item.discount_percentage! / 100)).toFixed(2) 
                : null;

              return (
                <Link to={`/goods/${item.id}`} key={`top-featured-${item.id}`} className="group">
                  <div className="bg-yellow-500/5 rounded-2xl border border-yellow-500/30 shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300 relative h-full flex flex-col group-hover:-translate-y-1 ring-1 ring-yellow-500/20">
                    <div className="absolute top-2 right-2 z-10">
                      <FavoriteButton id={item.id} type="item" className="h-8 w-8 bg-background/80 backdrop-blur-md shadow-sm" />
                    </div>
                    <div className="absolute top-2 left-2 z-10 flex gap-1">
                      <Badge className="bg-yellow-500 text-white text-[8px] font-black px-2 py-0.5 border-none shadow-lg">
                        <Sparkles className="h-2 w-2 mr-1 fill-current" />
                        {t('content.featured')}
                      </Badge>
                      {hasDiscount && (
                        <Badge className="bg-red-500 text-white text-[8px] font-bold px-2 py-0.5 border-none shadow-sm">
                          -{item.discount_percentage}%
                        </Badge>
                      )}
                    </div>
                    <div className="aspect-square w-full overflow-hidden bg-muted relative">
                      <img src={item.image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                      {item.is_seller_verified && (
                        <div className="absolute bottom-0 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-1 px-2 flex items-center justify-center gap-1.5">
                          <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                          <span className="text-[9px] font-bold text-white uppercase tracking-wider">{t('content.verifiedNeighbor')}</span>
                        </div>
                      )}
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-1.5 gap-1">
                        <span className="text-[10px] font-bold text-primary/70 uppercase tracking-widest truncate">{item.category}</span>
                        {distance && (
                          <span className="text-[10px] text-muted-foreground font-bold flex items-center shrink-0 bg-muted px-1.5 py-0.5 rounded">
                            <MapPin className="h-2.5 w-2.5 mr-1" />{distance}km
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">{item.name}</h4>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-auto pt-3 border-t border-muted gap-2">
                        <div className="flex flex-col">
                          {item.price === 0 ? (
                            <span className="text-sm font-extrabold text-green-600">{t('content.free')}</span>
                          ) : item.price === null ? (
                            <span className="text-sm font-extrabold text-primary">{t('content.offer')}</span>
                          ) : (
                            <div className="flex flex-wrap items-baseline gap-1.5">
                              <span className="text-sm font-extrabold text-primary">
                                ${discountedPrice || item.price.toFixed(2)}
                              </span>
                            </div>
                          )}
                        </div>
                        <Badge variant="outline" className="text-[9px] uppercase font-bold h-5 px-2 w-fit bg-yellow-500/10 text-yellow-700 border-yellow-200">
                          {item.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}

            {displayList.map((item, index) => {
              const distance = item.latitude && item.longitude && userLocation 
                ? (calculateDistance(userLocation[0], userLocation[1], item.latitude, item.longitude) / 1000).toFixed(1) 
                : null;
              const hasDiscount = item.price != null && item.discount_percentage != null && item.discount_percentage > 0;
              const discountedPrice = hasDiscount 
                ? (item.price! * (1 - item.discount_percentage! / 100)).toFixed(2) 
                : null;

              return (
                <React.Fragment key={`${item.id}-${index}`}>
                  <Link to={`/goods/${item.id}`} className="group">
                    <div className={cn(
                      "bg-card rounded-2xl border shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300 relative h-full flex flex-col group-hover:-translate-y-1",
                      item.is_featured && "border-yellow-500/30 bg-yellow-500/5 ring-1 ring-yellow-500/10"
                    )}>
                      <div className="absolute top-2 right-2 z-10">
                        <FavoriteButton id={item.id} type="item" className="h-8 w-8 bg-background/80 backdrop-blur-md shadow-sm" />
                      </div>
                      <div className="absolute top-2 left-2 z-10 flex gap-1">
                        {item.is_featured && (
                          <Badge className="bg-yellow-500 text-white text-[8px] font-black px-2 py-0.5 border-none shadow-sm">
                            FEATURED
                          </Badge>
                        )}
                        {hasDiscount && (
                          <Badge className="bg-red-500 hover:bg-red-600 text-[10px] font-bold px-2 py-0.5 border-none">
                            -{item.discount_percentage}%
                          </Badge>
                        )}
                      </div>
                      <div className="aspect-square w-full overflow-hidden bg-muted relative">
                        <img src={item.image_url} alt={item.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                        {item.is_seller_verified && (
                          <div className="absolute bottom-0 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-1 px-2 flex items-center justify-center gap-1.5">
                            <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                            <span className="text-[9px] font-bold text-white uppercase tracking-wider">Verified Neighbor</span>
                          </div>
                        )}
                      </div>
                      <div className="p-4 flex-1 flex flex-col">
                        <div className="flex justify-between items-start mb-1.5 gap-1">
                          <span className="text-[10px] font-bold text-primary/70 uppercase tracking-widest truncate">{item.category}</span>
                          {distance && (
                            <span className="text-[10px] text-muted-foreground font-bold flex items-center shrink-0 bg-muted px-1.5 py-0.5 rounded">
                              <MapPin className="h-2.5 w-2.5 mr-1" />{distance}km
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">{item.name}</h4>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-auto pt-3 border-t border-muted gap-2">
                          <div className="flex flex-col">
                            {item.price === 0 ? (
                              <span className="text-sm font-extrabold text-green-600">Free</span>
                            ) : item.price === null ? (
                              <span className="text-sm font-extrabold text-primary">Offer</span>
                            ) : (
                              <div className="flex flex-wrap items-baseline gap-1.5">
                                <span className="text-sm font-extrabold text-primary">
                                  ${discountedPrice || item.price.toFixed(2)}
                                </span>
                              </div>
                            )}
                          </div>
                          <Badge variant="outline" className={cn(
                            "text-[9px] uppercase font-bold h-5 px-2 w-fit",
                            item.status === "available" ? "border-green-200 text-green-700 bg-green-50" : "border-orange-200 text-orange-700 bg-orange-50"
                          )}>
                            {item.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </Link>

                  {/* Inject an ad every 8 regular items */}
                  {(index + 1) % 8 === 0 && !isPremium && (
                    <AdBanner position="grid" />
                  )}
                </React.Fragment>
              );
            })}
          </div>
        )}

        {(!loadingItems && displayList.length === 0 && topFeatured.length === 0) && (
          <div className="text-center py-32 bg-muted/20 rounded-3xl border-2 border-dashed flex flex-col items-center">
            <div className="p-4 bg-background rounded-full shadow-inner mb-4">
              <Search className="h-12 w-12 text-muted-foreground/20" />
            </div>
            <p className="text-muted-foreground font-bold">No results matching your search.</p>
            <Button variant="link" onClick={() => { setSelectedCategory("All Categories"); setSearchTerm(""); setMaxDistance("all"); setSelectedStatus("available"); setIsSmartSearch(false); }} className="text-primary mt-2">
              Clear All Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GoodsPage;