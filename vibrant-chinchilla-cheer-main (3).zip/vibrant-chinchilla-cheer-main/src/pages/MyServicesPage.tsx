"use client";

import React, { useState, useEffect } from "react";
import { PlusCircle, Loader2, MoreVertical, Edit, Trash, RefreshCcw, AlertTriangle, Sparkles, PackagePlus, EyeOff, Lock, Info, Briefcase } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { useServices } from "@/context/ServicesContext";
import { useItems } from "@/context/ItemsContext";
import { useRequests } from "@/context/RequestsContext";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import AddServiceDialog from "@/components/AddServiceDialog";
import EditServiceDialog from "@/components/EditServiceDialog";
import DeleteServiceAlertDialog from "@/components/DeleteServiceAlertDialog";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";

interface UploadedService {
  id: string;
  name: string;
  description: string;
  category: string;
  image_url: string | null;
  additional_images: string[];
  latitude: number | null;
  longitude: number | null;
  user_id: string;
  status: string;
  created_at?: string;
  price: number | null;
  discount_percentage: number | null;
  is_featured?: boolean;
  is_held?: boolean;
}

const MyServicesPage = () => {
  const { t } = useTranslation();
  const { addService, updateService, deleteService, toggleFeatured, uploadedServices, loadingServices, errorServices, refreshServices } = useServices();
  const { uploadedItems } = useItems();
  const { requests } = useRequests();
  const { user, loading: sessionLoading, isPremium } = useSession();

  const [extraSlots, setExtraSlots] = useState(0);
  const [activeSlotExpiry, setActiveSlotExpiry] = useState<Date | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [editingService, setEditingService] = useState<UploadedService | null>(null);
  const [deletingServiceId, setDeletingServiceId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const fetchSlotData = async () => {
      if (user) {
        const { data: profile } = await supabase.from('profiles').select('extra_slots').eq('id', user.id).maybeSingle();
        if (profile) setExtraSlots(profile.extra_slots || 0);

        const { data: transaction } = await supabase
          .from('slot_transactions')
          .select('expiry_date')
          .eq('user_id', user.id)
          .gt('expiry_date', new Date().toISOString())
          .order('expiry_date', { ascending: false })
          .limit(1)
          .maybeSingle();
        if (transaction) setActiveSlotExpiry(new Date(transaction.expiry_date));
      }
    };
    fetchSlotData();
  }, [user]);

  const handleEditClick = (service: UploadedService) => {
    setEditingService(service);
    setIsEditDialogOpen(true);
  };

  const handleDeleteClick = (serviceId: string) => {
    setDeletingServiceId(serviceId);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingServiceId) return;
    setIsDeleting(true);
    try {
      await deleteService(deletingServiceId);
      setDeletingServiceId(null);
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Failed to delete service:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleStatusToggle = async (serviceId: string, currentStatus: string) => {
    const newStatus = currentStatus === "available" ? "unavailable" : "available";
    try {
      await updateService(serviceId, { status: newStatus });
    } catch (error) {
      console.error("Failed to update service status:", error);
    }
  };

  const userServices = uploadedServices.filter(service => service.user_id === user?.id);
  const userItems = uploadedItems.filter(i => i.user_id === user?.id);
  const userRequests = requests.filter(r => r.user_id === user?.id);

  const activeServices = userServices.filter(s => !s.is_held);
  const heldServices = userServices.filter(s => s.is_held);

  // Corrected: Count total across all types
  const userListingsCount = userServices.length + userItems.length + userRequests.length;
  const currentLimit = 10 + extraSlots;
  const usagePercentage = isPremium ? 0 : Math.min(100, (userListingsCount / currentLimit) * 100);

  return (
    <div className="flex flex-1 flex-col items-center p-3 md:p-4">
      <div className="w-full max-w-2xl space-y-6">
        <div className="text-center space-y-1">
          <h3 className="text-2xl font-bold tracking-tight">{t('pages.myServices')}</h3>
          <p className="text-sm text-muted-foreground">{t('pages.manageServices')}</p>
        </div>

        <Card className="bg-muted/40 p-4 rounded-2xl border border-dashed space-y-3">
          <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider">
            <div className="flex items-center gap-2">
              <PackagePlus className="h-3.5 w-3.5 text-primary" />
              <span>{t('pages.capacityStatus')}</span>
            </div>
            <span>{userListingsCount} / {isPremium ? '∞' : currentLimit} {t('pages.slots')}</span>
          </div>
          {!isPremium && (
            <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full transition-all duration-500",
                  usagePercentage > 90 ? "bg-destructive" : usagePercentage > 70 ? "bg-orange-500" : "bg-primary"
                )}
                style={{ width: `${usagePercentage}%` }}
              />
            </div>
          )}
          {activeSlotExpiry && (
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-2">
              <Info className="h-3 w-3" />
              <span>{t('pages.activeSlotsExpire')}: {activeSlotExpiry.toLocaleDateString()}</span>
            </div>
          )}
          {heldServices.length > 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 p-2 rounded-lg flex items-center gap-2 mt-2">
              <EyeOff className="h-4 w-4 text-yellow-600" />
              <span className="text-xs font-bold text-yellow-700">{heldServices.length} {t('pages.servicesHeld')}</span>
            </div>
          )}
        </Card>

        <div className="flex justify-center">
          <Button onClick={() => setIsAddDialogOpen(true)} disabled={sessionLoading}>
            <PlusCircle className="h-4 w-4 mr-2" />
            {t('buttons.addService')}
          </Button>
        </div>

        {loadingServices ? (
          <div className="flex items-center justify-center py-10 gap-2 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>{t('pages.loading')}</span>
          </div>
        ) : errorServices ? (
          <div className="flex flex-col items-center py-10 gap-4 bg-muted/20 rounded-xl border border-dashed">
            <AlertTriangle className="h-8 w-8 text-destructive/50" />
            <p className="text-sm text-muted-foreground text-center px-4">{errorServices}</p>
            <Button variant="outline" size="sm" onClick={refreshServices}>
              <RefreshCcw className="h-4 w-4 mr-2" />
              {t('pages.retryConnection')}
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {activeServices.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">{t('pages.active')} ({activeServices.length})</h4>
                {activeServices.map((service) => (
                  <div key={service.id} className="flex items-center gap-3 p-2 border rounded-xl bg-card shadow-sm transition-all hover:border-primary/20">
                    <div className="relative shrink-0">
                      {service.image_url ? (
                        <img src={service.image_url} alt={service.name} className="w-16 h-16 md:w-20 md:h-20 object-cover rounded-lg" />
                      ) : (
                        <div className="w-16 h-16 md:w-20 md:h-20 bg-muted rounded-lg flex items-center justify-center">
                          <div className="bg-gray-200 border-2 border-dashed rounded-xl w-16 h-16" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm truncate">{service.name}</p>
                        {service.is_featured && <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20 text-[8px] h-4">{t('pages.featured')}</Badge>}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground">{service.category}</span>
                        <Badge variant="outline" className="text-[8px] h-3.5 px-1 py-0">{service.status}</Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-bold text-primary">
                          {service.price === 0 ? t('common.free') : service.price === null ? t('pages.negotiable') : `$${service.price.toFixed(2)}`}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-2">
                      <div className="flex items-center gap-2">
                        <Label htmlFor={`status-toggle-${service.id}`} className="text-xs text-muted-foreground">
                          {service.status === "available" ? t('pages.available') : t('pages.unavailable')}
                        </Label>
                        <Switch
                          id={`status-toggle-${service.id}`}
                          checked={service.status === "available"}
                          onCheckedChange={() => handleStatusToggle(service.id, service.status)}
                        />
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEditClick(service)}>
                            <Edit className="h-4 w-4 mr-2" />
                            {t('common.edit')}
                          </DropdownMenuItem>
                          {isPremium && (
                            <DropdownMenuItem onClick={() => toggleFeatured(service.id, !service.is_featured)} className="text-yellow-600 font-bold">
                              <Sparkles className="h-3 w-3 mr-2 fill-current" />
                              {service.is_featured ? t('pages.removeFeature') : t('pages.featureService')}
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDeleteClick(service.id)} className="text-destructive">
                            <Trash className="h-4 w-4 mr-2" />
                            {t('common.delete')}
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {heldServices.length > 0 && (
              <div className="space-y-3 opacity-80">
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Lock className="h-3 w-3" />
                  {t('pages.held')} / {t('pages.invisible')} ({heldServices.length})
                </h4>
                {heldServices.map((service) => (
                  <div key={service.id} className="flex items-center gap-3 p-2 border rounded-xl bg-muted/30 shadow-sm relative overflow-hidden">
                    <div className="absolute inset-0 bg-black/5 backdrop-blur-[1px] pointer-events-none rounded-xl" />
                    <div className="relative z-10 flex w-full items-center gap-3">
                      <div className="relative shrink-0">
                        {service.image_url ? (
                          <img src={service.image_url} alt={service.name} className="w-16 h-16 md:w-20 md:h-20 object-cover rounded-lg grayscale opacity-50" />
                        ) : (
                          <div className="w-16 h-16 md:w-20 md:h-20 bg-muted rounded-lg flex items-center justify-center grayscale opacity-50">
                            <Briefcase className="h-6 w-6 text-muted-foreground" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-sm truncate text-muted-foreground">{service.name}</p>
                          <Badge className="bg-black/80 text-white text-[8px] border-none">HELD</Badge>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] uppercase font-bold text-muted-foreground">{service.category}</span>
                          <span className="text-[10px] text-muted-foreground italic">{t('pages.invisibleToPublic')}</span>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 relative z-10">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEditClick(service)}>{t('pages.editDetails')}</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDeleteClick(service.id)} className="text-destructive">{t('common.delete')}</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeServices.length === 0 && heldServices.length === 0 && (
              <p className="text-muted-foreground text-center py-10 border rounded-xl border-dashed">
                {t('pages.noServicesYet')}
              </p>
            )}
          </div>
        )}
      </div>

      <AddServiceDialog
        isOpen={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onAddSuccess={() => {}}
        addService={addService}
      />
      <EditServiceDialog
        isOpen={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onEditSuccess={() => {}}
        updateService={updateService}
        editingService={editingService}
      />
      <DeleteServiceAlertDialog
        isOpen={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onDeleteConfirm={handleDeleteConfirm}
        isDeleting={isDeleting}
      />
    </div>
  );
};

export default MyServicesPage;