"use client";

import React, { useState, useEffect } from "react";
import { PlusCircle, Loader2, MoreVertical, Percent, RefreshCcw, AlertTriangle, Sparkles, PackagePlus, Info, EyeOff, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useRequests } from "@/context/RequestsContext";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import AddGoodDialog from "@/components/AddGoodDialog";
import EditGoodDialog from "@/components/EditGoodDialog";
import DeleteGoodAlertDialog from "@/components/DeleteGoodAlertDialog";
import BulkDiscountDialog from "@/components/BulkDiscountDialog";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

interface UploadedItem {
  id: string;
  name: string;
  description: string;
  category: string;
  image_url: string;
  additional_images: string[];
  latitude: number | null;
  longitude: number | null;
  user_id: string;
  status: string;
  price: number | null;
  discount_percentage: number | null;
  created_at?: string;
  is_featured?: boolean;
  is_held?: boolean;
}

const MyGoodsPage = () => {
  const { t } = useTranslation();
  const { addItem, updateItem, deleteItem, applyBulkDiscount, toggleFeatured, uploadedItems, loadingItems, errorItems, refreshItems } = useItems();
  const { uploadedServices } = useServices();
  const { requests } = useRequests();
  const { user, loading: sessionLoading, isPremium } = useSession();

  const [extraSlots, setExtraSlots] = useState(0);
  const [activeSlotExpiry, setActiveSlotExpiry] = useState<Date | null>(null);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isBulkDiscountDialogOpen, setIsBulkDiscountDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<UploadedItem | null>(null);
  const [deletingItemId, setDeletingItemId] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const fetchSlotData = async () => {
      if (user) {
        const { data: profile } = await supabase.from('profiles').select('extra_slots').eq('id', user.id).maybeSingle();
        if (profile) setExtraSlots(profile.extra_slots || 0);

        const { data: transaction } = await supabase
          .from('slot_transactions')
          .select('expiry_date')
          .eq('user_id', user.id)
          .gt('expiry_date', new Date().toISOString())
          .order('expiry_date', { ascending: false })
          .limit(1)
          .maybeSingle();
        if (transaction) setActiveSlotExpiry(new Date(transaction.expiry_date));
      }
    };
    fetchSlotData();
  }, [user]);

  const handleEditClick = (item: UploadedItem) => {
    setEditingItem(item);
    setIsEditDialogOpen(true);
  };

  const handleDeleteClick = (itemId: string) => {
    setDeletingItemId(itemId);
    setIsDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingItemId) return;
    setIsDeleting(true);
    try {
      await deleteItem(deletingItemId);
      setDeletingItemId(null);
      setIsDeleteDialogOpen(false);
    } catch (error) {
      console.error("Failed to delete item:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const userItems = uploadedItems.filter(item => item.user_id === user?.id);
  const userServices = uploadedServices.filter(s => s.user_id === user?.id);
  const userRequests = requests.filter(r => r.user_id === user?.id);

  const activeItems = userItems.filter(i => !i.is_held);
  const heldItems = userItems.filter(i => i.is_held);

  // Corrected: Total count includes all types of listings owned by user
  const userListingsCount = userItems.length + userServices.length + userRequests.length;
  const currentLimit = 10 + extraSlots;
  const usagePercentage = isPremium ? 0 : Math.min(100, (userListingsCount / currentLimit) * 100);

  return (
    <div className="flex flex-1 flex-col items-center p-3 md:p-4">
      <div className="w-full max-w-2xl space-y-6">
        <div className="text-center space-y-1">
          <h3 className="text-2xl font-bold tracking-tight">{t('pages.myGoods')}</h3>
          <p className="text-sm text-muted-foreground">{t('pages.manageItems')}</p>
        </div>

        <Card className="bg-muted/40 p-4 rounded-2xl border border-dashed space-y-3">
          <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider">
            <div className="flex items-center gap-2">
              <PackagePlus className="h-3.5 w-3.5 text-primary" />
              <span>{t('pages.capacityStatus')}</span>
            </div>
            <span>{userListingsCount} / {isPremium ? '∞' : currentLimit} {t('pages.slots')}</span>
          </div>
          {!isPremium && (
            <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full transition-all duration-500",
                  usagePercentage > 90 ? "bg-destructive" : usagePercentage > 70 ? "bg-orange-500" : "bg-primary"
                )}
                style={{ width: `${usagePercentage}%` }}
              />
            </div>
          )}
          {activeSlotExpiry && (
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-2">
              <Info className="h-3 w-3" />
              <span>{t('pages.activeSlotsExpire')} {activeSlotExpiry.toLocaleDateString()}</span>
            </div>
          )}
          {heldItems.length > 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 p-2 rounded-lg flex items-center gap-2 mt-2">
              <EyeOff className="h-4 w-4 text-yellow-600" />
              <span className="text-xs font-bold text-yellow-700">{heldItems.length} {t('pages.itemsHeld')}</span>
            </div>
          )}
        </Card>

        <div className="flex gap-2 justify-center">
          <Button size="sm" onClick={() => setIsAddDialogOpen(true)} disabled={sessionLoading}>
            <PlusCircle className="h-4 w-4 mr-2" />
            {t('pages.addItem')}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsBulkDiscountDialogOpen(true)}
            disabled={sessionLoading || activeItems.length === 0}
          >
            <Percent className="h-4 w-4 mr-2" />
            {t('pages.bulkDiscount')}
          </Button>
        </div>

        {loadingItems ? (
          <div className="flex items-center justify-center py-10 gap-2 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>{t('pages.loading')}</span>
          </div>
        ) : errorItems ? (
          <div className="flex flex-col items-center py-10 gap-4 bg-muted/20 rounded-xl border border-dashed">
            <AlertTriangle className="h-8 w-8 text-destructive/50" />
            <p className="text-sm text-muted-foreground text-center px-4">{errorItems}</p>
            <Button variant="outline" size="sm" onClick={refreshItems}>
              <RefreshCcw className="h-4 w-4 mr-2" />
              {t('pages.retryConnection')}
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {activeItems.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">{t('pages.active')} ({activeItems.length})</h4>
                {activeItems.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 p-2 border rounded-xl bg-card shadow-sm transition-all hover:border-primary/20">
                    <img src={item.image_url} alt={item.name} className="w-16 h-16 md:w-20 md:h-20 object-cover rounded-lg" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm truncate">{item.name}</p>
                        {item.is_featured && <Badge className="bg-yellow-500/10 text-yellow-600 border-yellow-500/20 text-[8px] h-4">{t('pages.featured')}</Badge>}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground">{item.category}</span>
                        <Badge variant="outline" className="text-[8px] h-3.5 px-1 py-0">{item.status}</Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs font-bold text-primary">
                          {item.price === 0 ? t('common.free') : item.price === null ? t('pages.offer') : `$${item.price.toFixed(2)}`}
                        </span>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleEditClick(item)}>{t('common.edit')}</DropdownMenuItem>
                        {isPremium && (
                          <DropdownMenuItem onClick={() => toggleFeatured(item.id, !item.is_featured)} className="text-yellow-600 font-bold">
                            <Sparkles className="h-3 w-3 mr-2 fill-current" />
                            {item.is_featured ? t('pages.removeFeature') : t('pages.featureItem')}
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleDeleteClick(item.id)} className="text-destructive">{t('common.delete')}</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}

            {heldItems.length > 0 && (
              <div className="space-y-3 opacity-80">
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Lock className="h-3 w-3" />
                  {t('pages.held')} / {t('pages.invisible')} ({heldItems.length})
                </h4>
                {heldItems.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 p-2 border rounded-xl bg-muted/30 shadow-sm relative overflow-hidden">
                    <div className="absolute inset-0 bg-black/5 backdrop-blur-[1px] pointer-events-none rounded-xl" />
                    <div className="relative z-10 flex w-full items-center gap-3">
                      <img src={item.image_url} alt={item.name} className="w-16 h-16 md:w-20 md:h-20 object-cover rounded-lg grayscale opacity-50" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-sm truncate text-muted-foreground">{item.name}</p>
                          <Badge className="bg-black/80 text-white text-[8px] border-none">HELD</Badge>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] uppercase font-bold text-muted-foreground">{item.category}</span>
                          <span className="text-[10px] text-muted-foreground italic">{t('pages.invisibleToPublic')}</span>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 relative z-10">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleEditClick(item)}>{t('pages.editDetails')}</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDeleteClick(item.id)} className="text-destructive">{t('common.delete')}</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeItems.length === 0 && heldItems.length === 0 && (
              <p className="text-muted-foreground text-center py-10 border rounded-xl border-dashed">
                {t('content.noItems')}
              </p>
            )} 
          </div>
        )}
      </div>

      <AddGoodDialog
        isOpen={isAddDialogOpen}
        onOpenChange={setIsAddDialogOpen}
        onAddSuccess={() => {}}
        addItem={addItem}
      />
      <EditGoodDialog
        isOpen={isEditDialogOpen}
        onOpenChange={setIsEditDialogOpen}
        onEditSuccess={() => {}}
        updateItem={updateItem}
        editingItem={editingItem}
      />
      <DeleteGoodAlertDialog
        isOpen={isDeleteDialogOpen}
        onOpenChange={setIsDeleteDialogOpen}
        onDeleteConfirm={handleDeleteConfirm}
        isDeleting={isDeleting}
      />
      <BulkDiscountDialog
        isOpen={isBulkDiscountDialogOpen}
        onOpenChange={setIsBulkDiscountDialogOpen}
        userItems={activeItems}
        applyBulkDiscount={applyBulkDiscount}
      />
    </div>
  );
};

export default MyGoodsPage;