"use client";

import React from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "@/hooks/useTranslation";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Users, Heart, Zap, Globe } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const AboutUsPage = () => {
  const { t } = useTranslation();
  return (
    <div className="container max-w-4xl mx-auto py-8 px-4 space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild className="rounded-full">
          <Link to="/settings">
            <ArrowLeft className="h-4 w-4" />
          </Link> 
        </Button>
        <h1 className="text-3xl font-bold">{t('requests.aboutHub')}</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="border-none bg-primary/5 shadow-none">
          <CardContent className="p-6 space-y-4">
            <div className="h-12 w-12 bg-primary/10 rounded-2xl flex items-center justify-center">
              <Users className="h-6 w-6 text-primary" />
            </div>
            <h2 className="text-xl font-bold">{t('requests.ourMission')}</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {t('requests.missionDescription')}
            </p>
          </CardContent>
        </Card>

        <Card className="border-none bg-orange-500/5 shadow-none">
          <CardContent className="p-6 space-y-4">
            <div className="h-12 w-12 bg-orange-500/10 rounded-2xl flex items-center justify-center">
              <Globe className="h-6 w-6 text-orange-600" />
            </div>
            <h2 className="text-xl font-bold">{t('requests.localFirst')}</h2>
            <p className="text-sm text-muted-foreground leading-relaxed">
              {t('requests.localFirstDescription')}
            </p>
          </CardContent>
        </Card>
      </div>

      <section className="text-center py-12 space-y-4 border-t">
        <Heart className="h-10 w-10 text-primary mx-auto animate-pulse" />
        <h2 className="text-2xl font-bold tracking-tight">{t('requests.builtForCommunity')}</h2>
        <p className="text-muted-foreground max-w-lg mx-auto">
          {t('requests.builtForCommunityDescription')}
        </p>
        <div className="pt-4 flex justify-center gap-4">
          <Button variant="link" asChild><Link to="settings/privacy-policy">{t('pages.privacyPolicyPage')}</Link></Button>
          <Button variant="link" asChild><Link to="settings/terms-of-service">{t('pages.termsOfServicePage')}</Link></Button>
        </div>
      </section>
    </div>
  );
};

export default AboutUsPage;