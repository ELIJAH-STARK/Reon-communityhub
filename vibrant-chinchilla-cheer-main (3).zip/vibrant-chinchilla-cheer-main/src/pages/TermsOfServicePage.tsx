"use client";

import React from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "@/hooks/useTranslation";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Scale, AlertTriangle, UserCheck, MessageSquare } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const TermsOfServicePage = () => {
  const { t } = useTranslation();
  return (
    <div className="container max-w-4xl mx-auto py-8 px-4 space-y-8">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" asChild className="rounded-full">
          <Link to="/settings">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-3xl font-bold">{t('pages.termsOfServicePage')}</h1>
        
               <p>View full terms and privacy policy on  </p> <br>
                <a href="https://elijah-stark.github.io/Reon-communityhub/">Full documentation</a>
      </div>
      <Card className="border-none shadow-sm bg-muted/30">
        <CardContent className="p-6 space-y-6 text-sm md:text-base leading-relaxed text-muted-foreground">
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <UserCheck className="h-5 w-5 text-primary" />
              
              <h2 className="text-xl font-bold">{t('pages.userEligibility')}</h2>
            </div>
            <p>
              {t('pages.userEligibilityDesc')}
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <Scale className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">{t('pages.prohibitedConduct')}</h2>
            </div>
            <p>
              {t('pages.prohibitedConductDesc')}
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <MessageSquare className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">{t('pages.transactions')}</h2>
            </div>
            <p>
              {t('pages.transactionsDesc')}
            </p>
          </section>

          <section className="space-y-3">
            <div className="flex items-center gap-2 text-foreground">
              <AlertTriangle className="h-5 w-5 text-primary" />
              <h2 className="text-xl font-bold">{t('pages.limitationOfLiability')}</h2>
            </div>
            <p>
              {t('pages.limitationOfLiabilityDesc')}
            </p>
          </section>

          <div className="pt-6 border-t">
            <p className="text-xs italic">{t('pages.termsAgreement')}</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default TermsOfServicePage;
