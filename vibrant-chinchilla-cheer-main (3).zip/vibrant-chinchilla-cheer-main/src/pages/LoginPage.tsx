/* LoginPage Component
This component provides the authentication UI for users to sign in or sign up.
It uses Supabase's Auth component and handles redirection after successful authentication.
*/
"use client";
import React, { useEffect } from "react";
import { Auth } from "@supabase/auth-ui-react";
import { ThemeSupa } from "@supabase/auth-ui-shared";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";
import { useNavigate } from "react-router-dom";

const LoginPage = () => {
  const { user, isGuest } = useSession();
  const navigate = useNavigate();
  const { t } = useTranslation();

  // Automatically redirect to home page if a real user session is detected
  useEffect(() => {
    if (user && !isGuest) {
      navigate("/", { replace: true });
    }
  }, [user, isGuest, navigate]);

  return (
    <div className="flex flex-1 flex-col items-center justify-center p-4 min-h-screen bg-background">
      <div className="w-full max-w-md p-8 space-y-6 bg-card rounded-lg shadow-lg border">
        <div className="space-y-2 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground">
            {isGuest ? t('auth.createAccount') : t('auth.welcomeBack')}
          </h2>
          <p className="text-sm text-muted-foreground">
            {isGuest ? t('auth.registerToSave') : t('auth.signInToAccess')}
          </p>
        </div>
        <div className="mt-4">
          <Auth
            supabaseClient={supabase}
            providers={[]} // Add providers like 'google' here if configured in Supabase
            appearance={{
              theme: ThemeSupa,
              variables: {
                default: {
                  colors: {
                    brand: 'hsl(var(--primary))',
                    brandAccent: 'hsl(var(--primary))',
                    inputText: 'hsl(var(--foreground))',
                    inputLabelText: 'hsl(var(--foreground))',
                    inputPlaceholder: 'hsl(var(--muted-foreground))',
                  },
                  radii: {
                    borderRadiusButton: '0.5rem',
                    borderRadiusInput: '0.5rem',
                  }
                },
              },
              className: {
                anchor: 'text-primary hover:text-primary/80',
                button: 'bg-primary hover:bg-primary/90 text-primary-foreground',
                container: 'bg-background rounded-lg',
                divider: 'bg-border',
                input: 'bg-background text-foreground border border-input focus:border-primary focus:ring-1 focus:ring-primary',
                label: 'text-foreground',
                loader: 'text-primary',
                message: 'text-foreground',
                radio: 'text-primary',
                checkbox: 'text-primary',
              },
            }}
            theme="light"
            redirectTo={window.location.origin}
          />
        </div>
        <div className="text-center">
          <button
            onClick={() => navigate("/")}
            className="text-xs text-muted-foreground hover:text-primary transition-colors underline"
          >
            {t('auth.continueAsGuest')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;