"use client";

import React, { useState, useMemo } from "react";
import { useGeolocation } from "@/hooks/use-geolocation";
import { Button } from "@/components/ui/button";
import { Loader2, MapPin, AlertCircle, RefreshCcw } from "lucide-react";
import { toast } from "sonner";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useRequests } from "@/context/RequestsContext"; // New import
import MapDisplay from "@/components/MapDisplay";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { itemCategories, serviceCategories } from "@/lib/constants";
import { useSession } from "@/context/SessionContext";

type DisplayType = "Goods" | "Services" | "Requests" | "All"; // Updated type

const MapPage = () => {
  const { loading: sessionLoading } = useSession();
  const { latitude, longitude, error, loading: geoLoading, permissionStatus } = useGeolocation();
  const { uploadedItems, loadingItems, errorItems, refreshItems } = useItems();
  const { uploadedServices, loadingServices, errorServices, refreshServices } = useServices();
  const { requests, loading: loadingRequests, error: errorRequests, refreshRequests } = useRequests(); // New hook
  
  const [displayType, setDisplayType] = useState<DisplayType>("All");
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");

  const handleRequestLocation = () => {
    if (permissionStatus === "denied") {
      toast.error("Location access is denied. Please enable it in your browser settings.");
    } else {
      navigator.geolocation.getCurrentPosition(
        () => toast.success("Location acquired!"),
        () => toast.error("Could not determine location."),
        { enableHighAccuracy: true }
      );
    }
  };

  const handleRetryAll = () => {
    refreshItems();
    refreshServices();
    refreshRequests(); // New refresh
    toast.info("Retrying database connections...");
  };

  const userLocation = useMemo<[number, number] | null>(() => {
    if (typeof latitude === 'number' && typeof longitude === 'number') {
      return [latitude, longitude];
    }
    return null;
  }, [latitude, longitude]);

  const filteredGoods = useMemo(() => {
    if (displayType === "Services" || displayType === "Requests") return [];
    if (displayType === "All" || displayType === "Goods") {
      return uploadedItems.filter(item => 
        (selectedCategory === "All Categories" || item.category === selectedCategory) &&
        typeof item.latitude === 'number' && typeof item.longitude === 'number'
      );
    }
    return [];
  }, [uploadedItems, selectedCategory, displayType]);

  const filteredServices = useMemo(() => {
    if (displayType === "Goods" || displayType === "Requests") return [];
    if (displayType === "All" || displayType === "Services") {
      return uploadedServices.filter(service => 
        (selectedCategory === "All Categories" || service.category === selectedCategory) &&
        typeof service.latitude === 'number' && typeof service.longitude === 'number'
      );
    }
    return [];
  }, [uploadedServices, selectedCategory, displayType]);

  const filteredRequests = useMemo(() => {
    if (displayType === "Goods" || displayType === "Services") return [];
    if (displayType === "All" || displayType === "Requests") {
      return requests.filter(request => 
        (selectedCategory === "All Categories" || request.category === selectedCategory) &&
        typeof request.latitude === 'number' && typeof request.longitude === 'number'
      );
    }
    return [];
  }, [requests, selectedCategory, displayType]);

  const dataLoading = loadingItems || loadingServices || loadingRequests || sessionLoading;
  const dataError = errorItems || errorServices || errorRequests;

  return (
    <div className="flex flex-1 flex-col items-center p-4">
      <div className="w-full max-w-4xl flex flex-col items-center gap-4 text-center">
        <div className="space-y-1">
          <h3 className="text-2xl font-bold tracking-tight text-primary">Interactive Community Map</h3>
          <p className="text-sm text-muted-foreground">See what's happening in your neighborhood</p>
        </div>
        
        {dataLoading && !userLocation && (
          <div className="flex flex-col items-center gap-4 py-20">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <span className="text-muted-foreground">Loading community data...</span>
          </div>
        )}
        
        {!dataLoading && dataError && !userLocation && (
          <div className="bg-destructive/10 text-destructive p-6 rounded-lg flex flex-col items-center gap-4 border border-destructive/20 w-full">
            <AlertCircle className="h-8 w-8" />
            <p className="font-medium">Data connection error: {dataError}</p>
            <Button onClick={handleRetryAll} variant="outline" size="sm">
              <RefreshCcw className="h-4 w-4 mr-2" /> Retry Connection
            </Button>
          </div>
        )}
        
        {error && !userLocation && !geoLoading && (
          <div className="bg-destructive/10 text-destructive p-6 rounded-lg flex flex-col items-center gap-4 border border-destructive/20 w-full">
            <AlertCircle className="h-8 w-8" />
            <p className="font-medium">Location needed to center the map: {error}</p>
            <Button onClick={handleRequestLocation} variant="outline" size="sm">
              <MapPin className="h-4 w-4 mr-2" /> Allow Access
            </Button>
          </div>
        )}
        
        {userLocation && (
          <div className="w-full space-y-6 animate-in fade-in duration-500">
            <div className="flex flex-wrap justify-center gap-4 bg-card p-4 rounded-lg border shadow-sm">
              <div className="flex flex-col items-start gap-1">
                <span className="text-xs font-semibold text-muted-foreground uppercase ml-1">Show</span>
                <Select value={displayType} onValueChange={(v: DisplayType) => setDisplayType(v)}>
                  <SelectTrigger className="w-[160px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All">All Items</SelectItem>
                    <SelectItem value="Goods">Only Goods</SelectItem>
                    <SelectItem value="Services">Only Services</SelectItem>
                    <SelectItem value="Requests">Only Requests</SelectItem> {/* New option */}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex flex-col items-start gap-1">
                <span className="text-xs font-semibold text-muted-foreground uppercase ml-1">Category</span>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="All Categories">All Categories</SelectItem>
                    {[...new Set([...itemCategories, ...serviceCategories])].sort().map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              {dataError && (
                <div className="flex items-center ml-auto">
                  <Button variant="ghost" size="sm" onClick={handleRetryAll} className="text-destructive h-10">
                    <RefreshCcw className="h-4 w-4 mr-2" /> Retry Sync
                  </Button>
                </div>
              )}
            </div>
            
            <div className="w-full h-[500px] rounded-lg overflow-hidden border">
              <MapDisplay 
                center={userLocation} 
                items={filteredGoods} 
                services={filteredServices} 
                requests={filteredRequests} // New prop
                zoom={13} 
              />
            </div>
            
            <div className="flex items-center justify-center gap-2 text-[10px] text-muted-foreground uppercase tracking-wider bg-muted/50 py-1 px-3 rounded-full">
              <MapPin className="w-3 h-3" /> 
              Current position: {userLocation[0].toFixed(5)}, {userLocation[1].toFixed(5)}
            </div>
          </div>
        )}
        
        {!dataLoading && !geoLoading && !error && !userLocation && (
          <div className="py-20 flex flex-col items-center gap-4">
            <div className="bg-muted p-4 rounded-full">
              <MapPin className="h-10 w-10 text-muted-foreground/50" />
            </div>
            <p className="text-muted-foreground max-w-xs">Map functionality requires location access to find resources near you.</p>
            <Button onClick={handleRequestLocation}>Enable Location Access</Button>
          </div>
        )}
        
        {geoLoading && !userLocation && (
          <div className="flex flex-col items-center gap-2 py-10">
            <Loader2 className="h-6 w-6 animate-spin text-primary" />
            <p className="text-xs text-muted-foreground">Finding your coordinates...</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MapPage;