"use client";
import React, { useState, useEffect, useRef } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useSession } from "@/context/SessionContext";
import { useMessages } from "@/context/MessagesContext";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, Send, ArrowLeft, User as UserIcon, Package2, Briefcase, Check, CheckCheck, MapPin, X, Flag } from "lucide-react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import MapDisplay from "@/components/MapDisplay";
import ReportDialog from "@/components/ReportDialog";
import { useHaptics } from "@/hooks/use-haptics";
import { ImpactStyle } from "@capacitor/haptics";

interface Profile {
  id: string;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  avatar_url: string | null;
  location_sharing_enabled?: boolean;
}

const ChatPage = () => {
  const { user, loading: sessionLoading } = useSession();
  const { messages, loadingMessages, markAsRead, sendMessage, fetchMessagesForConversation } = useMessages();
  const { uploadedItems } = useItems();
  const { uploadedServices } = useServices();
  const { impact } = useHaptics();
  const navigate = useNavigate();
  const { otherUserId, itemId, serviceId } = useParams<{ otherUserId: string; itemId?: string; serviceId?: string }>();
  const [messageContent, setMessageContent] = useState("");
  const [otherUserProfile, setOtherUserProfile] = useState<Profile | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [otherUserLocation, setOtherUserLocation] = useState<[number, number] | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [isReportOpen, setIsReportOpen] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const relatedItem = itemId ? uploadedItems.find(item => item.id === itemId) : null;
  const relatedService = serviceId ? uploadedServices.find(service => service.id === serviceId) : null;

  useEffect(() => {
    if (otherUserId && user && !sessionLoading) {
      fetchMessagesForConversation(otherUserId, itemId, serviceId);
      markAsRead(otherUserId, itemId, serviceId);
      const fetchOtherUserProfile = async () => {
        const { data, error } = await supabase
          .from('profiles')
          .select('id, username, first_name, last_name, avatar_url, location_sharing_enabled')
          .eq('id', otherUserId)
          .single();
        if (error && error.code !== 'PGRST116') {
          console.error("Error fetching other user profile:", error);
        } else if (data) {
          setOtherUserProfile(data);
        }
      };
      fetchOtherUserProfile();
    }
  }, [otherUserId, itemId, serviceId, user, sessionLoading, fetchMessagesForConversation, markAsRead]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!messageContent.trim() || !user || !otherUserId) return;
    setIsSending(true);
    
    // Provide tactile feedback for the send action
    impact(ImpactStyle.Medium);

    try {
      await sendMessage(otherUserId, messageContent.trim(), itemId, serviceId);
      setMessageContent("");
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setIsSending(false);
    }
  };

  const handleShowLocation = async () => {
    if (!user || !otherUserId) return;
    setLocationLoading(true);
    try {
      const { data: currentUserProfile } = await supabase.from('profiles').select('location_sharing_enabled').eq('id', user.id).single();
      if (!currentUserProfile?.location_sharing_enabled) {
        toast.error("Enable location sharing in settings first");
        return;
      }
      
      const position = await new Promise<GeolocationPosition>((res, rej) => navigator.geolocation.getCurrentPosition(res, rej));
      setUserLocation([position.coords.latitude, position.coords.longitude]);
      
      const { data: otherUserLocationData } = await supabase.from('profiles').select('latitude, longitude').eq('id', otherUserId).single();
      if (otherUserLocationData?.latitude) {
        setOtherUserLocation([otherUserLocationData.latitude, otherUserLocationData.longitude]);
      } else {
        toast.info("Other user's location unavailable");
      }
      setShowMap(true);
    } catch (error) {
      toast.error("Location access denied.");
    } finally {
      setLocationLoading(false);
    }
  };

  if (sessionLoading || !user || loadingMessages) {
    return (
      <div className="flex flex-1 flex-col items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Consistent name prioritization logic
  const otherUserName = otherUserProfile?.username || 
                       [otherUserProfile?.first_name, otherUserProfile?.last_name].filter(Boolean).join(' ') || 
                       "Neighbor";

  return (
    <div className="flex flex-1 flex-col max-w-4xl mx-auto w-full p-4 md:p-8">
      <div className="flex justify-between items-center mb-4">
        <Button variant="outline" asChild size="sm">
          <Link to="/messages">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Link>
        </Button>
        <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-destructive" onClick={() => setIsReportOpen(true)}>
          <Flag className="h-4 w-4 mr-2" />
          Report User
        </Button>
      </div>
      
      <Card className="flex flex-col flex-1 h-[calc(100vh-280px)] overflow-hidden">
        <CardHeader className="border-b p-4 flex flex-row items-center justify-between bg-card/50">
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={otherUserProfile?.avatar_url || undefined} />
              <AvatarFallback><UserIcon className="h-6 w-6" /></AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-base font-bold">{otherUserName}</CardTitle>
              {(relatedItem || relatedService) && (
                <div className="flex items-center gap-1 text-[10px] text-muted-foreground uppercase font-bold">
                  {relatedItem ? <Package2 className="h-2.5 w-2.5" /> : <Briefcase className="h-2.5 w-2.5" />}
                  <span className="truncate">{relatedItem?.name || relatedService?.name}</span>
                </div>
              )}
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={handleShowLocation} disabled={locationLoading} className="rounded-full">
            {locationLoading ? <Loader2 className="h-4 w-4 animate-spin" /> : <MapPin className="h-4 w-4 mr-2" />}
            Locate
          </Button>
        </CardHeader>
        
        <CardContent className="flex-1 overflow-y-auto p-4 space-y-4 bg-muted/5">
          {showMap && userLocation && (
            <div className="mb-4 rounded-xl overflow-hidden border bg-card shadow-sm h-64 relative">
              <Button variant="ghost" size="icon" onClick={() => setShowMap(false)} className="absolute top-2 right-2 z-10 bg-background/50 backdrop-blur h-8 w-8 rounded-full">
                <X className="h-4 w-4" />
              </Button>
              <MapDisplay center={userLocation} items={otherUserLocation ? [{ latitude: otherUserLocation[0], longitude: otherUserLocation[1], name: otherUserName }] : []} zoom={15} />
            </div>
          )}
          
          {messages.map((msg) => (
            <div key={msg.id} className={cn("flex items-end gap-2", msg.sender_id === user.id ? "justify-end" : "justify-start")}>
              {msg.sender_id !== user.id && (
                <Avatar className="h-6 w-6"><AvatarFallback><UserIcon className="h-3 w-3" /></AvatarFallback></Avatar>
              )}
              <div className={cn("max-w-[80%] p-3 rounded-2xl shadow-sm text-sm", msg.sender_id === user.id ? "bg-primary text-primary-foreground rounded-br-none" : "bg-card border rounded-bl-none")}>
                <p className="whitespace-pre-wrap">{msg.content}</p>
                <div className="flex items-center justify-end gap-1 mt-1 opacity-60 text-[9px]">
                  {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  {msg.sender_id === user.id && (msg.is_read ? <CheckCheck className="h-3 w-3" /> : <Check className="h-3 w-3" />)}
                </div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </CardContent>
        
        <div className="p-4 bg-card border-t flex items-center gap-2 pb-safe">
          <Input 
            placeholder="Write a message..." 
            value={messageContent} 
            onChange={e => setMessageContent(e.target.value)}
            className="rounded-full"
            onKeyPress={e => e.key === 'Enter' && handleSendMessage()}
          />
          <Button size="icon" onClick={handleSendMessage} disabled={isSending || !messageContent.trim()} className="rounded-full h-10 w-10">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </Card>
      
      <ReportDialog isOpen={isReportOpen} onOpenChange={setIsReportOpen} targetId={otherUserId!} targetType="chat" />
    </div>
  );
};

export default ChatPage;