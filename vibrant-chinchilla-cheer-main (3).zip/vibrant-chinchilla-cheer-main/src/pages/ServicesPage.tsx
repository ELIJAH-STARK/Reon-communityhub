"use client";

import React, { useState, useMemo, useRef, useEffect } from "react";
import { serviceCategories } from "@/lib/constants";
import { useServices } from "@/context/ServicesContext";
import { useGeolocation } from "@/hooks/use-geolocation";
import { calculateDistance, cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Loader2, MapPin, Search, SlidersHorizontal, Briefcase, RefreshCcw, AlertTriangle, CheckCircle2, Sparkles } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import FavoriteButton from "@/components/FavoriteButton";
import { Collapsible, CollapsibleContent } from "@/components/ui/collapsible";
import AdBanner from "@/components/AdBanner";
import { useSession } from "@/context/SessionContext";
import { useTranslation } from "@/hooks/useTranslation";

const ServicesPage = () => {
  const { uploadedServices, loadingServices, errorServices, refreshServices } = useServices();
  const { latitude, longitude } = useGeolocation();
  const { isPremium } = useSession();
  const { t } = useTranslation();
  
  const [selectedCategory, setSelectedCategory] = useState<string>("All Categories");
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("newest");
  const [maxDistance, setMaxDistance] = useState<string>("all");
  const [showFilters, setShowFilters] = useState(false);
  
  const categoriesRef = useRef<HTMLDivElement>(null);
  const userLocation: [number, number] | null = latitude && longitude ? [latitude, longitude] : null;

  const { topFeatured, displayList } = useMemo(() => {
    // 1. Filter base services - CRITICAL: Filter out held services
    let services = [...uploadedServices].filter(s => !s.is_held);
    
    if (selectedCategory !== "All Categories") {
      services = services.filter(s => s.category === selectedCategory);
    }
    
    if (searchTerm.trim() !== "") {
      const lower = searchTerm.toLowerCase();
      services = services.filter(s => 
        s.name.toLowerCase().includes(lower) || 
        s.description?.toLowerCase().includes(lower)
      );
    }
    
    if (maxDistance !== "all" && userLocation) {
      const limit = parseInt(maxDistance) * 1000;
      services = services.filter(s => {
        if (!s.latitude || !s.longitude) return false;
        const dist = calculateDistance(userLocation[0], userLocation[1], s.latitude, s.longitude);
        return dist <= limit;
      });
    }

    // 2. Sort
    services.sort((a, b) => {
      if (sortBy === "closest" && userLocation && a.latitude && a.longitude && b.latitude && b.longitude) {
        const distA = calculateDistance(userLocation[0], userLocation[1], a.latitude, a.longitude);
        const distB = calculateDistance(userLocation[0], userLocation[1], b.latitude, b.longitude);
        return distA - distB;
      }
      return new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime();
    });

    // 3. Separate Featured and Regular
    const featuredMatches = services.filter(s => s.is_featured);
    const regularMatches = services.filter(s => !s.is_featured);

    // 4. Hero selection (3 random)
    const top = [...featuredMatches].sort(() => 0.5 - Math.random()).slice(0, 3);
    const topIds = new Set(top.map(t => t.id));

    // 5. Injection pool (the rest)
    const injectionPool = featuredMatches.filter(s => !topIds.has(s.id));

    // 6. Build scroll list
    const result: any[] = [];
    let injectIdx = 0;

    regularMatches.forEach((service, index) => {
      result.push(service);
      if ((index + 1) % 5 === 0 && injectionPool.length > 0) {
        result.push(injectionPool[injectIdx % injectionPool.length]);
        injectIdx++;
      }
    });

    return { topFeatured: top, displayList: result };
  }, [uploadedServices, selectedCategory, searchTerm, sortBy, maxDistance, userLocation]);

  const categories = ["All Categories", ...serviceCategories];

  return (
    <div className="flex flex-1 flex-col items-center p-3 md:p-4">
      <div className="w-full max-w-5xl space-y-4 md:space-y-6">
        <div className="text-center space-y-1">
          <h3 className="text-2xl md:text-3xl font-bold tracking-tight text-primary">Discover Services</h3>
          <p className="text-sm text-muted-foreground">Find skilled neighbors within reach</p>
        </div>

        <div className="flex flex-col gap-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input 
                placeholder="Search services..." 
                value={searchTerm} 
                onChange={(e) => setSearchTerm(e.target.value)} 
                className="pl-9 h-10 rounded-xl" 
              />
            </div>
            <Button variant="outline" size="icon" onClick={() => setShowFilters(!showFilters)} className={cn("md:w-auto md:px-4 h-10 rounded-xl", showFilters && "bg-primary/5 border-primary text-primary")}>
              <SlidersHorizontal className="h-4 w-4 md:mr-2" />
              <span className="hidden md:inline text-xs font-bold uppercase tracking-wider">Filters</span>
            </Button>
          </div>

          <div ref={categoriesRef} className="w-full overflow-x-auto no-scrollbar py-1">
            <div className="flex gap-2 min-w-max px-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={cn(
                    "px-5 py-2 rounded-full text-[11px] font-bold uppercase tracking-wider transition-all whitespace-nowrap border-2",
                    selectedCategory === cat 
                      ? "bg-primary text-primary-foreground border-primary shadow-md scale-105" 
                      : "bg-background text-muted-foreground border-transparent hover:border-primary/20"
                  )}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <Collapsible open={showFilters} onOpenChange={setShowFilters}>
            <CollapsibleContent className="space-y-4 bg-muted/30 p-4 rounded-2xl border border-dashed animate-in fade-in slide-in-from-top-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">{t('content.range')}</Label>
                  <Select value={maxDistance} onValueChange={setMaxDistance}>
                    <SelectTrigger className="h-9 rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t('content.anyDistance')}</SelectItem>
                      <SelectItem value="5">{t('content.within5km')}</SelectItem>
                      <SelectItem value="10">{t('content.within10km')}</SelectItem>
                      <SelectItem value="25">{t('content.within25km')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-[10px] uppercase font-bold text-muted-foreground ml-1">{t('content.orderBy')}</Label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="h-9 rounded-lg"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">{t('content.newestFirst')}</SelectItem>
                      <SelectItem value="closest" disabled={!userLocation}>{t('content.closestToMe')}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>

        <div className="w-full">
          <AdBanner />
        </div>

        {loadingServices ? (
          <div className="flex flex-col items-center py-20 gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-muted-foreground text-sm font-medium">{t('content.scanningTreasures')}</p>
          </div>
        ) : errorServices ? (
          <div className="flex flex-col items-center py-20 gap-4 bg-muted/20 rounded-2xl border border-dashed">
            <AlertTriangle className="h-10 w-10 text-destructive/50" />
            <p className="text-muted-foreground font-medium">{errorServices}</p>
            <Button variant="outline" onClick={refreshServices} className="rounded-full">
              <RefreshCcw className="h-4 w-4 mr-2" />
              {t('content.reconnectHub')}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 md:gap-6">
            {/* TOP FEATURED SPOTS */}
            {topFeatured.map((service) => {
              const distance = service.latitude && service.longitude && userLocation 
                ? (calculateDistance(userLocation[0], userLocation[1], service.latitude, service.longitude) / 1000).toFixed(1) 
                : null;
              const hasDiscount = service.price != null && service.discount_percentage != null && service.discount_percentage > 0;
              const discountedPrice = hasDiscount 
                ? (service.price! * (1 - service.discount_percentage! / 100)).toFixed(2) 
                : null;

              return (
                <Link to={`/services/${service.id}`} key={`top-featured-${service.id}`} className="group">
                  <div className="bg-yellow-500/5 rounded-2xl border border-yellow-500/30 shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300 relative h-full flex flex-col group-hover:-translate-y-1 ring-1 ring-yellow-500/20">
                    <div className="absolute top-2 right-2 z-10">
                      <FavoriteButton id={service.id} type="service" className="h-8 w-8 bg-background/80 backdrop-blur-md shadow-sm" />
                    </div>
                    <div className="absolute top-2 left-2 z-10 flex gap-1">
                      <Badge className="bg-yellow-500 text-white text-[8px] font-black px-2 py-0.5 border-none shadow-lg">
                        <Sparkles className="h-2 w-2 mr-1 fill-current" />
                        FEATURED
                      </Badge>
                      {hasDiscount && (
                        <Badge className="bg-red-500 text-white text-[8px] font-bold px-2 py-0.5 border-none">
                          -{service.discount_percentage}%
                        </Badge>
                      )}
                    </div>
                    <div className="aspect-square w-full overflow-hidden bg-muted relative">
                      {service.image_url ? (
                        <img src={service.image_url} alt={service.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-primary/5">
                          <Briefcase className="h-10 w-10 text-primary/30" />
                        </div>
                      )}
                      {service.is_provider_verified && (
                        <div className="absolute bottom-0 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-1 px-2 flex items-center justify-center gap-1.5">
                          <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                          <span className="text-[9px] font-bold text-white uppercase tracking-wider">Verified Neighbor</span>
                        </div>
                      )}
                    </div>
                    <div className="p-4 flex-1 flex flex-col">
                      <div className="flex justify-between items-start mb-1.5 gap-1">
                        <span className="text-[10px] font-bold text-primary/70 uppercase tracking-widest truncate">{service.category}</span>
                        {distance && (
                          <span className="text-[10px] text-muted-foreground font-bold flex items-center shrink-0 bg-muted px-1.5 py-0.5 rounded">
                            <MapPin className="h-2.5 w-2.5 mr-1" />{distance}km
                          </span>
                        )}
                      </div>
                      <h4 className="font-bold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">{service.name}</h4>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-auto pt-3 border-t border-muted gap-2">
                        <div className="flex flex-col">
                          {service.price === 0 ? (
                            <span className="text-sm font-extrabold text-green-600">Free</span>
                          ) : service.price === null ? (
                            <span className="text-sm font-extrabold text-primary">Negotiable</span>
                          ) : (
                            <div className="flex flex-wrap items-baseline gap-1.5">
                              <span className="text-sm font-extrabold text-primary">
                                ${discountedPrice || service.price.toFixed(2)}
                              </span>
                            </div>
                          )}
                        </div>
                        <Badge variant="outline" className="text-[9px] uppercase font-bold h-5 px-2 bg-yellow-500/10 text-yellow-700 border-yellow-200">
                          {service.status}
                        </Badge>
                      </div>
                    </div>
                  </div>
                </Link>
              );
            })}

            {/* MAIN LIST WITH INJECTED FEATURED */}
            {displayList.map((service, index) => {
              const distance = service.latitude && service.longitude && userLocation 
                ? (calculateDistance(userLocation[0], userLocation[1], service.latitude, service.longitude) / 1000).toFixed(1) 
                : null;
              const hasDiscount = service.price != null && service.discount_percentage != null && service.discount_percentage > 0;
              const discountedPrice = hasDiscount 
                ? (service.price! * (1 - service.discount_percentage! / 100)).toFixed(2) 
                : null;

              return (
                <React.Fragment key={`${service.id}-${index}`}>
                  <Link to={`/services/${service.id}`} className="group">
                    <div className={cn(
                      "bg-card rounded-2xl border shadow-sm overflow-hidden hover:shadow-xl transition-all duration-300 relative h-full flex flex-col group-hover:-translate-y-1",
                      service.is_featured && "border-yellow-500/30 bg-yellow-500/5 ring-1 ring-yellow-500/10"
                    )}>
                      <div className="absolute top-2 right-2 z-10">
                        <FavoriteButton id={service.id} type="service" className="h-8 w-8 bg-background/80 backdrop-blur-md shadow-sm" />
                      </div>
                      <div className="absolute top-2 left-2 z-10 flex gap-1">
                        {service.is_featured && (
                          <Badge className="bg-yellow-500 text-white text-[8px] font-black px-2 py-0.5 border-none shadow-sm">
                            FEATURED
                          </Badge>
                        )}
                        {hasDiscount && (
                          <Badge className="bg-red-500 hover:bg-red-600 text-[10px] font-bold px-2 py-0.5 border-none">
                            -{service.discount_percentage}%
                          </Badge>
                        )}
                      </div>
                      <div className="aspect-square w-full overflow-hidden bg-muted relative">
                        {service.image_url ? (
                          <img src={service.image_url} alt={service.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-primary/5">
                            <Briefcase className="h-10 w-10 text-primary/30" />
                          </div>
                        )}
                        {service.is_provider_verified && (
                          <div className="absolute bottom-0 left-0 right-0 z-10 bg-blue-500/90 backdrop-blur-sm py-1 px-2 flex items-center justify-center gap-1.5">
                            <CheckCircle2 className="h-3 w-3 text-white fill-current" />
                            <span className="text-[9px] font-bold text-white uppercase tracking-wider">Verified Neighbor</span>
                          </div>
                        )}
                      </div>
                      <div className="p-4 flex-1 flex flex-col">
                        <div className="flex justify-between items-start mb-1.5 gap-1">
                          <span className="text-[10px] font-bold text-primary/70 uppercase tracking-widest truncate">{service.category}</span>
                          {distance && (
                            <span className="text-[10px] text-muted-foreground font-bold flex items-center shrink-0 bg-muted px-1.5 py-0.5 rounded">
                              <MapPin className="h-2.5 w-2.5 mr-1" />{distance}km
                            </span>
                          )}
                        </div>
                        <h4 className="font-bold text-sm mb-2 line-clamp-2 group-hover:text-primary transition-colors">{service.name}</h4>
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between mt-auto pt-3 border-t border-muted gap-2">
                          <div className="flex flex-col">
                            {service.price === 0 ? (
                              <span className="text-sm font-extrabold text-green-600">Free</span>
                            ) : service.price === null ? (
                              <span className="text-sm font-extrabold text-primary">Negotiable</span>
                            ) : (
                              <div className="flex flex-wrap items-baseline gap-1.5">
                                <span className="text-sm font-extrabold text-primary">
                                  ${discountedPrice || service.price.toFixed(2)}
                                </span>
                              </div>
                            )}
                          </div>
                          <Badge variant="outline" className="text-[9px] uppercase font-bold h-5 px-2 border-primary/20 text-primary bg-primary/5 w-fit">
                            {service.status}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </Link>

                  {(index + 1) % 20 === 0 && !isPremium && (
                    <div className="col-span-full py-4">
                      <AdBanner />
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>
        )}

        {(!loadingServices && displayList.length === 0 && topFeatured.length === 0) && (
          <div className="text-center py-32 bg-muted/20 rounded-3xl border-2 border-dashed flex flex-col items-center">
             <div className="p-4 bg-background rounded-full shadow-inner mb-4">
              <Briefcase className="h-12 w-12 text-muted-foreground/20" />
            </div>
            <p className="text-muted-foreground font-bold">No services found in your area.</p>
            <Button variant="link" onClick={() => { setSelectedCategory("All Categories"); setSearchTerm(""); setMaxDistance("all"); }} className="text-primary mt-2">
              Clear All Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServicesPage;