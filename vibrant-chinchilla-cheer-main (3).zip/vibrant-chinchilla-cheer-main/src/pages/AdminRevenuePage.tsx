"use client";

import React, { useState, useEffect, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from "@/components/ui/card";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";
import { 
  Loader2, 
  DollarSign, 
  TrendingUp, 
  Calendar, 
  Filter,
  ArrowUpRight,
  Package2,
  Crown,
  CreditCard
} from "lucide-react";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";

const AdminRevenuePage = () => {
  const { user, profile, isAdmin, loading: sessionLoading } = useSession();
  const navigate = useNavigate();
  
  const [transactions, setTransactions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [timeSpan, setTimeSpan] = useState("30"); // days

  useEffect(() => {
    // Access control
    if (!sessionLoading && (!user || !isAdmin)) {
      toast.error("Unauthorized access.");
      navigate("/");
      return;
    }

    const fetchTransactions = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('transactions')
          .select('*, profiles(username, first_name, last_name)')
          .eq('status', 'completed')
          .order('created_at', { ascending: true });

        if (error) throw error;
        setTransactions(data || []);
      } catch (err: any) {
        toast.error("Failed to load revenue data.");
      } finally {
        setLoading(false);
      }
    };

    if (isAdmin) fetchTransactions();
  }, [isAdmin, sessionLoading, user, navigate]);

  const stats = useMemo(() => {
    const total = transactions.reduce((acc, t) => acc + t.amount, 0);
    const premium = transactions.filter(t => t.item_type === 'premium').reduce((acc, t) => acc + t.amount, 0);
    const slots = transactions.filter(t => t.item_type !== 'premium').reduce((acc, t) => acc + t.amount, 0);
    
    return { total, premium, slots, count: transactions.length };
  }, [transactions]);

  const chartData = useMemo(() => {
    const now = new Date();
    const startDate = new Date();
    startDate.setDate(now.getDate() - parseInt(timeSpan));

    const dailyMap = new Map();
    
    // Initialize map with zeros for all days in range
    for (let d = new Date(startDate); d <= now; d.setDate(d.getDate() + 1)) {
      const dateStr = d.toISOString().split('T')[0];
      dailyMap.set(dateStr, 0);
    }

    // Populate with actual data
    transactions.forEach(t => {
      const dateStr = new Date(t.created_at).toISOString().split('T')[0];
      if (dailyMap.has(dateStr)) {
        dailyMap.set(dateStr, dailyMap.get(dateStr) + t.amount);
      }
    });

    return Array.from(dailyMap.entries()).map(([date, amount]) => ({
      date: new Date(date).toLocaleDateString([], { month: 'short', day: 'numeric' }),
      amount: parseFloat(amount.toFixed(2))
    }));
  }, [transactions, timeSpan]);

  if (sessionLoading || loading) {
    return (
      <div className="flex h-[400px] flex-col items-center justify-center gap-4">
        <Loader2 className="h-10 w-10 animate-spin text-primary" />
        <p className="text-muted-foreground animate-pulse">Calculating financial data...</p>
      </div>
    );
  }

  return (
    <div className="container max-w-6xl mx-auto py-8 space-y-8 px-4">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black tracking-tight flex items-center gap-3">
            <DollarSign className="h-8 w-8 text-primary" />
            Revenue Dashboard
          </h1>
          <p className="text-muted-foreground">Monitoring verified transaction flow across the Hub.</p>
        </div>
        
        <div className="flex items-center gap-3 bg-card p-1 rounded-xl border shadow-sm">
          <Badge variant="ghost" className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground flex gap-1 items-center">
            <Calendar className="h-3 w-3" /> Timespan
          </Badge>
          <Select value={timeSpan} onValueChange={setTimeSpan}>
            <SelectTrigger className="w-[140px] h-8 border-none bg-transparent font-bold">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-xl">
              <SelectItem value="7">Last 7 Days</SelectItem>
              <SelectItem value="30">Last 30 Days</SelectItem>
              <SelectItem value="90">Last 90 Days</SelectItem>
              <SelectItem value="365">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-none shadow-md bg-primary text-primary-foreground overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-20">
            <TrendingUp className="h-12 w-12" />
          </div>
          <CardHeader className="pb-2">
            <CardDescription className="text-primary-foreground/70 text-[10px] font-bold uppercase tracking-widest">Total Revenue</CardDescription>
            <CardTitle className="text-3xl font-black">${stats.total.toFixed(2)}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-1 text-xs font-bold bg-white/10 w-fit px-2 py-1 rounded-full">
              <ArrowUpRight className="h-3 w-3" />
              {stats.count} Successful Sales
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Premium Members</CardDescription>
            <CardTitle className="text-3xl font-black text-yellow-500 flex items-center gap-2">
              <Crown className="h-6 w-6 fill-current" />
              ${stats.premium.toFixed(2)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground font-medium">Lifetime supporter upgrades</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Extra Slots</CardDescription>
            <CardTitle className="text-3xl font-black text-blue-500 flex items-center gap-2">
              <Package2 className="h-6 w-6" />
              ${stats.slots.toFixed(2)}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground font-medium">Capacity boost purchases</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md">
          <CardHeader className="pb-2">
            <CardDescription className="text-[10px] font-bold uppercase tracking-widest">Avg Transaction</CardDescription>
            <CardTitle className="text-3xl font-black text-green-500">
              ${stats.count > 0 ? (stats.total / stats.count).toFixed(2) : "0.00"}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-muted-foreground font-medium">Average purchase value</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <Card className="lg:col-span-2 border-none shadow-lg rounded-3xl overflow-hidden bg-card">
          <CardHeader className="pb-8">
            <CardTitle className="text-lg font-black flex items-center gap-2">
              <Filter className="h-5 w-5 text-primary" />
              Earnings Overview
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[350px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorAmount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(var(--muted))" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 700 }}
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fontSize: 10, fontWeight: 700 }}
                    tickFormatter={(val) => '$' + val}
                  />
                  <Tooltip 
                    contentStyle={{ 
                      borderRadius: '12px', 
                      border: 'none', 
                      boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)',
                      fontWeight: 'bold'
                    }}
                    formatter={(val) => ['$' + val, 'Revenue']}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="amount" 
                    stroke="hsl(var(--primary))" 
                    strokeWidth={3}
                    fillOpacity={1} 
                    fill="url(#colorAmount)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg rounded-3xl overflow-hidden">
          <CardHeader>
            <CardTitle className="text-lg font-black">Recent Payments</CardTitle>
            <CardDescription>Latest successfully processed items.</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="divide-y">
              {transactions.slice(-6).reverse().map((t) => (
                <div key={t.id} className="p-4 flex items-center justify-between hover:bg-muted/30 transition-colors">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "p-2 rounded-xl",
                      t.item_type === 'premium' ? "bg-yellow-500/10" : "bg-blue-500/10"
                    )}>
                      {t.item_type === 'premium' ? <Crown className="h-4 w-4 text-yellow-600" /> : <CreditCard className="h-4 w-4 text-blue-600" />}
                    </div>
                    <div>
                      <p className="text-sm font-bold truncate max-w-[120px]">
                        {t.profiles?.username || "Neighbor"}
                      </p>
                      <p className="text-[10px] text-muted-foreground uppercase font-black">{t.item_type}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-black text-primary">+${t.amount.toFixed(2)}</p>
                    <p className="text-[10px] text-muted-foreground">{new Date(t.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
              {transactions.length === 0 && (
                <div className="p-12 text-center text-muted-foreground italic">
                  No successful payments yet.
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminRevenuePage;