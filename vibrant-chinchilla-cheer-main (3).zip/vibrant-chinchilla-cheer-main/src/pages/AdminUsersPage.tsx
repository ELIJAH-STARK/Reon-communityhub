"use client";
import React, { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useSession } from "@/context/SessionContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Users, Ban, Trash2, Package2, Briefcase, Search, ShieldCheck, CheckCircle2, AlertTriangle, HelpCircle } from "lucide-react";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const AdminUsersPage = () => {
  const { user: currentUser } = useSession();
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [userListings, setUserListings] = useState<{ goods: any[], services: any[], requests: any[] }>({ 
    goods: [], 
    services: [], 
    requests: [] 
  });
  const [showBanDialog, setShowBanDialog] = useState(false);
  const [banDuration, setBanDuration] = useState("forever");
  const [isProcessing, setIsProcessing] = useState(false);

  const fetchUsers = async () => {
    setLoading(true);
    const { data } = await supabase.from('profiles').select('*').order('updated_at', { ascending: false });
    if (data) setUsers(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUserListings = async (userId: string) => {
    const [goods, services, requests] = await Promise.all([
      supabase.from('goods').select('*').eq('user_id', userId),
      supabase.from('services').select('*').eq('user_id', userId),
      supabase.from('requests').select('*').eq('user_id', userId)
    ]);
    
    setUserListings({ 
      goods: goods.data || [], 
      services: services.data || [], 
      requests: requests.data || [] 
    });
  };

  const toggleVerification = async (userId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_verified: !currentStatus })
        .eq('id', userId);
      
      if (error) throw error;
      
      toast.success(currentStatus ? "Verification removed" : "User verified!");
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, is_verified: !currentStatus } : u));
      
      if (selectedUser?.id === userId) {
        setSelectedUser({ ...selectedUser, is_verified: !currentStatus });
      }
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleBan = async () => {
    if (!selectedUser) return;
    setIsProcessing(true);
    
    try {
      // Logic for actual banning via Edge Function 'admin-manage-user'
      const { error } = await supabase.functions.invoke('admin-manage-user', {
        body: {
          userId: selectedUser.id,
          action: 'ban',
          reason: 'Violated community guidelines'
        }
      });
      
      if (error) throw error;
      
      toast.success("User restricted successfully");
      fetchUsers();
      setShowBanDialog(false);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const deleteListing = async (id: string, type: 'good' | 'service' | 'request') => {
    if (!confirm("Are you sure? This action is permanent.")) return;
    
    const table = type === 'good' ? 'goods' : type === 'service' ? 'services' : 'requests';
    const { error } = await supabase.from(table).delete().eq('id', id);
    
    if (!error) {
      toast.success("Listing removed");
      fetchUserListings(selectedUser.id);
    }
  };

  const filteredUsers = users.filter(u => 
    `${u.first_name} ${u.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.id.includes(searchTerm)
  );

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin h-8 w-8 text-primary" /></div>;

  return (
    <div className="container max-w-6xl mx-auto py-8 space-y-6 px-4">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <Users className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold">User Management</h1>
        </div>
        <div className="relative w-full max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search users..." 
            value={searchTerm} 
            onChange={(e) => setSearchTerm(e.target.value)} 
            className="pl-9 rounded-xl" 
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4 max-h-[70vh] overflow-y-auto no-scrollbar">
          {filteredUsers.map((u) => (
            <Card 
              key={u.id} 
              className={`cursor-pointer transition-all hover:border-primary/50 shadow-sm ${selectedUser?.id === u.id ? 'border-primary ring-1 ring-primary' : ''}`}
              onClick={() => {
                setSelectedUser(u);
                fetchUserListings(u.id);
              }}
            >
              <CardContent className="p-4 flex items-center gap-3">
                <Avatar className="h-10 w-10 border">
                  <AvatarImage src={u.avatar_url} />
                  <AvatarFallback><Users className="h-5 w-5" /></AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-bold truncate text-sm flex items-center gap-1">
                    {u.first_name} {u.last_name}
                    {u.is_verified && <CheckCircle2 className="h-3 w-3 text-blue-500 fill-current" />}
                  </p>
                  <div className="flex gap-1 mt-1">
                    {u.is_banned && <Badge variant="destructive" className="text-[8px] h-3 px-1">RESTRICTED</Badge>}
                    <span className="text-[10px] text-muted-foreground uppercase tracking-widest font-bold">{u.role}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="lg:col-span-2">
          {selectedUser ? (
            <Card className="h-full shadow-md border-none">
              <CardHeader className="border-b pb-4">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-4">
                    <Avatar className="h-16 w-16 border-2 shadow-sm">
                      <AvatarImage src={selectedUser.avatar_url} />
                      <AvatarFallback><Users className="h-8 w-8" /></AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="flex items-center gap-2">
                        {selectedUser.first_name} {selectedUser.last_name}
                      </CardTitle>
                      <p className="text-xs font-mono text-muted-foreground mt-1">UUID: {selectedUser.id}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      variant={selectedUser.is_verified ? "outline" : "default"} 
                      size="sm" 
                      className="rounded-full"
                      onClick={() => toggleVerification(selectedUser.id, selectedUser.is_verified)}
                    >
                      {selectedUser.is_verified ? "Revoke Verify" : "Verify User"}
                    </Button>
                    <Button 
                      variant={selectedUser.is_banned ? "outline" : "destructive"} 
                      size="sm" 
                      className="rounded-full"
                      onClick={() => setShowBanDialog(true)}
                    >
                      <Ban className="h-4 w-4 mr-2" />
                      {selectedUser.is_banned ? "Lift Ban" : "Restrict"}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-6">
                <Tabs defaultValue="goods">
                  <TabsList className="grid w-full grid-cols-3 max-w-xs">
                    <TabsTrigger value="goods">Goods ({userListings.goods.length})</TabsTrigger>
                    <TabsTrigger value="services">Services ({userListings.services.length})</TabsTrigger>
                    <TabsTrigger value="requests">Requests ({userListings.requests.length})</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="goods" className="space-y-3 mt-4">
                    {userListings.goods.map(g => (
                      <div key={g.id} className="flex items-center justify-between p-3 border rounded-xl bg-muted/20">
                        <div className="flex items-center gap-3">
                          <Package2 className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">{g.name}</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive h-8 w-8"
                          onClick={() => deleteListing(g.id, 'good')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="services" className="space-y-3 mt-4">
                    {userListings.services.map(s => (
                      <div key={s.id} className="flex items-center justify-between p-3 border rounded-xl bg-muted/20">
                        <div className="flex items-center gap-3">
                          <Briefcase className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">{s.name}</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive h-8 w-8"
                          onClick={() => deleteListing(s.id, 'service')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </TabsContent>
                  
                  <TabsContent value="requests" className="space-y-3 mt-4">
                    {userListings.requests.map(r => (
                      <div key={r.id} className="flex items-center justify-between p-3 border rounded-xl bg-muted/20">
                        <div className="flex items-center gap-3">
                          <HelpCircle className="h-4 w-4 text-muted-foreground" />
                          <span className="text-sm font-medium">{r.title}</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="icon" 
                          className="text-destructive h-8 w-8"
                          onClick={() => deleteListing(r.id, 'request')}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <div className="h-full flex flex-col items-center justify-center border-2 border-dashed rounded-3xl bg-muted/10 p-12 text-center">
              <Users className="h-12 w-12 text-muted-foreground/20 mb-4" />
              <h3 className="text-lg font-bold text-muted-foreground">Select a Neighbor</h3>
              <p className="text-sm text-muted-foreground/60">Audit their listings and manage account trust.</p>
            </div>
          )}
        </div>
      </div>
      
      <Dialog open={showBanDialog} onOpenChange={setShowBanDialog}>
        <DialogContent className="rounded-3xl">
          <DialogHeader>
            <DialogTitle>Restrict Account: {selectedUser?.first_name}</DialogTitle>
          </DialogHeader>
          <div className="py-4 space-y-4 text-center">
            <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">
              Are you sure you want to restrict this user? They will be unable to message others or post new listings.
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowBanDialog(false)} className="rounded-full">
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleBan} 
              disabled={isProcessing}
              className="rounded-full"
            >
              {isProcessing && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Confirm Restriction
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default AdminUsersPage;