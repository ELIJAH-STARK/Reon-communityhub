"use client";

import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ThemeToggle } from "@/components/ThemeToggle";
import AccentColorPicker from "@/components/AccentColorPicker";
import { useSession } from "@/context/SessionContext";
import { useUserPreferences } from "@/context/UserPreferencesContext";
import { useLanguage, Language } from "@/context/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Info, Shield, Scale, Star } from "lucide-react";
import { Capacitor } from "@capacitor/core";
import { useTranslation } from "@/hooks/useTranslation";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const SettingsPage = () => {
  const { user } = useSession();
  const { preferences, updateShowFooter } = useUserPreferences();
  const { language, setLanguage } = useLanguage();
  const { t } = useTranslation();
  const [locationSharingEnabled, setLocationSharingEnabled] = React.useState(true);
  const [loading, setLoading] = React.useState(true);

  const languageNames: Record<Language, string> = {
    en: 'English',
    es: 'Español',
    fr: 'Français',
    de: 'Deutsch',
    ja: '日本語',
    ru: 'Русский',
    'zh-cn': '简体中文',
    hi: 'हिन्दी',
    it: 'Italiano',
    ar: 'العربية',
  };

  React.useEffect(() => {
    const fetchLocationSetting = async () => {
      if (!user) return;
      const { data, error } = await supabase
        .from("profiles")
        .select("location_sharing_enabled")
        .eq("id", user.id)
        .single();
      if (!error && data) {
        setLocationSharingEnabled(data.location_sharing_enabled ?? true);
      }
      setLoading(false);
    };
    fetchLocationSetting();
  }, [user]);

  const handleLocationSharingChange = async (checked: boolean) => {
    if (!user) return;
    const { error } = await supabase
      .from("profiles")
      .update({ location_sharing_enabled: checked })
      .eq("id", user.id);
    if (error) {
      toast.error(t('settings.failedToUpdateLocation'));
    } else {
      setLocationSharingEnabled(checked);
      toast.success(t('settings.locationUpdated'));
    }
  };

  if (loading) {
    return (
      <div className="flex h-[400px] items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container max-w-2xl mx-auto py-8 px-4 space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">{t('settings.settingsTitle')}</h1>
        <p className="text-muted-foreground">{t('settings.settingsDescription')}</p>
      </div>
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>{t('settings.privacySecurityTitle')}</CardTitle>
            <CardDescription>{t('settings.privacySecurityDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label className="text-base">{t('settings.locationSharing')}</Label>
                <p className="text-sm text-muted-foreground">{t('settings.locationSharingDesc')}</p>
              </div>
              <Switch checked={locationSharingEnabled} onCheckedChange={handleLocationSharingChange} />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('settings.appearance')}</CardTitle>
            <CardDescription>{t('settings.appearanceDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">{t('settings.themeMode')}</Label>
              <ThemeToggle />
            </div>
            <div className="flex items-center justify-between">
              <Label className="text-base font-medium">{t('settings.language')}</Label>
              <Select value={language} onValueChange={(value) => setLanguage(value as Language)}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder={t('settings.selectLanguage')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">{languageNames.en}</SelectItem>
                  <SelectItem value="es">{languageNames.es}</SelectItem>
                  <SelectItem value="fr">{languageNames.fr}</SelectItem>
                  <SelectItem value="de">{languageNames.de}</SelectItem>
                  <SelectItem value="ja">{languageNames.ja}</SelectItem>
                  <SelectItem value="ru">{languageNames.ru}</SelectItem>
                  <SelectItem value="zh-cn">{languageNames['zh-cn']}</SelectItem>
                  <SelectItem value="hi">{languageNames.hi}</SelectItem>
                  <SelectItem value="it">{languageNames.it}</SelectItem>
                  <SelectItem value="ar">{languageNames.ar}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <AccentColorPicker />
            {/* Footer visibility toggle - only show on web */}
            {!Capacitor.isNativePlatform() && (
              <div className="flex items-center justify-between pt-4 border-t">
                <div className="space-y-0.5">
                  <Label className="text-base">{t('settings.showFooter')}</Label>
                  <p className="text-sm text-muted-foreground">{t('settings.showFooterDesc')}</p>
                </div>
                <Switch 
                  checked={preferences.showFooter} 
                  onCheckedChange={updateShowFooter} 
                />
              </div>
            )}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>{t('settings.appInformation')}</CardTitle>
            <CardDescription>{t('settings.appInformationDesc')}</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="grid divide-y">
              <Link to="/settings/about-us" className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                <div className="h-9 w-9 rounded-lg bg-blue-500/10 flex items-center justify-center">
                  <Info className="h-5 w-5 text-blue-600" />
                </div>
                <span className="flex-1 font-medium">{t('settings.aboutCommunityHub')}</span>
              </Link>
              <Link to="/settings/privacy-policy" className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                <div className="h-9 w-9 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Shield className="h-5 w-5 text-green-600" />
                </div>
                <span className="flex-1 font-medium">{t('settings.privacyPolicy')}</span>
              </Link>
              <Link to="/settings/terms-of-service" className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors">
                <div className="h-9 w-9 rounded-lg bg-orange-500/10 flex items-center justify-center">
                  <Scale className="h-5 w-5 text-orange-600" />
                </div>
                <span className="flex-1 font-medium">{t('settings.termsOfService')}</span>
              </Link>
              <button onClick={() => alert("This would open the App Store / Play Store link.")} className="flex items-center gap-4 p-4 hover:bg-muted/50 transition-colors w-full text-left" >
                <div className="h-9 w-9 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                  <Star className="h-5 w-5 text-yellow-600" />
                </div>
                <span className="flex-1 font-medium">{t('settings.rateTheApp')}</span>
              </button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

const Loader2 = ({ className }: { className?: string }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className={`animate-spin ${className}`} >
    <path d="M21 12a9 9 0 1 1-6.219-8.56" />
  </svg>
);

export default SettingsPage;