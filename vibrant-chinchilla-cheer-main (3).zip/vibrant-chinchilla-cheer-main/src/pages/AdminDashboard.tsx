"use client";

import React from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useSystemSettings } from "@/hooks/use-system-settings";
import { Loader2, TrendingUp, Users, DollarSign, LayoutDashboard, AlertTriangle, ShieldCheck } from "lucide-react";

const AdminDashboard = () => {
  const { premiumEnabled, updatePremium, isUpdating } = useSystemSettings();

  // Fetching aggregate stats for the overview
  const { data: stats, isLoading: statsLoading, error: statsError } = useQuery({
    queryKey: ["admin-stats"],
    queryFn: async () => {
      const { data: transactions, error: txError } = await supabase
        .from("transactions")
        .select("amount, status");

      if (txError) throw txError;

      const totalSales = transactions
        ?.filter(t => t.status === 'completed')
        .reduce((acc, curr) => acc + (Number(curr.amount) || 0), 0) || 0;

      const { count: userCount } = await supabase
        .from("profiles")
        .select("*", { count: 'exact', head: true });

      return {
        totalSales,
        transactionCount: transactions?.length || 0,
        userCount: userCount || 0
      };
    }
  });

  return (
    <div className="container max-w-6xl mx-auto py-8 space-y-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="space-y-1">
          <h1 className="text-3xl font-black tracking-tight flex items-center gap-3">
            <LayoutDashboard className="h-8 w-8 text-primary" />
            System Control Panel
          </h1>
          <p className="text-muted-foreground">Manage global features and monitor platform performance.</p>
        </div>

        <Card className="w-full md:w-auto border-primary/20 bg-primary/5 shadow-sm">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-4">
              <div className="space-y-0.5">
                <Label className="text-sm font-bold uppercase tracking-wider">Premium Features</Label>
                <p className="text-[10px] text-muted-foreground font-medium">
                  {premiumEnabled ? "Public Access Active" : "Upgrades Restricted"}
                </p>
              </div>
              <Switch 
                checked={premiumEnabled} 
                onCheckedChange={updatePremium}
                disabled={isUpdating}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {statsError && (
        <div className="bg-destructive/10 text-destructive p-4 rounded-2xl flex items-center gap-3 border border-destructive/20 text-sm font-bold">
          <AlertTriangle className="h-5 w-5" />
          <span>Error loading metrics: {(statsError as Error).message}</span>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none shadow-md overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <DollarSign className="h-12 w-12" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-black uppercase tracking-widest text-muted-foreground">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? <Loader2 className="animate-spin h-6 w-6 text-primary" /> : (
              <div className="text-3xl font-black text-primary">${stats?.totalSales.toFixed(2)}</div>
            )}
            <p className="text-[10px] text-muted-foreground mt-2 font-bold">Gross transaction volume</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <Users className="h-12 w-12" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-black uppercase tracking-widest text-muted-foreground">Neighbor Count</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? <Loader2 className="animate-spin h-6 w-6 text-primary" /> : (
              <div className="text-3xl font-black">{stats?.userCount}</div>
            )}
            <p className="text-[10px] text-muted-foreground mt-2 font-bold">Registered community members</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-md overflow-hidden relative">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <ShieldCheck className="h-12 w-12" />
          </div>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-black uppercase tracking-widest text-muted-foreground">Sales Count</CardTitle>
          </CardHeader>
          <CardContent>
            {statsLoading ? <Loader2 className="animate-spin h-6 w-6 text-primary" /> : (
              <div className="text-3xl font-black">{stats?.transactionCount}</div>
            )}
            <p className="text-[10px] text-muted-foreground mt-2 font-bold">Verified purchases processed</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
        <Card className="border-none shadow-sm bg-muted/20">
          <CardHeader>
            <CardTitle className="text-lg">Quick Actions</CardTitle>
            <CardDescription>Shortcut to specific moderation tools.</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-3">
             <Button variant="outline" className="h-20 flex-col gap-2 rounded-2xl" asChild>
               <a href="/admin/users">
                 <Users className="h-5 w-5" />
                 <span>Users</span>
               </a>
             </Button>
             <Button variant="outline" className="h-20 flex-col gap-2 rounded-2xl" asChild>
               <a href="/admin/reports">
                 <AlertTriangle className="h-5 w-5" />
                 <span>Reports</span>
               </a>
             </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;