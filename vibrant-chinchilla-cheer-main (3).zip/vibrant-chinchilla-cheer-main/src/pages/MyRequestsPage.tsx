"use client";

import React, { useState, useEffect, useMemo } from "react";
import { PlusCircle, Loader2, MoreVertical, Edit, Trash, RefreshCcw, AlertTriangle, Sparkles, PackagePlus, EyeOff, Lock, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useRequests } from "@/context/RequestsContext";
import { useSession } from "@/context/SessionContext";
import { useItems } from "@/context/ItemsContext";
import { useServices } from "@/context/ServicesContext";
import { useTranslation } from "@/hooks/useTranslation";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { itemCategories, serviceCategories } from "@/lib/constants";
import { useGeolocation } from "@/hooks/use-geolocation";
import { Link } from "react-router-dom";
import { cn } from "@/lib/utils";
import { Card, CardContent } from "@/components/ui/card";

interface RequestForm {
  title: string;
  description: string;
  category: string;
  status: string;
}

const MyRequestsPage = () => {
  const { t } = useTranslation();
  const { userRequests, addRequest, updateRequest, deleteRequest, toggleFeatured, loading, error, refreshRequests } = useRequests();
  const { user, loading: sessionLoading, isPremium } = useSession();
  const { uploadedItems } = useItems();
  const { uploadedServices } = useServices();
  const { latitude, longitude } = useGeolocation();

  const [extraSlots, setExtraSlots] = useState(0);
  const [activeSlotExpiry, setActiveSlotExpiry] = useState<Date | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deletingRequestId, setDeletingRequestId] = useState<string | null>(null);
  const [editingRequest, setEditingRequest] = useState<any>(null);
  const [form, setForm] = useState<RequestForm>({
    title: "",
    description: "",
    category: "",
    status: "open"
  });
  const [formErrors, setFormErrors] = useState<Record<string, string>>({});

  // Deduplicate categories using useMemo to prevent the "duplicate key" error
  const categories = useMemo(() => {
    const combined = [...itemCategories, ...serviceCategories];
    return Array.from(new Set(combined)).sort();
  }, []);

  useEffect(() => {
    const fetchSlotData = async () => {
      if (user) {
        const { data: profile } = await supabase.from('profiles').select('extra_slots').eq('id', user.id).single();
        if (profile) setExtraSlots(profile.extra_slots || 0);

        const { data: transaction } = await supabase
          .from('slot_transactions')
          .select('expiry_date')
          .eq('user_id', user.id)
          .gt('expiry_date', new Date().toISOString())
          .order('expiry_date', { ascending: false })
          .limit(1)
          .single();
        if (transaction) setActiveSlotExpiry(new Date(transaction.expiry_date));
      }
    };
    fetchSlotData();
  }, [user]);

  // Separate Held vs Active
  const activeRequests = userRequests.filter(r => !r.is_held);
  const heldRequests = userRequests.filter(r => r.is_held);

  // Calculate total listings count including goods, services, and requests
  const userListingsCount = (uploadedItems?.filter(i => i.user_id === user?.id).length || 0) +
    (uploadedServices?.filter(s => s.user_id === user?.id).length || 0) +
    userRequests.length;

  const currentLimit = 10 + extraSlots;
  const usagePercentage = isPremium ? 0 : Math.min(100, (userListingsCount / currentLimit) * 100);

  const validateForm = () => {
    const errors: Record<string, string> = {};
    if (!form.title.trim()) {
      errors.title = t('dialogs.nameRequired');
    }
    if (!form.category) {
      errors.category = t('dialogs.categoryRequired');
    }
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const resetForm = () => {
    setForm({
      title: "",
      description: "",
      category: "",
      status: "open"
    });
    setFormErrors({});
    setEditingRequest(null);
  };

  const handleOpenDialog = (request?: any) => {
    if (request) {
      setEditingRequest(request);
      setForm({
        title: request.title,
        description: request.description || "",
        category: request.category,
        status: request.status
      });
    } else {
      resetForm();
    }
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    resetForm();
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleSelectChange = (name: string, value: string) => {
    setForm(prev => ({ ...prev, [name]: value }));
    if (formErrors[name]) {
      setFormErrors(prev => {
        const newErrors = { ...prev };
        delete newErrors[name];
        return newErrors;
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) {
      return;
    }
    try {
      if (editingRequest) {
        await updateRequest(editingRequest.id, {
          ...form,
          latitude: latitude || null,
          longitude: longitude || null
        });
      } else {
        if (!isPremium && userListingsCount >= currentLimit) {
          toast.error("You've reached your listing limit. Upgrade to Premium for unlimited requests.");
          return;
        }
        await addRequest({
          ...form,
          latitude: latitude || null,
          longitude: longitude || null
        });
      }
      handleCloseDialog();
    } catch (error) {
      console.error("Failed to save request:", error);
    }
  };

  const handleDeleteClick = (id: string) => {
    setDeletingRequestId(id);
  };

  const handleDeleteConfirm = async () => {
    if (!deletingRequestId) return;
    setIsDeleting(true);
    try {
      await deleteRequest(deletingRequestId);
      setDeletingRequestId(null);
    } catch (error) {
      console.error("Failed to delete request:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div className="flex flex-1 flex-col items-center p-3 md:p-4">
      <div className="w-full max-w-2xl space-y-6">
        <div className="text-center space-y-1">
          <h3 className="text-2xl font-bold tracking-tight">{t('pages.myRequests')}</h3>
          <p className="text-sm text-muted-foreground">{t('pages.manageRequests')}</p>
        </div>

        <Card className="bg-muted/40 p-4 rounded-2xl border border-dashed space-y-3">
          <div className="flex justify-between items-center text-xs font-bold uppercase tracking-wider">
            <div className="flex items-center gap-2">
              <PackagePlus className="h-3.5 w-3.5 text-primary" />
              <span>{t('pages.capacityStatus')}</span>
            </div>
            <span>{userListingsCount} / {isPremium ? '∞' : currentLimit} {t('pages.slots')}</span>
          </div>
          {!isPremium && (
            <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
              <div
                className={cn(
                  "h-full transition-all duration-500",
                  usagePercentage > 90 ? "bg-destructive" : usagePercentage > 70 ? "bg-orange-500" : "bg-primary"
                )}
                style={{ width: `${usagePercentage}%` }}
              />
            </div>
          )}
          {activeSlotExpiry && (
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground mt-2">
              <Info className="h-3 w-3" />
              <span>{t('pages.activeSlotsExpire')}: {activeSlotExpiry.toLocaleDateString()}</span>
            </div>
          )}
          {heldRequests.length > 0 && (
            <div className="bg-yellow-500/10 border border-yellow-500/20 p-2 rounded-lg flex items-center gap-2 mt-2">
              <EyeOff className="h-4 w-4 text-yellow-600" />
              <span className="text-xs font-bold text-yellow-700">{heldRequests.length} {t('pages.requestsHeld')}</span>
            </div>
          )}
        </Card>

        <div className="flex justify-center">
          <Button onClick={() => handleOpenDialog()} disabled={sessionLoading || (!isPremium && userListingsCount >= currentLimit)}>
            <PlusCircle className="h-4 w-4 mr-2" />
            {t('dialogs.addRequest')}
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-10 gap-2 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>{t('pages.loading')}</span>
          </div>
        ) : error ? (
          <div className="flex flex-col items-center py-10 gap-4 bg-muted/20 rounded-xl border border-dashed">
            <AlertTriangle className="h-8 w-8 text-destructive/50" />
            <p className="text-sm text-muted-foreground text-center px-4">{error}</p>
            <Button variant="outline" size="sm" onClick={refreshRequests}>
              <RefreshCcw className="h-4 w-4 mr-2" />
              {t('pages.retryConnection')}
            </Button>
          </div>
        ) : (
          <div className="space-y-8">
            {activeRequests.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground">{t('pages.active')} ({activeRequests.length})</h4>
                {activeRequests.map((request) => (
                  <div key={request.id} className="flex items-center gap-3 p-2 border rounded-xl bg-card shadow-sm transition-all hover:border-primary/20">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-semibold text-sm truncate">{request.title}</p>
                        <Badge
                          variant={request.status === "open" ? "default" : request.status === "in_progress" ? "secondary" : "outline"}
                          className="text-[8px] h-4"
                        >
                          {request.status.replace('_', ' ')}
                        </Badge>
                        {request.is_featured && (
                          <div className="bg-yellow-500 text-white p-0.5 rounded-full shadow-sm">
                            <Sparkles className="h-2 w-2 fill-current" />
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-[10px] uppercase font-bold text-muted-foreground">{request.category}</span>
                        <span className="text-[10px] text-muted-foreground">
                          {new Date(request.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => handleOpenDialog(request)}>
                          <Edit className="h-4 w-4 mr-2" />
                          {t('common.edit')}
                        </DropdownMenuItem>
                        {isPremium && (
                          <DropdownMenuItem onClick={() => toggleFeatured(request.id, !request.is_featured)} className="text-yellow-600 font-bold">
                            <Sparkles className="h-3 w-3 mr-2 fill-current" />
                            {request.is_featured ? t('pages.removeFeature') : t('pages.featureRequest')}
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleDeleteClick(request.id)} className="text-destructive">
                          <Trash className="h-4 w-4 mr-2" />
                          {t('common.delete')}
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                ))}
              </div>
            )}

            {heldRequests.length > 0 && (
              <div className="space-y-3 opacity-80">
                <h4 className="text-sm font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Lock className="h-3 w-3" />
                  {t('pages.held')} / {t('pages.invisible')} ({heldRequests.length})
                </h4>
                {heldRequests.map((request) => (
                  <div key={request.id} className="flex items-center gap-3 p-2 border rounded-xl bg-muted/30 shadow-sm relative overflow-hidden">
                    <div className="absolute inset-0 bg-black/5 backdrop-blur-[1px] pointer-events-none rounded-xl" />
                    <div className="relative z-10 flex w-full items-center gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="font-semibold text-sm truncate text-muted-foreground">{request.title}</p>
                          <Badge className="bg-black/80 text-white text-[8px] border-none">HELD</Badge>
                        </div>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] uppercase font-bold text-muted-foreground">{request.category}</span>
                          <span className="text-[10px] text-muted-foreground italic">{t('pages.invisibleToPublic')}</span>
                        </div>
                      </div>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 relative z-10">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => handleOpenDialog(request)}>{t('pages.editDetails')}</DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onClick={() => handleDeleteClick(request.id)} className="text-destructive">{t('common.delete')}</DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {activeRequests.length === 0 && heldRequests.length === 0 && (
              <p className="text-muted-foreground text-center py-10 border rounded-xl border-dashed">
                {t('pages.noRequestsYet')}
              </p>
            )}
          </div>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>{editingRequest ? t('dialogs.editRequest') : t('dialogs.addRequest')}</DialogTitle>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title *</Label>
              <Input
                id="title"
                name="title"
                value={form.title}
                onChange={handleInputChange}
                placeholder="What are you looking for?"
                className={formErrors.title ? "border-destructive" : ""}
              />
              {formErrors.title && (
                <p className="text-sm text-destructive">{formErrors.title}</p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={form.category}
                  onValueChange={(value) => handleSelectChange("category", value)}
                >
                  <SelectTrigger className={formErrors.category ? "border-destructive" : ""}>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(category => (
                      <SelectItem key={category} value={category}>{category}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {formErrors.category && (
                  <p className="text-sm text-destructive">{formErrors.category}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="status">{t('pages.status')}</Label>
                <Select
                  value={form.status}
                  onValueChange={(value) => handleSelectChange("status", value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open">{t('requests.open')}</SelectItem>
                    <SelectItem value="in_progress">{t('requests.inProgress')}</SelectItem>
                    <SelectItem value="fulfilled">{t('requests.fulfilled')}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">{t('dialogs.description')}</Label>
              <Textarea
                id="description"
                name="description"
                value={form.description}
                onChange={handleInputChange}
                placeholder="Provide more details about what you need..."
                rows={3}
              />
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={handleCloseDialog}>
                {t('common.cancel')}
              </Button>
              <Button type="submit">
                {editingRequest ? t('dialogs.updateRequest') : t('dialogs.createRequest')}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deletingRequestId} onOpenChange={(open) => !open && setDeletingRequestId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{t('dialogs.areYouSure')}</DialogTitle>
          </DialogHeader>
          <p>{t('dialogs.deleteConfirmation')}</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeletingRequestId(null)} disabled={isDeleting}>
              {t('common.cancel')}
            </Button>
            <Button variant="destructive" onClick={handleDeleteConfirm} disabled={isDeleting}>
              {isDeleting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  {t('dialogs.deleting')}
                </>
              ) : (
                t('common.delete')
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default MyRequestsPage;