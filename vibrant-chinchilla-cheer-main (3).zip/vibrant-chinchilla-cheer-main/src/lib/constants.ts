export const itemCategories = [
  "Food",
  "Entertainment",
  "Technology",
  "Construction",
  "ICT",
  "Education",
  "Others",
];

export const serviceCategories = [
  "Food",
  "Entertainment",
  "Technology",
  "Construction",
  "ICT",
  "Education",
  "Others",
];