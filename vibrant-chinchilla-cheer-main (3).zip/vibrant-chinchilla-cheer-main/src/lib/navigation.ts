import { ShoppingBag, Handshake, Map, Home, Briefcase, Settings, User, MessageSquare, Heart, LucideIcon, HelpCircle, Crown } from "lucide-react";

interface NavItem {
  name: string;
  href: string;
  icon: LucideIcon;
}

export const navItems: NavItem[] = [
  {
    name: "Goods",
    href: "/goods",
    icon: ShoppingBag,
  },
  {
    name: "Services",
    href: "/services",
    icon: Handshake,
  },
  {
    name: "Requests",
    href: "/requests",
    icon: HelpCircle,
  },
  {
    name: "My Goods",
    href: "/my-goods",
    icon: Home,
  },
  {
    name: "My Services",
    href: "/my-services",
    icon: Briefcase,
  },
  {
    name: "My Requests",
    href: "/my-requests",
    icon: HelpCircle,
  },
  {
    name: "Map",
    href: "/map",
    icon: Map,
  },
  {
    name: "Premium", // Added Premium to navigation
    href: "/premium",
    icon: Crown,
  },
  {
    name: "Favorites",
    href: "/favorites",
    icon: Heart,
  },
  {
    name: "Messages",
    href: "/messages",
    icon: MessageSquare,
  },
  {
    name: "Profile",
    href: "/profile",
    icon: User,
  },
  {
    name: "Settings",
    href: "/settings",
    icon: Settings,
  },
];