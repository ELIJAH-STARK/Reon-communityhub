"use client";

/**
 * Shared utility to filter listings based on the user's subscription and the '10 most recent' rule.
 * Now uses the owner_profile already joined in the database query.
 */
export const getVisibleListings = (
  allGoods: any[],
  allServices: any[],
  allRequests: any[]
) => {
  const now = new Date();
  const userGroups: Record<string, any[]> = {};
  
  // Combine all listing types into one master list sorted by date
  const allListings = [
    ...allGoods.map(i => ({ ...i, type: 'good' })),
    ...allServices.map(s => ({ ...s, type: 'service' })),
    ...allRequests.map(r => ({ ...r, type: 'request' }))
  ].sort((a, b) => new Date(b.created_at || 0).getTime() - new Date(a.created_at || 0).getTime());

  // Group by owner
  allListings.forEach(l => {
    if (!userGroups[l.user_id]) userGroups[l.user_id] = [];
    userGroups[l.user_id].push(l);
  });

  const visibleIds = new Set<string>();
  
  Object.keys(userGroups).forEach(uid => {
    // We grab the profile from the first listing in the group (since they all share the same owner)
    const profile = userGroups[uid][0].owner_profile;
    
    // Check if user has an active premium subscription or extra slots
    const isPremium = profile?.is_premium && (!profile?.premium_until || new Date(profile.premium_until) > now);
    const hasSlots = (profile?.extra_slots || 0) > 0 && (!profile?.extra_slots_until || new Date(profile.extra_slots_until) > now);
    
    const limit = (isPremium || hasSlots) ? 999999 : 10;
    
    // Only the first 'limit' listings for this user are visible to the public
    userGroups[uid].slice(0, limit).forEach(l => visibleIds.add(l.id));
  });

  return {
    goods: allGoods.filter(i => visibleIds.has(i.id)),
    services: allServices.filter(s => visibleIds.has(s.id)),
    requests: allRequests.filter(r => visibleIds.has(r.id)),
    visibleIds
  };
};