package com.example.vibrantchinchillacheer;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
